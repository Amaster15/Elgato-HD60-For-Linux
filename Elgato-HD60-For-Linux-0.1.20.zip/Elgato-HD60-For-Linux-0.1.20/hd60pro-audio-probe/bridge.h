/* SPDX-License-Identifier: GPL-2.0 */
/* Host-buffer delivery only; hardware commands belong to the caller's worker. */
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/spinlock.h>
#include <media/v4l2-device.h>
#include <media/v4l2-ioctl.h>
#include <media/videobuf2-v4l2.h>
#include <media/videobuf2-vmalloc.h>
#define BRIDGE_BYTES 3110400u
struct bridge_buffer { struct vb2_v4l2_buffer vb; struct list_head link; };
struct hd60_bridge {
 struct v4l2_device v4l2;
 struct video_device video;
 struct vb2_queue queue;
 struct mutex mutex;
 spinlock_t lock;
 struct list_head pending;
 bool streaming, used;
 /* Host-only experiment: owner explicitly permits reuse after stop joins. */
 bool reusable;
 u32 sequence;
 /* start schedules worker only. stop joins it; neither takes mutex. */
 int (*start)(void *);
 void (*stop)(void *);
 void *context;
};
static void bridge_return(struct hd60_bridge *b, enum vb2_buffer_state state)
{
 struct bridge_buffer *v, *next;
 unsigned long flags;
 LIST_HEAD(done);
 spin_lock_irqsave(&b->lock,flags);
 list_splice_init(&b->pending,&done);
 spin_unlock_irqrestore(&b->lock,flags);
 list_for_each_entry_safe(v,next,&done,link) {
  list_del_init(&v->link); vb2_buffer_done(&v->vb.vb2_buf,state);
 }
}
/* Caller supplies a stable host copy. Never call with card-owned DMA memory.
 * Worker must be joined by stop before vb2 buffers may be released. */
static bool bridge_deliver(struct hd60_bridge *b,const void *frame,size_t bytes,u64 stamp)
{
 struct bridge_buffer *v=NULL; void *dst; unsigned long flags;
 if(!frame || bytes!=BRIDGE_BYTES) return false;
 spin_lock_irqsave(&b->lock,flags);
 if(b->streaming && !list_empty(&b->pending)) {
  v=list_first_entry(&b->pending,struct bridge_buffer,link);
  list_del_init(&v->link);
 }
 spin_unlock_irqrestore(&b->lock,flags);
 if(!v) return false;
 dst=vb2_plane_vaddr(&v->vb.vb2_buf,0);
 if(!dst) { vb2_buffer_done(&v->vb.vb2_buf,VB2_BUF_STATE_ERROR); return false; }
 memcpy(dst,frame,bytes);
 v->vb.field=V4L2_FIELD_NONE; v->vb.sequence=b->sequence++;
 v->vb.vb2_buf.timestamp=stamp;
 vb2_set_plane_payload(&v->vb.vb2_buf,0,bytes);
 vb2_buffer_done(&v->vb.vb2_buf,VB2_BUF_STATE_DONE);
 return true;
}
static int bridge_setup(struct vb2_queue *q,unsigned int *count,unsigned int *planes,
 unsigned int sizes[],struct device *devices[])
{
 if(*planes) return *planes==1 && sizes[0]>=BRIDGE_BYTES ? 0 : -EINVAL;
 *count=clamp_t(unsigned int,*count,2,8); *planes=1; sizes[0]=BRIDGE_BYTES; return 0;
}
static int bridge_prepare(struct vb2_buffer *v)
{ return vb2_plane_size(v,0)>=BRIDGE_BYTES ? 0 : -EINVAL; }
static void bridge_queue(struct vb2_buffer *v)
{
 struct hd60_bridge *b=vb2_get_drv_priv(v->vb2_queue);
 struct bridge_buffer *buf=container_of(to_vb2_v4l2_buffer(v),struct bridge_buffer,vb);
 unsigned long flags;
 spin_lock_irqsave(&b->lock,flags); list_add_tail(&buf->link,&b->pending);
 spin_unlock_irqrestore(&b->lock,flags);
}
static int bridge_start(struct vb2_queue *q,unsigned int count)
{
 struct hd60_bridge *b=vb2_get_drv_priv(q); int ret; unsigned long flags;
 if(b->used) { bridge_return(b,VB2_BUF_STATE_QUEUED); return -EIO; }
 b->used=true; b->sequence=0;
 spin_lock_irqsave(&b->lock,flags); b->streaming=true; spin_unlock_irqrestore(&b->lock,flags);
 ret=b->start(b->context);
 if(ret) {
  spin_lock_irqsave(&b->lock,flags); b->streaming=false; spin_unlock_irqrestore(&b->lock,flags);
  bridge_return(b,VB2_BUF_STATE_QUEUED);
 }
 return ret;
}
static void bridge_stop(struct vb2_queue *q)
{
 struct hd60_bridge *b=vb2_get_drv_priv(q); unsigned long flags;
 spin_lock_irqsave(&b->lock,flags); b->streaming=false; spin_unlock_irqrestore(&b->lock,flags);
 b->stop(b->context); /* Join worker; never acquire b->mutex in that worker. */
 bridge_return(b,VB2_BUF_STATE_ERROR);
 if(b->reusable) b->used=false;
}
static const struct vb2_ops bridge_ops={.queue_setup=bridge_setup,.buf_prepare=bridge_prepare,
 .buf_queue=bridge_queue,.start_streaming=bridge_start,.stop_streaming=bridge_stop};
static void bridge_format(struct v4l2_pix_format *p)
{
 memset(p,0,sizeof(*p)); p->width=1920;p->height=1080;
 p->pixelformat=V4L2_PIX_FMT_YUV420;p->field=V4L2_FIELD_NONE;
 p->bytesperline=1920;p->sizeimage=BRIDGE_BYTES;
 p->colorspace=V4L2_COLORSPACE_REC709;p->ycbcr_enc=V4L2_YCBCR_ENC_709;
 p->quantization=V4L2_QUANTIZATION_LIM_RANGE;p->xfer_func=V4L2_XFER_FUNC_709;
}
static int bridge_querycap(struct file *f,void *priv,struct v4l2_capability *c)
{
 struct hd60_bridge *b=video_drvdata(f);
 strscpy(c->driver,"hd60pro_bounded",sizeof(c->driver));
 strscpy(c->card,"HD60 Pro bounded live test",sizeof(c->card));
 snprintf(c->bus_info,sizeof(c->bus_info),"PCI:%s",dev_name(b->v4l2.dev));return 0;
}
static int bridge_enumfmt(struct file *f,void *p,struct v4l2_fmtdesc *d)
{ if(d->index) return -EINVAL;d->pixelformat=V4L2_PIX_FMT_YUV420;return 0; }
static int bridge_getfmt(struct file *f,void *p,struct v4l2_format *fmt)
{ bridge_format(&fmt->fmt.pix);return 0; }
static int bridge_setfmt(struct file *f,void *p,struct v4l2_format *fmt)
{
 struct hd60_bridge *b=video_drvdata(f);
 if(vb2_is_busy(&b->queue)) return -EBUSY;
 return bridge_getfmt(f,p,fmt);
}
static int bridge_enumsize(struct file *f,void *p,struct v4l2_frmsizeenum *s)
{
 if(s->index || s->pixel_format!=V4L2_PIX_FMT_YUV420) return -EINVAL;
 s->type=V4L2_FRMSIZE_TYPE_DISCRETE;s->discrete.width=1920;s->discrete.height=1080;return 0;
}
static int bridge_enuminterval(struct file *f,void *p,struct v4l2_frmivalenum *v)
{
 if(v->index || v->pixel_format!=V4L2_PIX_FMT_YUV420 || v->width!=1920 || v->height!=1080) return -EINVAL;
 v->type=V4L2_FRMIVAL_TYPE_DISCRETE;v->discrete.numerator=1;v->discrete.denominator=30;return 0;
}
static int bridge_parm(struct file *f,void *p,struct v4l2_streamparm *v)
{
 if(v->type!=V4L2_BUF_TYPE_VIDEO_CAPTURE) return -EINVAL;
 memset(&v->parm,0,sizeof(v->parm));v->parm.capture.capability=V4L2_CAP_TIMEPERFRAME;
 v->parm.capture.timeperframe.numerator=1;v->parm.capture.timeperframe.denominator=30;return 0;
}
static int bridge_enuminput(struct file *f,void *p,struct v4l2_input *i)
{ if(i->index)return -EINVAL;strscpy(i->name,"HDMI",sizeof(i->name));i->type=V4L2_INPUT_TYPE_CAMERA;return 0; }
static int bridge_getinput(struct file *f,void *p,unsigned int *i) { *i=0;return 0; }
static int bridge_setinput(struct file *f,void *p,unsigned int i) { return i ? -EINVAL : 0; }
static const struct v4l2_ioctl_ops bridge_ioctl={
 .vidioc_querycap=bridge_querycap,.vidioc_enum_fmt_vid_cap=bridge_enumfmt,
 .vidioc_g_fmt_vid_cap=bridge_getfmt,.vidioc_try_fmt_vid_cap=bridge_getfmt,
 .vidioc_s_fmt_vid_cap=bridge_setfmt,.vidioc_enum_framesizes=bridge_enumsize,
 .vidioc_enum_frameintervals=bridge_enuminterval,.vidioc_g_parm=bridge_parm,.vidioc_s_parm=bridge_parm,
 .vidioc_enum_input=bridge_enuminput,.vidioc_g_input=bridge_getinput,.vidioc_s_input=bridge_setinput,
 .vidioc_reqbufs=vb2_ioctl_reqbufs,.vidioc_create_bufs=vb2_ioctl_create_bufs,
 .vidioc_prepare_buf=vb2_ioctl_prepare_buf,.vidioc_querybuf=vb2_ioctl_querybuf,
 .vidioc_qbuf=vb2_ioctl_qbuf,.vidioc_dqbuf=vb2_ioctl_dqbuf,
 .vidioc_streamon=vb2_ioctl_streamon,.vidioc_streamoff=vb2_ioctl_streamoff,
};
static const struct v4l2_file_operations bridge_fops={.owner=THIS_MODULE,
 .open=v4l2_fh_open,.release=vb2_fop_release,.poll=vb2_fop_poll,
 .mmap=vb2_fop_mmap,.unlocked_ioctl=video_ioctl2};
/* Owner must retain bridge storage through final video release, including
 * open descriptors. Initial integration deliberately retains it until reboot. */
static int bridge_register(struct hd60_bridge *b,struct device *dev,
 int (*start)(void *),void (*stop)(void *),void *context)
{
 int ret;
 if(!start || !stop) return -EINVAL;
 mutex_init(&b->mutex);spin_lock_init(&b->lock);INIT_LIST_HEAD(&b->pending);
 b->start=start;b->stop=stop;b->context=context;b->streaming=false;b->used=false;
 /* A root test device has no dev->driver. Do not ask V4L2 to derive
  * its name from that pointer; provide the name before registration. */
 strscpy(b->v4l2.name,"hd60pro-bounded",sizeof(b->v4l2.name));
 ret=v4l2_device_register(dev,&b->v4l2);if(ret)return ret;
 b->queue.type=V4L2_BUF_TYPE_VIDEO_CAPTURE;b->queue.io_modes=VB2_MMAP;
 b->queue.drv_priv=b;b->queue.buf_struct_size=sizeof(struct bridge_buffer);
 b->queue.ops=&bridge_ops;b->queue.mem_ops=&vb2_vmalloc_memops;
 b->queue.timestamp_flags=V4L2_BUF_FLAG_TIMESTAMP_MONOTONIC;
 b->queue.lock=&b->mutex;b->queue.dev=dev;
 ret=vb2_queue_init(&b->queue);if(ret)goto fail;
 strscpy(b->video.name,"HD60 Pro bounded live test",sizeof(b->video.name));
 b->video.v4l2_dev=&b->v4l2;b->video.fops=&bridge_fops;
 b->video.ioctl_ops=&bridge_ioctl;b->video.release=video_device_release_empty;
 b->video.lock=&b->mutex;b->video.queue=&b->queue;
 b->video.device_caps=V4L2_CAP_VIDEO_CAPTURE|V4L2_CAP_STREAMING;
 video_set_drvdata(&b->video,b);
 ret=video_register_device(&b->video,VFL_TYPE_VIDEO,-1);if(!ret)return 0;
 vb2_queue_release(&b->queue);
fail:
 v4l2_device_unregister(&b->v4l2);return ret;
}
/* Worker calls this after hardware containment. No saved-image replay. */
static void bridge_finished(struct hd60_bridge *b)
{
 unsigned long flags;
 spin_lock_irqsave(&b->lock,flags);b->streaming=false;spin_unlock_irqrestore(&b->lock,flags);
 bridge_return(b,VB2_BUF_STATE_ERROR);vb2_queue_error(&b->queue);
}
