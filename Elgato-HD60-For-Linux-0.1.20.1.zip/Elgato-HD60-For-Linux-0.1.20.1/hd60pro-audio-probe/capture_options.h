/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_CAPTURE_OPTIONS_H
#define HD60_CAPTURE_OPTIONS_H
/* Continuous operation requires the retained-owner client stop lifecycle.
 * Startup discard remains an explicit 0/150ms choice, never ongoing silence. */
static inline int hd60_capture_options_valid(unsigned int duration,
 unsigned int reuse, unsigned int startup)
{
 if(startup!=0 && startup!=150) return 0;
 return duration==3000 || duration==30000 || duration==300000 ||
        (duration==0 && reuse);
}
#endif
