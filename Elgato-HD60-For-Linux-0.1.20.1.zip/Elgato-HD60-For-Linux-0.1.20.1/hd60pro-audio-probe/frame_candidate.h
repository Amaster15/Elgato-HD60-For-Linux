/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_FRAME_CANDIDATE_H
#define HD60_FRAME_CANDIDATE_H
#include "stable_copy.h"
/* A negative filter, NOT a DMA completion or freshness detector.
 * Primary pools start zeroed. A 16-byte stub leaves the rest untouched.
 * Inspect all three planes so that luma-only updates cannot pass this gate.
 * Valid limited-range black has Y=16,U=128,V=128 and passes. Pure zero planes
 * are ambiguous and rejected for this diagnostic; not a generic format rule.
 */
static inline unsigned int hd60_candidate_plane_mask(const void *frame, size_t bytes)
{
 const unsigned char *p=frame;
 const size_t start[3]={16,2073600,2592000};
 const size_t end[3]={2073600,2592000,3110400};
 unsigned int mask=0,plane;
 size_t i;
 if(!p || bytes!=HD60_I420_1080_BYTES) return 0;
 for(plane=0;plane<3;plane++) {
  for(i=start[plane];i<end[plane];i++) {
   if(p[i]) { mask|=1u<<plane; break; }
  }
 }
 return mask;
}
/* Firmware sets byte 5 bit 0 BEFORE a full DMA and clears it before
 * a 16-byte stub. Reject stale image bodies under a newer stub header.
 * This marker is NOT a completion fence; even a marked partial frame passes.
 * Call only on an immutable host copy, never directly on active DMA memory.
 */
static inline int hd60_candidate_full_marker(const void *frame, size_t bytes)
{
 const unsigned char *p=frame;
 return p && bytes==HD60_I420_1080_BYTES && (p[5]&1u);
}
static inline int hd60_candidate_selected(const void *frame, size_t bytes)
{
 return hd60_candidate_full_marker(frame,bytes) &&
        hd60_candidate_plane_mask(frame,bytes)==7;
}
#endif
