#ifndef HD60_STABLE_COPY_H
#define HD60_STABLE_COPY_H
/* Diagnostic only: equality is not a device completion fence. Caller provides
 * two disjoint host-owned buffers, and a reader for coherent DMA memory.
 * Never expose the DMA source directly to userspace. No retry/spin loop here.
 */
#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/string.h>
#else
#include <stddef.h>
#include <string.h>
#endif
#define HD60_I420_1080_BYTES 3110400u

enum hd60_copy_result {
 HD60_COPY_INVALID = -1,
 HD60_COPY_CHANGED = 0,
 HD60_COPY_EQUAL_CANDIDATE = 1
};
typedef void (*hd60_copy_reader)(void *context, void *destination, size_t bytes);

static inline enum hd60_copy_result
hd60_copy_pair(void *first, size_t first_capacity,
               void *second, size_t second_capacity,
               hd60_copy_reader reader, void *context)
{
 if (!first || !second || first == second || !reader ||
     first_capacity < HD60_I420_1080_BYTES ||
     second_capacity < HD60_I420_1080_BYTES)
  return HD60_COPY_INVALID;
 reader(context, first, HD60_I420_1080_BYTES);
 reader(context, second, HD60_I420_1080_BYTES);
 return memcmp(first, second, HD60_I420_1080_BYTES) ?
        HD60_COPY_CHANGED : HD60_COPY_EQUAL_CANDIDATE;
}
#endif
