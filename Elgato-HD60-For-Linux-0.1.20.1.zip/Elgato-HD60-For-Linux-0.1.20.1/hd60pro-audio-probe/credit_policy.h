/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_CREDIT_POLICY_H
#define HD60_CREDIT_POLICY_H
/* Bounded drop-only observer. This policy does not authorize CPU reads of DMA
 * buffers. One observed frame grants at most one release, until STOP begins. */
enum hd60_credit_action { HD60_CREDIT_WAIT, HD60_CREDIT_RELEASE, HD60_CREDIT_FAULT };
static inline enum hd60_credit_action
hd60_credit_action(unsigned int observed, unsigned int stopping,
                   unsigned int io_valid, unsigned int master_on,
                   unsigned int raw_status)
{
 if(stopping || !observed) return HD60_CREDIT_WAIT;
 if(!io_valid || !master_on || raw_status==~0u || (raw_status&255u)>1u)
  return HD60_CREDIT_FAULT;
 return (raw_status&255u) ? HD60_CREDIT_RELEASE : HD60_CREDIT_WAIT;
}
#endif
