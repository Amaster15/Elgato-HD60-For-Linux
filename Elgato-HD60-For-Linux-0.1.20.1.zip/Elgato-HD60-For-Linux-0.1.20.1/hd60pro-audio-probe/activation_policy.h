/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_CONFIGURED_ACTIVATION_H
#define HD60_CONFIGURED_ACTIVATION_H
#include "../hd60pro-lifecycle/capture_guard.h"
/* The encoder tail activates this firmware. Accept frame events as soon as
 * BME is enabled, without claiming an opcode6 acknowledgement. The shared
 * guard's historical start_submitted member is the event-eligibility latch. */
static inline int hd60_arm_configured_pipeline(struct hd60_capture_guard *g,
 unsigned int mode_ack, unsigned int audio_ack, unsigned int encoder_acks,
 unsigned int preview_ack)
{
 if(!mode_ack || !audio_ack || encoder_acks!=2 || !preview_ack || g->start_submitted)
  return 0;
 if(!hd60_capture_arm_master(g)) return 0;
 g->start_submitted=1;
 g->life.stop_confirmed=0;
 return 1;
}
#endif
