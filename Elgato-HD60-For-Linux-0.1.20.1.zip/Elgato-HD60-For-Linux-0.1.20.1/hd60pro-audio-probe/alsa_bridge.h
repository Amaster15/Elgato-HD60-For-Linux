/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_ALSA_BRIDGE_H
#define HD60_ALSA_BRIDGE_H
#include <sound/core.h>
#include <sound/pcm.h>
#include <sound/pcm_params.h>
/* Host-only PCM storage. Hardware session is owned by the V4L2 worker in this
 * bounded integration test. No PCM operation writes a card register.
 * gate serializes producer with close/hw_free; trigger never takes gate because
 * ALSA invokes it with its stream spinlock held. */
struct hd60_alsa {
 struct snd_card *card;
 struct snd_pcm *pcm;
 struct snd_pcm_substream *substream;
 unsigned int pushes, rejected;
 struct mutex gate;
 bool running, ended;
 snd_pcm_uframes_t position;
};
static const struct snd_pcm_hardware hd60_pcm_hw={
 .info=SNDRV_PCM_INFO_INTERLEAVED|SNDRV_PCM_INFO_BLOCK_TRANSFER,
 .formats=SNDRV_PCM_FMTBIT_S16_LE, .rates=SNDRV_PCM_RATE_48000,
 .rate_min=48000,.rate_max=48000,.channels_min=2,.channels_max=2,
 .buffer_bytes_max=1920*100,.period_bytes_min=1920,.period_bytes_max=1920,
 .periods_min=2,.periods_max=100,
};
static int hd60_pcm_open(struct snd_pcm_substream *s)
{
 struct hd60_alsa *a=snd_pcm_substream_chip(s);
 int ret;
 mutex_lock(&a->gate);
 if(a->ended) { mutex_unlock(&a->gate);return -ENODEV; }
 s->runtime->hw=hd60_pcm_hw;
 /* Receiver setup currently takes ~5s. ALSA default read wait expires sooner.
  * This is a finite startup allowance, not inserted silence or fake periods. */
 s->wait_time=10000;
 /* Failed open does not promise a close callback. Publish the stream only
  * after constraints succeed, so end/push cannot retain a rejected runtime. */
 ret=snd_pcm_hw_constraint_integer(s->runtime,SNDRV_PCM_HW_PARAM_PERIODS);
 if(ret>=0) a->substream=s;
 mutex_unlock(&a->gate);
 return ret<0 ? ret : 0;
}
static int hd60_pcm_close(struct snd_pcm_substream *s)
{
 struct hd60_alsa *a=snd_pcm_substream_chip(s);
 mutex_lock(&a->gate);WRITE_ONCE(a->running,false);a->substream=NULL;
 mutex_unlock(&a->gate);return 0;
}
static int hd60_pcm_free(struct snd_pcm_substream *s)
{
 struct hd60_alsa *a=snd_pcm_substream_chip(s);
 mutex_lock(&a->gate);WRITE_ONCE(a->running,false);
 mutex_unlock(&a->gate);return 0;
}
static int hd60_pcm_prepare(struct snd_pcm_substream *s)
{
 struct hd60_alsa *a=snd_pcm_substream_chip(s);
 int ret=0;
 mutex_lock(&a->gate);
 if(a->ended) ret=-ENODEV;
 else { WRITE_ONCE(a->running,false);WRITE_ONCE(a->position,0); }
 mutex_unlock(&a->gate);return ret;
}
static int hd60_pcm_trigger(struct snd_pcm_substream *s,int cmd)
{
 struct hd60_alsa *a=snd_pcm_substream_chip(s);
 switch(cmd) {
 case SNDRV_PCM_TRIGGER_START:
  if(READ_ONCE(a->ended)) return -ENODEV;
  WRITE_ONCE(a->running,true);return 0;
 case SNDRV_PCM_TRIGGER_STOP:
  WRITE_ONCE(a->running,false);return 0;
 default:return -EINVAL;
 }
}
static snd_pcm_uframes_t hd60_pcm_pointer(struct snd_pcm_substream *s)
{ struct hd60_alsa *a=snd_pcm_substream_chip(s);return READ_ONCE(a->position); }
static const struct snd_pcm_ops hd60_pcm_ops={
 .open=hd60_pcm_open,.close=hd60_pcm_close,.ioctl=snd_pcm_lib_ioctl,
 .hw_free=hd60_pcm_free,.prepare=hd60_pcm_prepare,.trigger=hd60_pcm_trigger,
 .pointer=hd60_pcm_pointer,
};
static int hd60_alsa_register(struct hd60_alsa *a,struct device *dev,const char *id)
{
 int ret;
 mutex_init(&a->gate);
 ret=snd_card_new(dev,-1,id,THIS_MODULE,0,&a->card);
 if(ret) return ret;
 strscpy(a->card->driver,"HD60Audio");
 strscpy(a->card->shortname,"HD60 Pro HDMI Audio");
 strscpy(a->card->longname,"HD60 Pro experimental bounded HDMI capture");
 ret=snd_pcm_new(a->card,"HD60 HDMI",0,0,1,&a->pcm);
 if(ret) goto fail;
 a->pcm->private_data=a;strscpy(a->pcm->name,"HDMI 48k stereo");
 snd_pcm_set_ops(a->pcm,SNDRV_PCM_STREAM_CAPTURE,&hd60_pcm_ops);
 ret=snd_pcm_set_managed_buffer_all(a->pcm,SNDRV_DMA_TYPE_VMALLOC,NULL,192000,192000);
 if(ret) goto fail;
 ret=snd_card_register(a->card);
 if(!ret) return 0;
fail:
 snd_card_free(a->card);a->card=NULL;return ret;
}
static void hd60_alsa_end(struct hd60_alsa *a)
{
 if(!a->card) return;
 mutex_lock(&a->gate);WRITE_ONCE(a->ended,true);
 if(a->substream && READ_ONCE(a->running)) snd_pcm_stop_xrun(a->substream);
 WRITE_ONCE(a->running,false);mutex_unlock(&a->gate);
}
/* Caller must have joined the hardware worker and verified clean STOP, or fully undone pre-registration startup, before
 * rearming. This changes host PCM eligibility only; no hardware access. */
static int hd60_alsa_rearm(struct hd60_alsa *a)
{
 int ret=0;
 mutex_lock(&a->gate);
 if(READ_ONCE(a->running)) ret=-EBUSY;
 else { WRITE_ONCE(a->ended,false);WRITE_ONCE(a->position,0); }
 mutex_unlock(&a->gate);
 return ret;
}
static void hd60_alsa_push(struct hd60_alsa *a,const void *data)
{
 struct snd_pcm_substream *s;
 struct snd_pcm_runtime *r;
 snd_pcm_uframes_t pos;
 if(!a->card) return;
 mutex_lock(&a->gate);s=a->substream;
 if(a->ended || !s || !READ_ONCE(a->running)) { a->rejected++;goto out; }
 r=s->runtime;pos=READ_ONCE(a->position);
 if(!r->dma_area || r->period_size!=480 || r->buffer_size<960 ||
    r->buffer_size%480 || pos+480>r->buffer_size) {
  pr_err("HD60 ALSA invalid area=%u period=%lu buffer=%lu pos=%lu\n",!!r->dma_area,(unsigned long)r->period_size,(unsigned long)r->buffer_size,(unsigned long)pos);
  WRITE_ONCE(a->ended,true);snd_pcm_stop_xrun(s);goto out;
 }
 a->pushes++;
 memcpy(r->dma_area+pos*4,data,1920);
 pos+=480;if(pos==r->buffer_size) pos=0;
 /* ALSA sees the new pointer only after the corresponding host copy. */
 smp_wmb();WRITE_ONCE(a->position,pos);snd_pcm_period_elapsed(s);
out:
 mutex_unlock(&a->gate);
}
#endif
