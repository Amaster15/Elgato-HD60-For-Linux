/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_COHERENT_POOL_H
#define HD60_COHERENT_POOL_H
#ifndef HD60_POOL_TEST
#include <linux/dma-mapping.h>
#include <linux/string.h>
#endif
#define HD60_RAW_SLOTS 4
#define HD60_RAW_ALLOCATION (4U * 1024U * 1024U)
#define HD60_CHUNK_BYTES (4U * 1024U * 1024U)
#define HD60_CHUNK_LIMIT 16
#ifndef HD60_POOL_TEST
#define HD60_POOL_LOG(dev, ...) dev_info(dev, __VA_ARGS__)
#else
#define HD60_POOL_LOG(dev, ...) ((void)0)
#endif
struct hd60_coherent_pool {
 void *cpu[HD60_RAW_SLOTS], *tail[HD60_RAW_SLOTS];
 dma_addr_t dma[HD60_RAW_SLOTS], tail_dma[HD60_RAW_SLOTS];
 unsigned int allocated;
 bool paired;
};
/* Only after proven end of device ownership, or before publishing addresses. */
static inline void hd60_coherent_pool_free(struct device *dev,
 struct hd60_coherent_pool *p)
{
 unsigned int i;
 for (i=0;i<HD60_RAW_SLOTS;i++) {
  if(p->cpu[i]) dma_free_coherent(dev,p->paired?HD60_CHUNK_BYTES:HD60_RAW_ALLOCATION,p->cpu[i],p->dma[i]);
  if(p->tail[i]) dma_free_coherent(dev,HD60_CHUNK_BYTES,p->tail[i],p->tail_dma[i]);
 }
 memset(p,0,sizeof(*p));
}
/* Host pointer contiguity is never assumed, even when DMA addresses adjoin. */
static inline void hd60_coherent_copy_stopped(void *dst,
 const struct hd60_coherent_pool *p, unsigned int i)
{
 if(!p->paired) memcpy(dst,p->cpu[i],HD60_RAW_ALLOCATION);
 else {
  memcpy(dst,p->cpu[i],HD60_CHUNK_BYTES);
  memcpy((char *)dst+HD60_CHUNK_BYTES,p->tail[i],HD60_RAW_ALLOCATION-HD60_CHUNK_BYTES);
 }
}
static inline int hd60_coherent_pool_alloc(struct device *dev,
 struct hd60_coherent_pool *p)
{
 unsigned int i;
 if(p->allocated || p->paired) return -EBUSY;
 for(i=0;i<HD60_RAW_SLOTS;i++) if(p->cpu[i] || p->tail[i]) return -EBUSY;
 for(i=0;i<HD60_RAW_SLOTS;i++) {
  p->cpu[i]=dma_alloc_coherent(dev,HD60_RAW_ALLOCATION,&p->dma[i],GFP_KERNEL|__GFP_NOWARN);
  if(!p->cpu[i]) { hd60_coherent_pool_free(dev,p); return -ENOMEM; }
  memset(p->cpu[i],0,HD60_RAW_ALLOCATION);p->allocated++;
 }
 return 0;
}
#endif
