/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_STREAM_SESSION_H
#define HD60_STREAM_SESSION_H
struct hd60_stream_session {
 unsigned int delivered_frames;
 bool client_stop_requested;
 unsigned long long live_interval_ns;
 int diagnostic_error;
 bool finished;
 bool stop_event;
 bool version_after;
 unsigned int stop_status;
 bool mode_event;
 bool audio_event;
 unsigned int mode_status;
 unsigned int mode_done;
 unsigned int mode_opcode;
 unsigned int audio_status;
 unsigned int audio_done;
 unsigned int audio_opcode;
 bool preview_attempted;
 bool preview_event;
 unsigned int preview_status;
 unsigned int preview_done;
 unsigned int encoder_events;
 unsigned int ownership_releases;
 unsigned int encoded_status_last;
 bool explicit_start_event;
 bool ownership_release_pending;
 bool snapshot_ready;
 unsigned int snapshot_bytes;
 unsigned int snapshot_flush_status;
 bool master_off_verified;
 unsigned int frame_events;
 unsigned int last_frame_counter;
 unsigned int activation_armed;
 unsigned int mailbox_snapshot[5];
 unsigned int frame_counters[96];
 unsigned int frame_snapshots;
 unsigned int live_copy_count;
 unsigned int live_copy_equal;
 unsigned int live_copy_slots[8];
 unsigned int live_copy_events[8];
 int live_copy_results[8];
 unsigned long long live_copy_begin_ns[8];
 unsigned long long live_copy_end_ns[8];
 unsigned int stub_updates_skipped;
 unsigned int raw_after[8];
 unsigned int raw_selected[8];
};
#endif
