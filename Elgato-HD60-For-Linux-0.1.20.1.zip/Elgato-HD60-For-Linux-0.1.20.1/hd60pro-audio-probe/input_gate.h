/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_INPUT_GATE_H
#define HD60_INPUT_GATE_H
/* Classification of the existing measured-input gate, not a retry policy. */
enum hd60_input_status {
 HD60_INPUT_UNCHECKED, HD60_INPUT_NO_LOCK,
 HD60_INPUT_UNSUPPORTED, HD60_INPUT_ACCEPTED
};
static inline unsigned int hd60_input_classify(unsigned int lock,
 unsigned int width_hi,unsigned int width_lo,unsigned int height_hi,
 unsigned int height_lo,unsigned int scan)
{
 if((lock&0x3c)!=0x3c) return HD60_INPUT_NO_LOCK;
 if(width_hi!=7 || width_lo!=128 || (height_hi&255)!=4 ||
    (height_lo&255)!=0x38 || (scan&255)!=0)
  return HD60_INPUT_UNSUPPORTED;
 return HD60_INPUT_ACCEPTED;
}
#endif
