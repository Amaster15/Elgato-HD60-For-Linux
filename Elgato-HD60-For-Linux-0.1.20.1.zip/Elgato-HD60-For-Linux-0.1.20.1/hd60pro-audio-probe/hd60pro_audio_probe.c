#include "frame_candidate.h"
#include "../hd60pro-audio-review/stereo_event.h"
#include "../hd60pro-audio-review/indexed_event.h"
#include "../hd60pro-audio-review/copy_window.h"
/* PC/KVM measured metadata 48=82,49=28,4a=00/80. CSC evidence: pc-csc-plan.json. */
// SPDX-License-Identifier: GPL-2.0
/* Experimental bounded START; retains all DMA mappings after master enable. */
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/io.h>
#include <linux/iopoll.h>
#include <linux/iommu.h>
#include <linux/debugfs.h>
#include <linux/vmalloc.h>
#include "credit_policy.h"
#include "capture_options.h"
#include "hdmi_metadata.h"
#include "input_gate.h"
static unsigned int input_status;
module_param(input_status,uint,0444);
MODULE_PARM_DESC(input_status,"Startup input: 0 unchecked, 1 no lock, 2 unsupported mode, 3 accepted");
#include "activation_policy.h"
#include "coherent_pool.h"
#include "stable_copy.h"
#include <linux/ktime.h>
#include <linux/workqueue.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include "bridge.h"
#include "alsa_bridge.h"
#include "../hd60pro-audio-review/audio_sequence.h"
#include "../hd60pro-audio-review/startup_window.h"
static unsigned int audio_startup_ms;
static unsigned long long audio_start_ns;
static unsigned int audio_startup_discarded;
module_param(audio_startup_ms,uint,0444);
module_param(audio_startup_discarded,uint,0444);
MODULE_PARM_DESC(audio_startup_ms,"Initial PCM discard: 0 or 150 ms");
static struct hd60_alsa audio_pcm;
module_param_named(alsa_running,audio_pcm.running,bool,0444);
module_param_named(alsa_pushes,audio_pcm.pushes,uint,0444);
module_param_named(alsa_rejected,audio_pcm.rejected,uint,0444);
static struct hd60_audio_sequence audio_sequence;
static unsigned int audio_sequence_fault;
module_param(audio_sequence_fault,uint,0444);
/* Last eight audio publications, frozen at the first audio fault. Host-only
 * observations of existing reads; no extra MMIO, ACKs or ownership changes.
 * Each row: entry_ns,status,latest,sequence_seen,previous_slot,previous_begin,
 * previous_end,notification_count. Head is the next ring row to overwrite.
 * Read only after capture stops to obtain a consistent multi-field snapshot. */
static unsigned long long audio_event_history[64];
static unsigned int audio_event_history_head, audio_event_history_count;
module_param_array(audio_event_history,ullong,NULL,0444);
module_param(audio_event_history_head,uint,0444);
module_param(audio_event_history_count,uint,0444);

#include "receiver_session.h"
#include "stream_session.h"
#include "../hd60pro-restartability/session_policy.h"
#include "../hd60pro-restartability/startup_retry.h"
#include "../hd60pro-restartability/audio_restart.h"
static bool audio_restart_test;
module_param(audio_restart_test,bool,0444);
MODULE_PARM_DESC(audio_restart_test,"Experimental audio-only fault recovery after fully verified clean stop");
static unsigned int previous_audio_fault, audio_recovered_sessions;
static bool audio_recovery_pending;
module_param(audio_recovery_pending,bool,0444);
/* Opt-in one-shot host PCM fault; does not alter card registers or DMA data. */
static unsigned int audio_inject_gap_after_blocks;
static bool audio_gap_injected;
module_param(audio_inject_gap_after_blocks,uint,0444);
module_param(audio_gap_injected,bool,0444);
MODULE_PARM_DESC(audio_inject_gap_after_blocks,"Diagnostic only: inject one PCM continuity fault after this many accepted blocks; 0 disables");

module_param(previous_audio_fault,uint,0444);
module_param(audio_recovered_sessions,uint,0444);
static bool startup_retry_ready;
module_param(startup_retry_ready,bool,0444);
#define AUDIO_SAMPLE_LIMIT 3200u
static unsigned char audio_live_block[HD60_STEREO_BLOCK_BYTES];
static unsigned int audio_blocks;
module_param(audio_blocks,uint,0444);
/* Fixed LE24-byte records, one per accepted candidate; exported only stopped. */
struct audio_trace_record { __le64 begin_ns,end_ns; __le32 slot,reserved; };
static struct audio_trace_record audio_trace[AUDIO_SAMPLE_LIMIT];
static struct debugfs_blob_wrapper audio_trace_blob;
/* LE64x8: entry,status-read,decode,ack,audio,video,exit,status bits.
 * Timing only: no extra card accesses. Single dedicated worker writer. */
static u64 phase_current[8];
static __le64 phase_trace[65536][8];
static unsigned int phase_count;
static struct debugfs_blob_wrapper phase_blob;
/* Cumulative timing counters, single capture worker writer. Observe the
 * existing credit read only; never change release ordering or copy guards. */
static unsigned long long credit_pending_since_ns, credit_wait_calls;
static unsigned long long credit_release_samples, credit_release_total_ns;
static unsigned long long credit_release_max_ns, credit_pending_overlap;
module_param(credit_wait_calls,ullong,0444);
module_param(credit_release_samples,ullong,0444);
module_param(credit_release_total_ns,ullong,0444);
module_param(credit_release_max_ns,ullong,0444);
module_param(credit_pending_overlap,ullong,0444);
#define AUDIO_SENTINEL 0xa5
static unsigned int audio_extent_changed[32], audio_extent_nonzero[32];
static unsigned int audio_extent_first[32], audio_extent_last[32];
static bool audio_extent_snapshot;
module_param_array(audio_extent_changed,uint,NULL,0444);
module_param_array(audio_extent_nonzero,uint,NULL,0444);
module_param_array(audio_extent_first,uint,NULL,0444);
module_param_array(audio_extent_last,uint,NULL,0444);
module_param(audio_extent_snapshot,bool,0444);
/* Windows14024e287..e3cf audio setup; snapshot only, no configuration writes. */
static const u8 audio_receiver_regs[]={1,2,3,4,5,6,0x1c,0x1d,0x1e,0x1f,0x25};
static unsigned int audio_receiver_values[ARRAY_SIZE(audio_receiver_regs)];
static unsigned int audio_receiver_reads;
static bool audio_receiver_bank_restored;
module_param_array(audio_receiver_values,uint,NULL,0444);
module_param(audio_receiver_reads,uint,0444);
module_param(audio_receiver_bank_restored,bool,0444);
/* Snapshot run-CZljreUQ; targets from Windows14024e287..e3cf. */
static const u8 audio_setup_index[]={0,1,2,6,10};
static const u8 audio_setup_before[]={0x60,0x65,0,0x5a,0};
static const u8 audio_setup_target[]={0x61,0xf5,2,0x1a,0xa2};
static unsigned int audio_setup_attempted, audio_setup_verified, audio_setup_restored;
static unsigned int audio_setup_after[5];
static bool audio_write_armed;
static u8 audio_write_reg, audio_write_value;
module_param(audio_setup_attempted,uint,0444);
module_param(audio_setup_verified,uint,0444);
module_param(audio_setup_restored,uint,0444);
module_param_array(audio_setup_after,uint,NULL,0444);
static unsigned int audio_notifications, audio_candidates, audio_changed, audio_slot_changed;
static unsigned int audio_capacity_drops, audio_last_slot, audio_before_start, audio_during_stop;
module_param(audio_notifications,uint,0444);
module_param(audio_candidates,uint,0444);
module_param(audio_changed,uint,0444);
module_param(audio_slot_changed,uint,0444);
module_param(audio_capacity_drops,uint,0444);
module_param(audio_last_slot,uint,0444);
module_param(audio_before_start,uint,0444);
module_param(audio_during_stop,uint,0444);
static struct hd60_stream_session stream;
static struct hd60_session session;
/* Evidence about the preceding session, consumed before reconfiguration.
 * Only join_capture sets this after flush_work returns. */
static bool session_worker_joined;
static bool session_setup_started;
static unsigned int restart_attempts, completed_sessions, session_state;
module_param(restart_attempts,uint,0444);
module_param(completed_sessions,uint,0444);
module_param(session_state,uint,0444);
static unsigned long long retained_dma_addresses[13];
module_param_array(retained_dma_addresses,ullong,NULL,0444);
static struct hd60_receiver_session receiver;
static struct hd60_bridge live_bridge;
static struct kthread_work capture_work;
static struct kthread_worker *capture_thread;
static struct pci_dev *bridge_pdev;
static atomic_t stop_requested=ATOMIC_INIT(0);

module_param_named(delivered_frames, stream.delivered_frames,uint,0444);


module_param_named(client_stop_requested, stream.client_stop_requested,bool,0444);
module_param_named(live_interval_ns, stream.live_interval_ns,ullong,0444);
static bool reuse_test;
module_param(reuse_test,bool,0444);
static unsigned int capture_duration_ms=3000;
static bool full_rate_probe;
module_param(full_rate_probe,bool,0444);
MODULE_PARM_DESC(full_rate_probe,"Experimental preview skip0; continuous operation requires reuse_test");
static bool capture_mirror;
module_param(capture_mirror,bool,0444);
MODULE_PARM_DESC(capture_mirror,"Request horizontal mirror in the firmware mode packet (default off)");
module_param(capture_duration_ms,uint,0444);
MODULE_PARM_DESC(capture_duration_ms,"Capture interval: 3000, 30000 or 300000 ms; reuse_test permits 0 until client stop");
#define BUFFER_BYTES HD60_RAW_ALLOCATION
#include "../hd60pro-lifecycle/io_guard.h"
#include "../hd60pro-lifecycle/capture_guard.h"
#include "../hd60pro-lifecycle/mailbox_event.h"
static unsigned int major, minor, acknowledgements;

static bool quarantined, intx_restored, command_pending;
module_param_named(diagnostic_error, stream.diagnostic_error, int, 0444);
module_param_named(finished, stream.finished, bool, 0444);
module_param(quarantined, bool, 0444);
module_param(intx_restored, bool, 0444);
module_param(major, uint, 0444);
module_param(minor, uint, 0444);
struct diagnostic_owner {
 struct pci_dev *pdev;
 void __iomem *bar, *aux;
 struct hd60_capture_guard capture;
 struct hd60_coherent_pool pool;
 void *snapshot;
 void *live_copies, *live_scratch;
 void *audio_copies, *audio_scratch;
 struct debugfs_blob_wrapper audio_blob;
 u64 next_copy_ns;
 struct debugfs_blob_wrapper live_blob;
 struct debugfs_blob_wrapper snapshot_blob;
 struct dentry *snapshot_dir;
 void *channels;
 dma_addr_t channel_address;
 void *extra[8];
 dma_addr_t extra_address[8];
 u64 saved_mask, saved_coherent_mask;
 unsigned int saved_segment;
 bool masks_changed, segment_changed, allocation_attempted;
 bool ordering_changed;
 u16 saved_devctl;
};
static struct diagnostic_owner *active_owner;
static const char *last_stage = "entry";
static void trace_stage(const char *stage) {
 last_stage = stage;
 /* Error priority makes diagnostic markers visible at console_loglevel=3. */
 pr_err("HD60-FRAME-SNAPSHOT stage=%s\n", stage);
}
static unsigned int raw_read32(void *address) { return ioread32((void __iomem *)address); }
static void raw_write32(void *address, unsigned int value)
{ iowrite32(value, (void __iomem *)address); }
static u32 guarded_read32(const void __iomem *address)
{
 if (!active_owner) return ~0U;
 if (active_owner->capture.life.dma_ever_enabled) {
  u32 value;
  if (!hd60_capture_io_allowed(&active_owner->capture)) return ~0U;
  value=raw_read32((void *)address);
  if (address==active_owner->bar+0x30) {
   active_owner->capture.life.pending_event=!!value;
   if(value==~0U) active_owner->capture.life.health=HD60_HEALTH_LOST;
   else if(value&~HD60_INDEXED_AUDIO_ALLOWED_STATUS) active_owner->capture.fault=1;
  }
  return value;
 }
 return hd60_guarded_read(&active_owner->capture.life, (void *)address, raw_read32,
                         active_owner->bar && address == active_owner->bar + 0x30);
}
static void guarded_write32(u32 value, void __iomem *address)
{
 if (active_owner && active_owner->capture.life.dma_ever_enabled) {
  if (hd60_capture_io_allowed(&active_owner->capture)) raw_write32(address,value);
  return;
 }
 if (active_owner)
  hd60_guarded_write(&active_owner->capture.life, (void *)address, raw_write32, value);
}
static int guarded_config_read(struct pci_dev *pdev, int where, u16 *value)
{
 int err;
 if (!active_owner || active_owner->capture.life.health == HD60_HEALTH_LOST) {
  *value = 0xffff;
  return PCIBIOS_DEVICE_NOT_FOUND;
 }
 err = pci_read_config_word(pdev, where, value);
 if (where == PCI_COMMAND) {
  if (active_owner->capture.life.dma_ever_enabled)
   hd60_capture_config(&active_owner->capture,err,*value);
  else hd60_observe_config(&active_owner->capture.life,err,*value);
 }
 return err;
}
/* Keep the raw Linux accessors above these aliases. Every later command,
 * poll and restore path uses the same sticky fault guard.
 */
#define ioread32 guarded_read32
#define iowrite32 guarded_write32
#define pci_read_config_word guarded_config_read
static int acknowledge(void __iomem *bar, void __iomem *aux)
{
 u32 status = ioread32(bar + 0x30);
 if (!status) return 0;
 if (status != 0x800) return status == ~0U ? -ENODEV : -EPROTO;
 iowrite32(2, aux + 0xdc);
 wmb();
 iowrite32(0, bar + 0x30);
 wmb();
 iowrite32(0x400, bar);
 acknowledgements++;
 return read_poll_timeout(ioread32, status, !status || status == ~0U,
                          1000, 100000, false, bar + 0x30) ?: (status ? -ENODEV : 0);
}

static int wait_mailbox_event(void __iomem *bar, u32 *status)
{
 int ret = read_poll_timeout(ioread32, *status, *status != 0,
                             1000, 5000000, false, bar + 0x30);
 if (ret) return ret;
 return *status == 0x800 ? 0 : (*status == ~0U ? -ENODEV : -EPROTO);
}

static int query(void __iomem *bar, void __iomem *aux)
{
 u32 done, status;
 int ret;
 if (ioread32(bar + 0x30)) return -EBUSY;
 iowrite32(0, bar + 0x2c);
 iowrite32(0x0a, bar + 4);
 iowrite32(0, bar + 8);
 iowrite32(0, bar + 12);
 wmb();
 command_pending=true;
 iowrite32(0x800, bar);
 ret = read_poll_timeout(ioread32, done, done == 0xaaaaaaaa || done == ~0U,
                         1000, 500000, false, bar + 0x2c);
 if (ret || done == ~0U) return ret ?: -ENODEV;
 major = ioread32(bar + 8); minor = ioread32(bar + 12);
 ret = wait_mailbox_event(bar, &status);
 if (ret) return ret;
 ret = acknowledge(bar, aux);
 if (ret) return ret;
 command_pending=false;
 return major == 1 && minor == 11 ? 0 : -EPROTO;
}

static bool register_event, buffer_freed, iommu_mapping;
static unsigned int buffers_allocated, register_status;
static unsigned long long addresses[4];
module_param(register_event, bool, 0444);
module_param_named(stop_event, stream.stop_event, bool, 0444);
module_param_named(version_after, stream.version_after, bool, 0444);
module_param(buffer_freed, bool, 0444);
module_param(iommu_mapping, bool, 0444);
module_param(command_pending, bool, 0444);
module_param(buffers_allocated, uint, 0444);
module_param(register_status, uint, 0444);
module_param_named(stop_status, stream.stop_status, uint, 0444);
module_param_array(addresses, ullong, NULL, 0444);


module_param_named(mode_event, stream.mode_event, bool, 0444);
module_param_named(audio_event, stream.audio_event, bool, 0444);
module_param_named(mode_status, stream.mode_status, uint, 0444);
module_param_named(mode_done, stream.mode_done, uint, 0444);
module_param_named(mode_opcode, stream.mode_opcode, uint, 0444);
module_param_named(audio_status, stream.audio_status, uint, 0444);
module_param_named(audio_done, stream.audio_done, uint, 0444);
module_param_named(audio_opcode, stream.audio_opcode, uint, 0444);


module_param_named(preview_attempted, stream.preview_attempted,bool,0444);
module_param_named(preview_event, stream.preview_event,bool,0444);
module_param_named(preview_status, stream.preview_status,uint,0444);
module_param_named(preview_done, stream.preview_done,uint,0444);
/* Local tinyvenc5 efb8/efc4: byte14 disables creation of fake worker.
 * Mask zero preserves processing options. Only channel0 at 60fps.
 * This is an observation experiment, not proof of valid video. */
/* Draft bounded continuous probe. No live buffer copying: frame ownership is
 * released only to discard that frame; immutable export follows STOP/BME-off.
 * Main/sub register windows remain owned until reboot. */


module_param_named(explicit_start_event, stream.explicit_start_event,bool,0444);
static bool encoder_tail_attempted;
module_param_named(encoder_events, stream.encoder_events,uint,0444);
module_param_named(ownership_releases, stream.ownership_releases,uint,0444);
module_param_named(encoded_status_last, stream.encoded_status_last,uint,0444);
module_param(encoder_tail_attempted,bool,0444);
static int register_extra(struct diagnostic_owner *o);
static int configure_encoder(void __iomem *bar, void __iomem *aux)
{
 unsigned int encoder_index,i;
 u32 status,packet[11]={0x2d,0x3fff,0,0x18,0,0,0,0,0,0,0};
 int ret;
 for(encoder_index=0;encoder_index<2;encoder_index++) {
  if(command_pending || ioread32(bar+0x30)) return -EBUSY;
  packet[2]=encoder_index ? 0x1e3c0100 : 0x203c0000;
  packet[4]=encoder_index ? 4000000 : 4194304;
  trace_stage("encoder2d-submit-master-disabled");
  /* Last payload word occupies +2c. Do not clear it after writing payload. */
  encoder_tail_attempted=true;
  for(i=0;i<ARRAY_SIZE(packet);i++) iowrite32(packet[i],bar+4+4*i);
  wmb(); command_pending=true;
  iowrite32(0x800,bar);
  ret=wait_mailbox_event(bar,&status);
  if(ret) return ret;
  if(ioread32(bar+4)!=0x2d) return -EPROTO;
  ret=acknowledge(bar,aux);
  if(ret) return ret;
  command_pending=false; stream.encoder_events++;
 }
 return 0;
}
static int configure_preview(void __iomem *bar, void __iomem *aux)
{
 u32 packet[]={0x31,1,0x00023c00,0x00010001,0,0};
 unsigned int i;
 int ret;
 /* Firmware zero-skip selects its generated all-frame bitmap. Skip1 is not
  * equivalent: the nonzero path requires remainder1. See60fps review. */
 if(full_rate_probe) packet[2]=0x00003c00;
 if(command_pending || ioread32(bar+0x30)) return -EBUSY;
 trace_stage("preview31-submit");
 iowrite32(0,bar+0x2c);
 for(i=0;i<ARRAY_SIZE(packet);i++) iowrite32(packet[i],bar+4+4*i);
 wmb(); stream.preview_attempted=true; command_pending=true;
 iowrite32(0x800,bar);
 ret=wait_mailbox_event(bar,&stream.preview_status);
 if(ret) return ret;
 stream.preview_done=ioread32(bar+0x2c);
 if(ioread32(bar+4)!=0x31) return -EPROTO;
 ret=acknowledge(bar,aux);
 if(ret) return ret;
 command_pending=false; stream.preview_event=true;
 return 0;
}
static int first_capture(struct diagnostic_owner *o);
static int mode_only(void __iomem *bar, void __iomem *aux)
{
 const u32 packet[] = {
  /* video_capture_mgr packet byte14 is mirror; byte13 is flip. */
  0x29, 0x06073c00, 0x04380780, capture_mirror ? 0x00010000 : 0, 0,
  0, 0x04380780, 1, 0, 0x01010100
 };
 unsigned int i;
 int ret;
 if(ioread32(bar+0x30)) return -EBUSY;
 trace_stage("mode29-submit");
 iowrite32(0,bar+0x2c);
 for(i=0;i<ARRAY_SIZE(packet);i++) iowrite32(packet[i],bar+4+4*i);
 wmb();
 command_pending=true;
 iowrite32(0x800,bar);
 ret=wait_mailbox_event(bar,&stream.mode_status);
 if(ret) return ret; /* Never overwrite a timed-out command with STOP. */
 stream.mode_done=ioread32(bar+0x2c);
 stream.mode_opcode=ioread32(bar+4);
 if(stream.mode_opcode!=0x29) return -EPROTO;
 ret=acknowledge(bar,aux);
 if(ret) return ret;
 stream.mode_event=true; command_pending=false;
 /* Windows 28a110 stores frequency, 28a165 stores packed periods.
  * Audio probe uses on=1, product5 stereo, F=120/B=4. It may launch
  * capture_app_infinite; this build is single-use and retains every mapping.
  * Acknowledgement is still mandatory before any subsequent command.
  */
 trace_stage("mode29-ack-audio2a-submit");
 {
  /* Packet byte4=index0, byte5=channels2, bytes6..7=bits16,
   * byte8..11=rate48000, bytes12..15=F120/B4, byte16=enable1.
   * audio_capture_mgr89f4 selects index;8a54/8a64 stores byte16;
   * 8b04..8b0c requires that byte to equal1 before helper launch. */
  static const u32 audio[] = {0x2a, 0x00100200, 0x0000bb80, 0x00040078, 0x101};
  if(ioread32(bar+0x30)) return -EBUSY;
  iowrite32(0,bar+0x2c);
  for(i=0;i<ARRAY_SIZE(audio);i++) iowrite32(audio[i],bar+4+4*i);
  wmb(); command_pending=true;
  iowrite32(0x800,bar);
  ret=wait_mailbox_event(bar,&stream.audio_status);
  if(ret) return ret;
  stream.audio_done=ioread32(bar+0x2c);
  stream.audio_opcode=ioread32(bar+4);
  if(stream.audio_opcode!=0x2a) return -EPROTO;
  ret=acknowledge(bar,aux);
  if(ret) return ret;
  stream.audio_event=true; command_pending=false;
 }
 /* Firmware process replacement may reset its encoded-window state. Reuse
  * the same owned allocations, never introduce new physical addresses here. */
 ret=register_extra(active_owner);
 if(ret) return ret;
 ret=configure_encoder(bar,aux);
 if(ret) return ret;
 return configure_preview(bar,aux);
}



module_param_named(gpio8_before, receiver.gpio8_before,uint,0444);
module_param_named(gpio8_low, receiver.gpio8_low,uint,0444);
module_param_named(gpio8_final, receiver.gpio8_final,uint,0444);
module_param_named(gpio8_attempted, receiver.gpio8_attempted,bool,0444);
module_param_named(gpio8_verified, receiver.gpio8_verified,bool,0444);
module_param_named(gpio8_restored, receiver.gpio8_restored,bool,0444);



module_param_named(restored, receiver.restored, bool, 0444);
module_param_named(steps, receiver.steps, uint, 0444);
module_param_named(restored_level, receiver.restored_level, uint, 0444);
module_param_named(gpio9, receiver.gpio9, uint, 0444);
module_param_named(read_count, receiver.read_count, uint, 0444);
module_param_named(accepted_mask, receiver.accepted_mask, uint, 0444);
module_param_array_named(values, receiver.values, uint, NULL, 0444);
module_param_named(baseline_complete, receiver.baseline_complete, bool, 0444);







module_param_array_named(metadata, receiver.metadata, uint, NULL, 0444);
module_param_named(metadata_mask, receiver.metadata_mask, uint, 0444);
module_param_named(bank_attempted, receiver.bank_attempted, bool, 0444);
module_param_named(bank_restored, receiver.bank_restored, bool, 0444);
module_param_named(bank_restore_error, receiver.bank_restore_error, int, 0444);
module_param_named(source_before, receiver.source_before, uint, 0444);
module_param_named(source_after, receiver.source_after, uint, 0444);
module_param_named(source_restored_value, receiver.source_restored_value, uint, 0444);
module_param_named(source_attempted, receiver.source_attempted, bool, 0444);
module_param_named(source_verified, receiver.source_verified, bool, 0444);
module_param_named(source_restored, receiver.source_restored, bool, 0444);

module_param_named(source_restore_error, receiver.source_restore_error, int, 0444);
/* Only GPIO9 levels and the two bounded source-register values are writable. */


module_param_named(reg13_before, receiver.reg13_before, uint, 0444);
module_param_named(reg13_after, receiver.reg13_after, uint, 0444);
module_param_named(reg13_final, receiver.reg13_final, uint, 0444);
module_param_named(reg13_attempted, receiver.reg13_attempted, bool, 0444);
module_param_named(reg13_verified, receiver.reg13_verified, bool, 0444);
module_param_named(reg13_restored, receiver.reg13_restored, bool, 0444);

module_param_array_named(output_snapshot, receiver.output_snapshot, uint, NULL, 0444);
module_param_named(output_snapshot_count, receiver.output_snapshot_count, uint, 0444);


module_param_named(output_b0_before, receiver.output_b0_before, uint, 0444);
module_param_named(output_b0_after, receiver.output_b0_after, uint, 0444);
module_param_named(output_b0_final, receiver.output_b0_final, uint, 0444);
module_param_named(output_b0_attempted, receiver.output_b0_attempted, bool, 0444);
module_param_named(output_b0_verified, receiver.output_b0_verified, bool, 0444);
module_param_named(output_b0_restored, receiver.output_b0_restored, bool, 0444);
static bool test_coefficients=true;

module_param(test_coefficients, bool, 0444);
module_param_named(coefficients_attempted, receiver.coefficients_attempted, bool, 0444);
module_param_named(coefficients_verified, receiver.coefficients_verified, bool, 0444);
module_param_named(coefficients_restored, receiver.coefficients_restored, bool, 0444);
module_param_named(coefficient_writes, receiver.coefficient_writes, uint, 0444);
module_param_named(coefficient_restores, receiver.coefficient_restores, uint, 0444);
static unsigned int csc_profile;
module_param(csc_profile,uint,0444);
static const struct { u8 reg, value; } coefficient_plan[] = {
 {0x9c,0x9f},
 {0x9b,0x0b},
 {0x96,0x74},
 {0x95,0x03},
 {0xa2,0x2c},
 {0xa1,0x01},
 {0x9a,0x94},
 {0x99,0x78},
 {0x94,0x2d},
 {0x93,0x08},
 {0xa0,0x40},
 {0x9f,0x7f},
 {0x9e,0xb3},
 {0x9d,0x79},
 {0x98,0x22},
 {0x97,0x7e},
 {0xa4,0x2d},
 {0xa3,0x08},
 {0xa6,0x00},
 {0xa5,0x20},
 {0xa8,0x00},
 {0xa7,0x00},
 {0xaa,0x00},
 {0xa9,0x20}
};
static bool test_output_activation=true;
module_param(test_output_activation, bool, 0444);



module_param_named(final_gate_value, receiver.final_gate_value,uint,0444);
module_param_named(final_gate_read, receiver.final_gate_read,bool,0444);
module_param_named(activation_lock, receiver.activation_lock, uint, 0444);
static bool test_output_prefix=true;

module_param(test_output_prefix, bool, 0444);
module_param_named(prefix_attempted, receiver.prefix_attempted, bool, 0444);
module_param_named(prefix_verified, receiver.prefix_verified, bool, 0444);
module_param_named(prefix_restored, receiver.prefix_restored, bool, 0444);
module_param_named(prefix_writes, receiver.prefix_writes, uint, 0444);
module_param_named(prefix_restores, receiver.prefix_restores, uint, 0444);
static const struct { u8 reg, value; } prefix_plan[] = {
 {0xab,0x80},{0x90,0x15},{0x91,0x15},{0x92,0x40},
 {0xab,0x95},{0xac,0x15},{0xad,0x05},{0x1e,0x11},{0x1f,0x01}
};
static const u8 prefix_restore_regs[]={0x90,0x91,0x92,0xac,0xad,0x1e,0x1f,0xab};
/* Groups verified by init-register-transaction/run-rE6zWJpw and control-transaction/run-gJfQVMWt. */


module_param_named(init_writes_attempted, receiver.init_writes_attempted,uint,0444);
module_param_named(init_writes_verified, receiver.init_writes_verified,uint,0444);
module_param_named(init_restores, receiver.init_restores,uint,0444);
module_param_named(init_restored, receiver.init_restored,bool,0444);
/* B7=02 loses live lock (run-RXA62xqG); retain its working zero value. */
static const struct { u8 reg, value, original; } init_plan[] = {
 {0x64,2,1}, {0x65,0xff,0}, {0x67,2,0},
 {0xb0,0x14,0}, {0xae,4,0}, {0xad,5,0}, {0xb1,0xc0,0},
 {0xb2,0,0}, {0xb4,0x55,0x80}, {0xb4,0x54,0x80}
};
static bool init_write_allowed(u32 reg,u32 value)
{
 unsigned int i;
 if(!receiver.init_writes_attempted) return false;
 for(i=0;i<ARRAY_SIZE(init_plan);i++)
  if(reg==init_plan[i].reg && (value==init_plan[i].value || value==init_plan[i].original)) return true;
 return false;
}
static u8 coefficient_value(unsigned int i)
{
 return hd60_csc_coefficient(csc_profile,i,coefficient_plan[i].value);
}
static u8 prefix_value(unsigned int i)
{
 return csc_profile==2 && prefix_plan[i].reg==0x92 ? 0x62 : prefix_plan[i].value;
}
static bool prefix_write_allowed(u32 reg, u32 value)
{
 unsigned int i;
 if (!(test_output_prefix || test_output_activation) || !receiver.prefix_attempted) return false;
 for (i=0;i<ARRAY_SIZE(prefix_plan);i++)
  if (reg==prefix_plan[i].reg && (value==0 || value==prefix_value(i))) return true;
 return false;
}
static bool coefficient_write_allowed(u32 reg, u32 value)
{
 unsigned int i;
 if (!(test_coefficients || test_output_prefix || test_output_activation) || !receiver.coefficients_attempted) return false;
 for (i=0; i<ARRAY_SIZE(coefficient_plan); i++)
  if (reg == coefficient_plan[i].reg)
   return value == 0 || value == coefficient_value(i);
 return false;
}

module_param_named(page1_changed, receiver.page1_changed,uint,0444);
module_param_named(page1_writes, receiver.page1_writes,uint,0444);
module_param_named(page1_restores, receiver.page1_restores,uint,0444);
static const u8 page1_pages[]={1,1,1,1,2,1,2};
static const u8 page1_regs[]={0x16,0x1a,0x2a,0x30,8,0x24,0x27};
static const u8 page1_before[]={0x10,2,0,0,0,0,0xff},page1_after[]={0x30,0x50,7,0x80,3,0x41,0};
/* Windows 14027844c..493; status acknowledgement, not restorable config. */
/* Windows 140278312..407. Indexed port effects are NOT rolled back. */
static bool port_touched;


module_param_named(handoff_attempted, receiver.handoff_attempted,bool,0444);
module_param_named(handoff_completed, receiver.handoff_completed,bool,0444);
module_param_named(handoff_gates_restored, receiver.handoff_gates_restored,bool,0444);
module_param(port_touched,bool,0444);
module_param_named(handoff_writes, receiver.handoff_writes,uint,0444);
module_param_named(handoff_poll_count, receiver.handoff_poll_count,uint,0444);
module_param_named(handoff_poll_value, receiver.handoff_poll_value,uint,0444);


module_param_named(status_before, receiver.status_before,uint,0444);
module_param_named(status_after, receiver.status_after,uint,0444);
module_param_named(status_ack_count, receiver.status_ack_count,uint,0444);
module_param_named(status_ack_clear, receiver.status_ack_clear,bool,0444);
module_param_named(post_ack_lock, receiver.post_ack_lock,uint,0444);


module_param_named(pulse_attempted, receiver.pulse_attempted,bool,0444);
module_param_named(pulse_cleared, receiver.pulse_cleared,bool,0444);
module_param_named(pulse_restored, receiver.pulse_restored,bool,0444);
module_param_named(pulse_before, receiver.pulse_before,uint,0444);
module_param_named(pulse_high_read, receiver.pulse_high_read,uint,0444);
module_param_named(pulse_after, receiver.pulse_after,uint,0444);
module_param_named(pulse_final, receiver.pulse_final,uint,0444);


module_param_named(latch_attempted, receiver.latch_attempted,bool,0444);
module_param_named(latch_cleared, receiver.latch_cleared,bool,0444);
module_param_named(latch_before, receiver.latch_before,uint,0444);
module_param_named(latch_high_read, receiver.latch_high_read,uint,0444);
module_param_named(latch_final, receiver.latch_final,uint,0444);


module_param_named(core_changed, receiver.core_changed,uint,0444);
module_param_named(core_writes, receiver.core_writes,uint,0444);
module_param_named(core_restores, receiver.core_restores,uint,0444);
module_param_array_named(core_before, receiver.core_before,uint,NULL,0444);
module_param_array_named(core_after, receiver.core_after,uint,NULL,0444);
static const u8 core_pages[]={2,2,2,2,0,0,0x80,0x80};
static const u8 core_regs[]={1,4,6,9,0x54,0xac,0xce,0xcf};
static const u8 core_expected[]={0,0,0,8,0x30,0x15,0,0};
static const u8 core_values[]={0x60,1,8,0x28,0x20,0x95,0x80,2};
static bool core_write_allowed(u32 reg,u32 value)
{
 unsigned int i;
 for(i=0;i<ARRAY_SIZE(core_regs);i++)
  if((receiver.core_changed&BIT(i)) && reg==core_regs[i] &&
     (value==core_expected[i] || value==core_values[i])) return true;
 return false;
}
static void __iomem *receiver_aux;

static int read_command(void __iomem *bar, u32 opcode, u32 a, u32 b)
{
 u32 done;
 u16 command;
 int ret;
 if (guarded_config_read(active_owner->pdev, PCI_COMMAND, &command) ||
     !hd60_io_allowed(&active_owner->capture.life)) return -ENODEV;
 if (opcode != 0x14 && opcode != 0x1a && opcode != 0x15 && opcode != 0x1b) return -EPERM;
 if (opcode == 0x1b) {
  u32 value = ioread32(bar + 16);
  if (a != 0x9c) return -EPERM;
  if (!((b == 0x51 && (value == 0x03 || value == 0x89)) ||
        (audio_write_armed && b==audio_write_reg && value==audio_write_value) ||
        (receiver.handoff_write_armed && b==receiver.handoff_reg && value==receiver.handoff_value) ||
        (receiver.status_ack_armed && b==0x0e && value==receiver.status_ack_value && value<=255) ||
        (receiver.pulse_attempted && b==7 && (value==0 || value==4 || value==0xf4)) ||
        (receiver.latch_attempted && b==0xb8 && (value==0 || value==0x10)) ||
        (b == 0x13 && (value == 0 || value == 8)) ||
        (b == 0x00 && (value <= 2 || value==0x80)) ||
        (receiver.page1_changed && ((b==0x16 && (value==0x10 || value==0x30)) ||
         (b==0x1a && (value==2 || value==0x50)) || (b==0x2a && (value==0 || value==7)) || (b==0x30 && (value==0 || value==0x80)) || (b==8 && (value==0 || value==3)) || (b==0x24 && (value==0 || value==0x41)) || (b==0x27 && (value==0 || value==0xff)))) || core_write_allowed(b,value) || coefficient_write_allowed(b, value) || prefix_write_allowed(b, value) || init_write_allowed(b,value) ||
        (test_output_activation && receiver.output_b0_attempted && b == 0xb0 &&
         (value == 0 || value == 0x21)))) return -EPERM;
 }
 if (opcode == 0x15 && ((a != BIT(8) && a != BIT(9)) || (b != 0 && b != a))) return -EPERM;
 if (ioread32(bar + 0x30)) return -EBUSY;
 iowrite32(0, bar + 0x2c);
 iowrite32(opcode, bar + 4);
 iowrite32(a, bar + 8);
 iowrite32(b, bar + 12);
 wmb();
 command_pending=true;
 iowrite32(0x800, bar);
 ret = read_poll_timeout(ioread32, done, (done & 1) || done == ~0U,
                         1000, 500000, false, bar + 0x2c);
 if (ret || done == ~0U) { active_owner->capture.life.health = HD60_HEALTH_LOST; return ret ?: -ENODEV; }
 if (!ret) ret = acknowledge(bar, receiver_aux);
 if (!ret) command_pending=false;
 return ret;
}

static int receiver_byte(void __iomem *bar, u8 reg, unsigned int *value)
{
 u32 tagged;
 int ret;
 iowrite32(0xa55a003c, bar + 16);
 ret = read_command(bar, 0x1a, 0x9c, reg);
 if (ret) return ret;
 tagged = ioread32(bar + 16);
 if ((tagged & 0xffffff00) != 0xa55a0000) return -EIO;
 *value = tagged & 255;
 return 0;
}

static int source_write(void __iomem *bar, u8 value)
{
 if (value != 0x03 && value != 0x89) return -EPERM;
 iowrite32(value, bar + 16);
 return read_command(bar, 0x1b, 0x9c, 0x51);
}

static int select_bank(void __iomem *bar, u8 page)
{
 unsigned int actual;
 int ret;
 if (page > 2 && page != 0x80) return -EPERM;
 receiver.bank_attempted = true;
 iowrite32(page, bar + 16);
 ret = read_command(bar, 0x1b, 0x9c, 0x00);
 if (!ret) ret = receiver_byte(bar, 0x00, &actual);
 if (!ret && actual != page) ret = -EIO;
 return ret;
}

static int page1_write(void __iomem *bar,u8 expected_bank,u8 reg,u8 value)
{
 unsigned int bank,actual;
 int ret=receiver_byte(bar,0,&bank);
 if(ret || bank!=expected_bank) return ret ?: -EPROTO;
 iowrite32(value,bar+16);
 ret=read_command(bar,0x1b,0x9c,reg);
 if(!ret) ret=receiver_byte(bar,reg,&actual);
 return ret ?: (actual==value ? 0 : -EIO);
}
static int audio_setup_write(void __iomem *bar,unsigned int index,bool restore)
{
 int ret;
 if(index>=ARRAY_SIZE(audio_setup_index)) return -EINVAL;
 audio_write_reg=audio_receiver_regs[audio_setup_index[index]];
 audio_write_value=restore ? audio_setup_before[index] : audio_setup_target[index];
 audio_write_armed=true;
 ret=page1_write(bar,2,audio_write_reg,audio_write_value);
 audio_write_armed=false;
 return ret;
}
static int handoff_write(void __iomem *bar,u8 bank,u8 reg,u8 value,bool indexed)
{
 int ret=select_bank(bar,bank);
 if(ret) return ret;
 if(!((bank==0 && reg==0xab && (value==0 || value==0x80)) ||
      (bank==0 && reg==0xb3 && (value==0 || value==0xff)) ||
      (bank==2 && reg==0x27 && (value==0 || value==0xff)) ||
      (bank==1 && reg==0x24 && value==0x41) ||
      (bank==1 && reg>=0x25 && reg<=0x27 && value==0))) return -EPERM;
 receiver.handoff_reg=reg; receiver.handoff_value=value; receiver.handoff_write_armed=true;
 if(indexed) {
  /* Do not read data port as a readback or pretend its contents are restored. */
  port_touched=true;
  iowrite32(value,bar+16);
  ret=read_command(bar,0x1b,0x9c,reg);
 } else ret=page1_write(bar,bank,reg,value);
 receiver.handoff_write_armed=false;
 if(!ret) receiver.handoff_writes++;
 return ret;
}
static int receiver_handoff(void __iomem *bar)
{
 static const u8 banks[]={0,0,2,1};
 static const u8 regs[]={0xab,0xb3,0x27,0x24};
 static const u8 expected[]={0,0,0,0x41};
 unsigned int i,value;
 int ret;
 for(i=0;i<ARRAY_SIZE(regs);i++) {
  ret=select_bank(bar,banks[i]);
  if(!ret) ret=receiver_byte(bar,regs[i],&value);
  if(ret || value!=expected[i]) return ret ?: -EPROTO;
 }
 receiver.handoff_attempted=true;
 ret=handoff_write(bar,0,0xab,0x80,false);
 if(!ret) ret=handoff_write(bar,2,0x27,0xff,false);
 if(!ret) ret=handoff_write(bar,0,0xb3,0xff,false);
 if(!ret) ret=handoff_write(bar,1,0x24,0x41,false);
 if(!ret) ret=handoff_write(bar,1,0x25,0,true);
 if(!ret) ret=handoff_write(bar,1,0x26,0,true);
 for(i=0;!ret && i<5;i++) ret=handoff_write(bar,1,0x27,0,true);
 if(!ret) ret=handoff_write(bar,0,0xab,0,false);
 if(!ret) ret=handoff_write(bar,2,0x27,0,false);
 if(!ret) ret=handoff_write(bar,0,0xb3,0,false);
 if(ret) return ret;
 receiver.handoff_completed=true;
 ret=select_bank(bar,2);
 for(i=0;!ret && i<10;i++) {
  ret=receiver_byte(bar,0x0e,&receiver.handoff_poll_value);
  if(ret) break;
  receiver.handoff_poll_count++;
  if(receiver.handoff_poll_value&7) break;
  msleep(5);
 }
 return ret;
}
static int receiver_baseline(void __iomem *bar, bool preflight_only)
{
 int ret, restore_ret;
 unsigned int i, sample, bank;
 static const u32 levels[] = { BIT(9), 0, BIT(9) };
 static const u8 regs[] = {0x55,0x6a,0x6b,0x57,0x58,0x59,0x5a,0x5b,0x5c,0x5f};
 if(preflight_only && (active_owner->capture.life.registered_buffers ||
    active_owner->capture.life.dma_ever_enabled)) return -EINVAL;
 input_status=HD60_INPUT_UNCHECKED;
 if (major != 1 || minor != 11) return -EPROTO;
 ret = read_command(bar, 0x14, BIT(9), 0);
 if (ret) return ret;
 receiver.gpio9 = !!(ioread32(bar + 12) & BIT(9));
 /* This test is only validated for the observed low starting state. */
 if (receiver.gpio9) return -EAGAIN;
 ret=read_command(bar,0x14,BIT(8),0);
 if(ret) return ret;
 receiver.gpio8_before=!!(ioread32(bar+12)&BIT(8));
 if(!receiver.gpio8_before) return -EAGAIN;
 trace_stage("GPIO9-wake");
 for (i = 0; i < ARRAY_SIZE(levels); i++) {
  receiver.steps++;
  ret = read_command(bar, 0x15, BIT(9), levels[i]);
  if (ret) goto restore;
  msleep(50);
 }
 receiver.gpio8_attempted=true;
 ret=read_command(bar,0x15,BIT(8),0);
 if(!ret) ret=read_command(bar,0x14,BIT(8),0);
 if(ret) goto restore;
 receiver.gpio8_low=!!(ioread32(bar+12)&BIT(8));
 receiver.gpio8_verified=!receiver.gpio8_low;
 if(!receiver.gpio8_verified) { ret=-EIO; goto restore; }
 msleep(50);
 ret = receiver_byte(bar, 0x00, &bank);
 if (ret) goto restore;
 if (bank != 0) { ret = -EPROTO; goto restore; }
 ret=select_bank(bar,1);
 if(ret) goto restore;
 for(i=0;i<ARRAY_SIZE(page1_regs);i++) {
  unsigned int actual;
  ret=select_bank(bar,page1_pages[i]);
  if(ret) goto restore;
  ret=receiver_byte(bar,page1_regs[i],&actual);
  if(ret || actual!=page1_before[i]) { ret=ret ?: -EPROTO; goto restore; }
 }
 for(i=0;i<ARRAY_SIZE(page1_regs);i++) {
  ret=select_bank(bar,page1_pages[i]);
  if(ret) goto restore;
  receiver.page1_changed|=BIT(i);
  ret=page1_write(bar,page1_pages[i],page1_regs[i],page1_after[i]);
  if(ret) goto restore;
  receiver.page1_writes++;
 }
 ret=select_bank(bar,0);
 if(ret) goto restore;
 ret = receiver_byte(bar, 0x51, &receiver.source_before);
 if (ret) goto restore;
 if (receiver.source_before != 0x03) { ret = -EPROTO; goto restore; }
 trace_stage("source51-write");
 receiver.source_attempted = true; /* Restore even if command completion times out. */
 ret = source_write(bar, 0x89);
 if (ret) goto restore;
 ret = receiver_byte(bar, 0x51, &receiver.source_after);
 if (ret) goto restore;
 if (receiver.source_after != 0x89) { ret = -EIO; goto restore; }
 receiver.source_verified = true;
 ret = receiver_byte(bar, 0x13, &receiver.reg13_before);
 if (ret) goto restore;
 if (receiver.reg13_before != 0) { ret = -EPROTO; goto restore; }
 trace_stage("reg13-write");
 receiver.reg13_attempted = true;
 iowrite32(8, bar + 16);
 ret = read_command(bar, 0x1b, 0x9c, 0x13);
 if (!ret) ret = receiver_byte(bar, 0x13, &receiver.reg13_after);
 if (!ret && receiver.reg13_after != 8) ret = -EIO;
 if (ret) goto restore;
 receiver.reg13_verified = true;
 trace_stage("reg13-verified-timing-reads");

 msleep(50);
 for (sample = 0; sample < 3; sample++) {
 if (sample) msleep(sample == 1 ? 950 : 2000);
 for (i = 0; i < ARRAY_SIZE(regs); i++) {
  iowrite32(0xa55a003c, bar + 16);
  ret = read_command(bar, 0x1a, 0x9c, regs[i]);
  if (ret) goto restore;
  receiver.values[sample * 10 + i] = ioread32(bar + 16);
  receiver.read_count++;
  if ((receiver.values[sample * 10 + i] & 0xffffff00) != 0xa55a0000) {
   ret = -EIO;
   goto restore;
  }
  receiver.accepted_mask |= BIT(sample * 10 + i);
 }
 }
 {
  static const u8 pages[] = {2,2,2,2,2,2,1,1,2,2};
  static const u8 regs_meta[] = {0x29,0x28,0x0b,0x0c,0x0e,0x48,0x01,0x34,0x49,0x4a};
  for (i = 0; i < ARRAY_SIZE(regs_meta); i++) {
   ret = select_bank(bar, pages[i]);
   if (ret) goto restore;
   ret = receiver_byte(bar, regs_meta[i], &receiver.metadata[i]);
   if (ret) goto restore;
   receiver.metadata_mask |= BIT(i);
  }
 }
 receiver.baseline_complete = true;
 /* Only the measured 1920-wide, 1080 vertical-field, progressive input. */
 input_status=hd60_input_classify(receiver.values[20],receiver.metadata[0],
  receiver.metadata[1],receiver.values[27],receiver.values[28],receiver.values[29]);
 if(input_status!=HD60_INPUT_ACCEPTED) {
  ret=input_status==HD60_INPUT_NO_LOCK ? -ENOLINK : -EOPNOTSUPP;
  goto restore;
 }
 /* Preflight uses the same bounded wake/read/restore transaction, but never
  * enters output setup, mode submission or capture. No addresses registered. */
 if(preflight_only) goto restore;
 ret = select_bank(bar, 0);
 if (ret) goto restore;
 ret = receiver_byte(bar, 0xb0, &receiver.output_b0_before);
 if (ret) goto restore;
 pr_err("HD60-ISOLATED B0=0x%02x (not written)\n", receiver.output_b0_before);
 trace_stage("B0-read-only-complete");
 {
  static const u8 output_regs[] = {
   0xab,0x90,0x91,0x92,0xac,0xad,0x1e,0x1f,0xb0,
   0x93,0x94,0x95,0x96,0x97,0x98,0x99,0x9a,
   0x9b,0x9c,0x9d,0x9e,0x9f,0xa0,0xa1,0xa2,
   0xa3,0xa4,0xa5,0xa6,0xa7,0xa8,0xa9,0xaa
  };
  trace_stage("output-snapshot-read-only");
  for (i = 0; i < ARRAY_SIZE(output_regs); i++) {
   ret = receiver_byte(bar, output_regs[i], &receiver.output_snapshot[i]);
   if (ret) goto restore;
   receiver.output_snapshot_count++;
   pr_err("HD60-ISOLATED output snapshot reg=%02x value=%02x\n",
          output_regs[i], receiver.output_snapshot[i]);
  }
 }
 trace_stage("output-snapshot-complete");
 if (test_coefficients || test_output_prefix || test_output_activation) {
  unsigned int actual;
  /* Only the measured all-zero output state; no B0 activation. */
  for (i=0; i<ARRAY_SIZE(receiver.output_snapshot); i++)
   if (receiver.output_snapshot[i]) { ret=-EPROTO; goto restore; }
  csc_profile=hd60_csc_profile(receiver.metadata[4],receiver.metadata[5],
                              receiver.metadata[8],receiver.metadata[9]);
  if (!csc_profile) {
   ret=-EPROTO; goto restore;
  }
  /* Snapshot before changing any of the additional registers. B3 stays
   * untouched; its descriptor-dependent Windows branch is not resolved. */
  for(i=0;i<ARRAY_SIZE(init_plan);i++) {
   ret=receiver_byte(bar,init_plan[i].reg,&actual);
   if(ret) goto restore;
   if(actual!=init_plan[i].original) { ret=-EPROTO; goto restore; }
  }
  trace_stage("verified-init-group-write");
  for(i=0;i<ARRAY_SIZE(init_plan);i++) {
   receiver.init_writes_attempted++;
   iowrite32(init_plan[i].value,bar+16);
   ret=read_command(bar,0x1b,0x9c,init_plan[i].reg);
   if(!ret) ret=receiver_byte(bar,init_plan[i].reg,&actual);
   if(!ret && actual!=init_plan[i].value) ret=-EIO;
   if(ret) goto restore;
   receiver.init_writes_verified++;
  }
  if (test_output_prefix || test_output_activation) {
   receiver.prefix_attempted=true;
   trace_stage("output-prefix-write-readback");
   for (i=0;i<ARRAY_SIZE(prefix_plan);i++) {
    iowrite32(prefix_value(i),bar+16);
    ret=read_command(bar,0x1b,0x9c,prefix_plan[i].reg);
    if (ret) goto restore;
    receiver.prefix_writes++;
    ret=receiver_byte(bar,prefix_plan[i].reg,&actual);
    if (!ret && actual != prefix_value(i)) ret=-EIO;
    if (ret) goto restore;
   }
   receiver.prefix_verified=true;
  }
  receiver.coefficients_attempted=true;
  trace_stage("coefficient-write-readback");
  for (i=0; i<ARRAY_SIZE(coefficient_plan); i++) {
   iowrite32(coefficient_value(i), bar+16);
   ret=read_command(bar,0x1b,0x9c,coefficient_plan[i].reg);
   if (ret) break;
   receiver.coefficient_writes++;
   ret=receiver_byte(bar,coefficient_plan[i].reg,&actual);
   if (!ret && actual != coefficient_value(i)) ret=-EIO;
   if (ret) break;
  }
  receiver.coefficients_verified=!ret;
  if (!ret && test_output_activation) {
   /* Exact terminal writes of reviewed 1080p Windows output sequence. */
   receiver.output_b0_attempted=true;
   trace_stage("output-B0-activation");
   iowrite32(0x21,bar+16);
   ret=read_command(bar,0x1b,0x9c,0xb0);
   if (!ret) ret=receiver_byte(bar,0xb0,&receiver.output_b0_after);
   if (!ret && receiver.output_b0_after != 0x21) ret=-EIO;
   if (ret) goto restore;
   receiver.output_b0_verified=true;
   trace_stage("output-final-AB");
   iowrite32(0,bar+16);
   ret=read_command(bar,0x1b,0x9c,0xab);
   if (!ret) ret=receiver_byte(bar,0xab,&actual);
   if (!ret && actual) ret=-EIO;
   if (ret) goto restore;
   msleep(100);
   ret=receiver_byte(bar,0x55,&receiver.activation_lock);
   trace_stage("output-activation-observed");
  }
 }
 if (!ret) {
  if ((receiver.activation_lock & 0x7f) != 0x7f) ret=-ENOLINK;
  else {
   /* Check the gate AFTER source selection and output initialization. */
   ret=select_bank(bar,2);
   if (!ret) ret=receiver_byte(bar,0x27,&receiver.final_gate_value);
   if (!ret) receiver.final_gate_read=true;
   if (!ret) ret=select_bank(bar,0);
   if (ret) goto restore;
   if (receiver.final_gate_value != 0) { ret=-EPROTO; goto restore; }
   /* Verified HDMI core group after CSC; AC retains CSC bits (15|80=95). */
   for(i=0;i<ARRAY_SIZE(core_regs);i++) {
    ret=select_bank(bar,core_pages[i]);
    if(!ret) ret=receiver_byte(bar,core_regs[i],&receiver.core_before[i]);
    if(ret || receiver.core_before[i]!=core_expected[i]) { ret=ret ?: -EPROTO; goto restore; }
   }
   for(i=0;i<ARRAY_SIZE(core_regs);i++) {
    ret=select_bank(bar,core_pages[i]);
    if(ret) goto restore;
    receiver.core_changed|=BIT(i);
    ret=page1_write(bar,core_pages[i],core_regs[i],core_values[i]);
    if(ret) goto restore;
    receiver.core_writes++;
   }
   /* Recheck final values after every core write, before capture. */
   for(i=0;i<ARRAY_SIZE(core_regs);i++) {
    ret=select_bank(bar,core_pages[i]);
    if(!ret) ret=receiver_byte(bar,core_regs[i],&receiver.core_after[i]);
    if(ret || receiver.core_after[i]!=core_values[i]) { ret=ret ?: -EIO; goto restore; }
   }
   ret=select_bank(bar,0);
   if(ret) goto restore;
   msleep(100);
   ret=receiver_byte(bar,0x55,&receiver.activation_lock);
   if(ret || (receiver.activation_lock&0x7f)!=0x7f) { ret=ret ?: -ENOLINK; goto restore; }
   ret=receiver_byte(bar,0xb8,&receiver.latch_before);
   if(ret || receiver.latch_before) { ret=ret ?: -EPROTO; goto restore; }
   receiver.latch_attempted=true;
   iowrite32(0x10,bar+16);
   ret=read_command(bar,0x1b,0x9c,0xb8);
   if(!ret) ret=receiver_byte(bar,0xb8,&receiver.latch_high_read);
   if(ret) goto restore;
   ret=page1_write(bar,0,0xb8,0);
   if(ret) goto restore;
   receiver.latch_cleared=true;
   ret=select_bank(bar,2);
   if(!ret) ret=receiver_byte(bar,7,&receiver.pulse_before);
   if(ret || receiver.pulse_before) { ret=ret ?: -EPROTO; goto restore; }
   receiver.pulse_attempted=true;
   iowrite32(0xf4,bar+16);
   ret=read_command(bar,0x1b,0x9c,7);
   if(!ret) ret=receiver_byte(bar,7,&receiver.pulse_high_read);
   if(ret) goto restore;
   ret=page1_write(bar,2,7,4);
   if(!ret) ret=receiver_byte(bar,7,&receiver.pulse_after);
   if(ret) goto restore;
   receiver.pulse_cleared=true;
   ret=select_bank(bar,0);
   if(ret) goto restore;
   msleep(100);
   ret=receiver_byte(bar,0x55,&receiver.activation_lock);
   if(ret || (receiver.activation_lock&0x7f)!=0x7f) { ret=ret ?: -ENOLINK; goto restore; }
   ret=receiver_handoff(bar);
   if(ret) goto restore;
   ret=select_bank(bar,2);
   if(ret) goto restore;
   for(i=0;i<500;i++) {
    ret=receiver_byte(bar,0x0e,&receiver.status_ack_value);
    if(ret) goto restore;
    if(!i) receiver.status_before=receiver.status_ack_value;
    receiver.status_ack_armed=true;
    iowrite32(receiver.status_ack_value,bar+16);
    ret=read_command(bar,0x1b,0x9c,0x0e);
    receiver.status_ack_armed=false;
    if(ret) goto restore;
    receiver.status_ack_count++;
    ret=receiver_byte(bar,0x0e,&receiver.status_after);
    if(ret) goto restore;
    if(!(receiver.status_after&7)) { receiver.status_ack_clear=true; break; }
    msleep(5);
   }
   if(!receiver.status_ack_clear) { ret=-EAGAIN; goto restore; }
   ret=select_bank(bar,0);
   if(!ret) ret=receiver_byte(bar,0x55,&receiver.post_ack_lock);
   if(ret || (receiver.post_ack_lock&0x7f)!=0x7f) { ret=ret ?: -ENOLINK; goto restore; }
   trace_stage("receiver-active-paired-modes");
   /* Inspect missing audio initialization before mode/helper launch. Restore
    * bank0 only if transport remains healthy; never overwrite a timeout. */
   ret=select_bank(bar,2);
   if(!ret) {
    unsigned int ar;
    for(ar=0;ar<ARRAY_SIZE(audio_receiver_regs);ar++) {
     ret=receiver_byte(bar,audio_receiver_regs[ar],&audio_receiver_values[ar]);
     if(ret) break;
     audio_receiver_reads++;
    }
    /* Require every saved original before changing anything. Only these five
     * Windows-backed values are allowed; mark intent before each write so a
     * failed readback still enters restoration when transport permits it. */
    for(ar=0;!ret && ar<ARRAY_SIZE(audio_setup_index);ar++)
     if(audio_receiver_values[audio_setup_index[ar]]!=audio_setup_before[ar]) ret=-EAGAIN;
    for(ar=0;!ret && ar<ARRAY_SIZE(audio_setup_index);ar++) {
     audio_setup_attempted|=BIT(ar);
     ret=audio_setup_write(bar,ar,false);
     if(!ret) {
      audio_setup_verified|=BIT(ar);
      audio_setup_after[ar]=audio_setup_target[ar];
     }
    }
   }
   if(!command_pending && hd60_io_allowed(&active_owner->capture.life)) {
    int rr=select_bank(bar,0);
    audio_receiver_bank_restored=!rr;
    if(!ret) ret=rr;
   }
   if(ret) goto restore;
   ret=receiver_byte(bar,0x55,&receiver.post_ack_lock);
   if(ret || (receiver.post_ack_lock&0x7f)!=0x7f) { ret=ret ?: -ENOLINK;goto restore; }
   ret=mode_only(bar,receiver_aux);
   if (!ret) ret=first_capture(active_owner);
  }
 }
restore:
 /* No further mailbox traffic after uncertain mode/receiver command. */
 if(command_pending || active_owner->capture.fault ||
    !hd60_io_allowed(&active_owner->capture.life)) return ret ?: -EIO;
 if(audio_setup_attempted) {
  int rr=select_bank(bar,2);
  if(rr) return ret ?: rr;
  for(i=ARRAY_SIZE(audio_setup_index);i>0;i--) {
   if(!(audio_setup_attempted&BIT(i-1))) continue;
   rr=audio_setup_write(bar,i-1,true);
   if(rr) return ret ?: rr;
   audio_setup_restored|=BIT(i-1);
  }
  rr=select_bank(bar,0);
  if(rr) return ret ?: rr;
 }
 if(receiver.handoff_attempted) {
  int rr=handoff_write(bar,0,0xab,0,false);
  if(!rr) rr=handoff_write(bar,2,0x27,0,false);
  if(!rr) rr=handoff_write(bar,0,0xb3,0,false);
  receiver.handoff_gates_restored=!rr;
  if(rr) return ret ?: rr;
 }
 if(receiver.pulse_attempted) {
  int rr=select_bank(bar,2);
  if(!rr) rr=page1_write(bar,2,7,0);
  if(!rr) rr=receiver_byte(bar,7,&receiver.pulse_final);
  receiver.pulse_restored=!rr;
  if(rr) return ret ?: rr;
 }
 if(receiver.latch_attempted) {
  int rr=select_bank(bar,0);
  if(!rr) rr=page1_write(bar,0,0xb8,0);
  if(!rr) rr=receiver_byte(bar,0xb8,&receiver.latch_final);
  receiver.latch_cleared=!rr;
  if(rr) return ret ?: rr;
 }
 if(receiver.core_changed) {
  int rr;
  for(i=ARRAY_SIZE(core_regs);i>0;i--) {
   if(!(receiver.core_changed&BIT(i-1))) continue;
   rr=select_bank(bar,core_pages[i-1]);
   if(!rr) rr=page1_write(bar,core_pages[i-1],core_regs[i-1],core_expected[i-1]);
   if(rr) return ret ?: rr;
   receiver.core_changed&=~BIT(i-1); receiver.core_restores++;
  }
  rr=select_bank(bar,0);
  if(rr) return ret ?: rr;
 }
 if(receiver.page1_changed) {
  int rr=select_bank(bar,1);
  if(rr) return ret ?: rr;
  for(i=ARRAY_SIZE(page1_regs);i>0;i--) {
   if(!(receiver.page1_changed&BIT(i-1))) continue;
   rr=select_bank(bar,page1_pages[i-1]);
   if(rr) return ret ?: rr;
   rr=page1_write(bar,page1_pages[i-1],page1_regs[i-1],page1_before[i-1]);
   if(rr) return ret ?: rr;
   receiver.page1_changed&=~BIT(i-1); receiver.page1_restores++;
  }
  rr=select_bank(bar,0);
  if(rr) return ret ?: rr;
 }
 if (receiver.output_b0_attempted) {
  int rr;
  trace_stage("output-B0-restore-first");
  iowrite32(0,bar+16);
  rr=read_command(bar,0x1b,0x9c,0xb0);
  if (!rr) rr=receiver_byte(bar,0xb0,&receiver.output_b0_final);
  if (!rr && receiver.output_b0_final != receiver.output_b0_before) rr=-EIO;
  receiver.output_b0_restored=!rr;
  if (!ret) ret=rr;
 }

 if (receiver.coefficients_attempted) {
  int rr=0;
  unsigned int actual;
  trace_stage("coefficient-restore");
  for (i=0; i<ARRAY_SIZE(coefficient_plan); i++) {
   iowrite32(0,bar+16);
   rr=read_command(bar,0x1b,0x9c,coefficient_plan[i].reg);
   if (!rr) rr=receiver_byte(bar,coefficient_plan[i].reg,&actual);
   if (!rr && actual) rr=-EIO;
   if (rr) break;
   receiver.coefficient_restores++;
  }
  receiver.coefficients_restored=!rr;
  if (!ret) ret=rr;
 }

 if (receiver.prefix_attempted) {
  int rr=0;
  unsigned int actual;
  trace_stage("output-prefix-restore");
  for (i=0;i<ARRAY_SIZE(prefix_restore_regs);i++) {
   iowrite32(0,bar+16);
   rr=read_command(bar,0x1b,0x9c,prefix_restore_regs[i]);
   if (!rr) rr=receiver_byte(bar,prefix_restore_regs[i],&actual);
   if (!rr && actual) rr=-EIO;
   if (rr) break;
   receiver.prefix_restores++;
  }
  receiver.prefix_restored=!rr;
  if (!ret) ret=rr;
 }
 if(receiver.init_writes_attempted) {
  int rr=0;
  unsigned int actual;
  /* Corrupted/stale transaction counters must never index beyond the plan. */
  if(receiver.init_writes_attempted > ARRAY_SIZE(init_plan)) return -EOVERFLOW;
  trace_stage("verified-init-group-restore");
  for(i=receiver.init_writes_attempted;i>0;i--) {
   if(command_pending || active_owner->capture.fault ||
      !hd60_io_allowed(&active_owner->capture.life)) return ret ?: -EIO;
   iowrite32(init_plan[i-1].original,bar+16);
   rr=read_command(bar,0x1b,0x9c,init_plan[i-1].reg);
   if(!rr) rr=receiver_byte(bar,init_plan[i-1].reg,&actual);
   if(!rr && actual!=init_plan[i-1].original) rr=-EIO;
   if(rr) break;
   receiver.init_restores++;
  }
  receiver.init_restored=!rr && receiver.init_restores==receiver.init_writes_attempted;
  if(!ret) ret=rr;
 }
 trace_stage("receiver-restoration");
 /* Never restore 51 on an unverified bank. GPIO restoration still runs. */
 if (receiver.bank_attempted) {
  receiver.bank_restore_error = select_bank(bar, 0);
  receiver.bank_restored = !receiver.bank_restore_error;
 }
 if (receiver.reg13_attempted && !receiver.bank_restore_error) {
  int rr;
  iowrite32(0, bar + 16);
  rr = read_command(bar, 0x1b, 0x9c, 0x13);
  if (!rr) rr = receiver_byte(bar, 0x13, &receiver.reg13_final);
  if (!rr && receiver.reg13_final != receiver.reg13_before) rr = -EIO;
  receiver.reg13_restored = !rr;
  if (!ret) ret = rr;
 }
 if (receiver.source_attempted && receiver.bank_restore_error) receiver.source_restore_error = receiver.bank_restore_error;
 if (receiver.source_attempted && !receiver.bank_restore_error) {
  receiver.source_restore_error = source_write(bar, 0x03);
  if (!receiver.source_restore_error)
   receiver.source_restore_error = receiver_byte(bar, 0x51, &receiver.source_restored_value);
  if (!receiver.source_restore_error && receiver.source_restored_value != receiver.source_before)
   receiver.source_restore_error = -EIO;
  receiver.source_restored = !receiver.source_restore_error;
 }
 if(receiver.gpio8_attempted) {
  int rr=read_command(bar,0x15,BIT(8),BIT(8));
  if(!rr) rr=read_command(bar,0x14,BIT(8),0);
  if(!rr) {
   receiver.gpio8_final=!!(ioread32(bar+12)&BIT(8));
   receiver.gpio8_restored=receiver.gpio8_final==receiver.gpio8_before;
   if(!receiver.gpio8_restored) rr=-EIO;
  }
  if(rr) return ret ?: rr;
 }
 /* Attempt restoration on every exit after the first GPIO write. */
 restore_ret = read_command(bar, 0x15, BIT(9), 0);
 if (!restore_ret) restore_ret = read_command(bar, 0x14, BIT(9), 0);
 if (!restore_ret) {
  receiver.restored_level = !!(ioread32(bar + 12) & BIT(9));
  receiver.restored = receiver.restored_level == receiver.gpio9;
  if (!receiver.restored) restore_ret = -EIO;
 }
 stream.diagnostic_error = ret ? ret : (receiver.source_restore_error ? receiver.source_restore_error : restore_ret);
 return stream.diagnostic_error;
}




static unsigned int channels_completed;
static bool channels_freed;
module_param(channels_completed, uint, 0444);
module_param(channels_freed, bool, 0444);
#define CHANNEL_BYTES (8U*4U*0x2000U)
static int register_channels(struct diagnostic_owner *o)
{
 u32 packet[11]={3,0,0x2000};
 u32 status;
 unsigned int channel,slot,i;
 int ret;
 trace_stage("channel-allocation");
 o->channels=dma_alloc_coherent(&o->pdev->dev,CHANNEL_BYTES,&o->channel_address,GFP_KERNEL);
 if(!o->channels) return -ENOMEM;
 /* Host-owned initialization BEFORE registration and bus mastering. These
  * are payload destinations, not firmware descriptors. Never refill live. */
 memset(o->channels,AUDIO_SENTINEL,CHANNEL_BYTES);
 dma_wmb();
 o->capture.life.allocated_buffers+=32;
 for(channel=0;channel<8;channel++) {
  if(ioread32(o->bar+0x30)) return -EBUSY;
  packet[1]=channel;
  for(slot=0;slot<4;slot++) {
   dma_addr_t a=o->channel_address+(channel*4+slot)*0x2000;
   packet[3+slot*2]=upper_32_bits(a);
   packet[4+slot*2]=lower_32_bits(a);
  }
  trace_stage("channel-register-submit");
  for(i=0;i<ARRAY_SIZE(packet);i++) iowrite32(packet[i],o->bar+4+i*4);
  wmb(); o->capture.life.registered_buffers+=4; command_pending=true;
  iowrite32(0x800,o->bar);
  ret=wait_mailbox_event(o->bar,&status);
  if(ret) return ret;
  if(ioread32(o->bar+4)!=3) return -EPROTO;
  ret=acknowledge(o->bar,o->aux);
  if(ret) return ret;
  command_pending=false;
  channels_completed++;
 }
 return 0;
}

#define EXTRA_BYTES 0x34bd00U
static unsigned int extra_allocated, extra_registered, extra_freed;
module_param(extra_allocated, uint, 0444);
module_param(extra_registered, uint, 0444);
module_param(extra_freed, uint, 0444);
static int allocate_extra(struct diagnostic_owner *o)
{
 unsigned int i;
 trace_stage("extra-pools-allocation");
 for(i=0;i<8;i++) {
  o->extra[i]=dma_alloc_coherent(&o->pdev->dev,EXTRA_BYTES,&o->extra_address[i],GFP_KERNEL);
  if(!o->extra[i]) return -ENOMEM;
  memset(o->extra[i],0,EXTRA_BYTES);
  extra_allocated++; o->capture.life.allocated_buffers++;
 }
 return 0;
}
static int register_extra(struct diagnostic_owner *o)
{
 unsigned int pool,slot,i;
 u32 status,packet[11]={0,0,EXTRA_BYTES};
 int ret;
 for(pool=0;pool<2;pool++) {
  if(ioread32(o->bar+0x30)) return -EBUSY;
  packet[0]=4+pool;
  for(slot=0;slot<4;slot++) {
   dma_addr_t a=o->extra_address[pool*4+slot];
   packet[3+2*slot]=upper_32_bits(a);
   packet[4+2*slot]=lower_32_bits(a);
  }
  trace_stage("extra-pool-register");
  for(i=0;i<ARRAY_SIZE(packet);i++) iowrite32(packet[i],o->bar+4+i*4);
  wmb(); command_pending=true; o->capture.life.registered_buffers+=4;
  iowrite32(0x800,o->bar);
  ret=wait_mailbox_event(o->bar,&status);
  if(ret) return ret;
  if(ioread32(o->bar+4)!=packet[0]) return -EPROTO;
  ret=acknowledge(o->bar,o->aux);
  if(ret) return ret;
  command_pending=false; extra_registered++;
 }
 return 0;
}




static unsigned int snapshot_pcie_devctl;
module_param_named(snapshot_ready, stream.snapshot_ready,bool,0444);
module_param_named(snapshot_bytes, stream.snapshot_bytes,uint,0444);
module_param_named(snapshot_flush_status, stream.snapshot_flush_status,uint,0444);
module_param(snapshot_pcie_devctl,uint,0444);
static bool mappings_retained;
module_param_named(master_off_verified, stream.master_off_verified,bool,0444);
module_param(mappings_retained,bool,0444);
static bool paired_primary;
module_param(paired_primary,bool,0444);

 /* status, actual, expected, pending, class */
module_param_array_named(mailbox_snapshot, stream.mailbox_snapshot,uint,NULL,0444);

module_param_array_named(frame_counters, stream.frame_counters,uint,NULL,0444);
module_param_named(frame_snapshots, stream.frame_snapshots,uint,0444);
module_param_named(frame_events, stream.frame_events,uint,0444);
module_param_named(last_frame_counter, stream.last_frame_counter,uint,0444);
module_param_named(activation_armed, stream.activation_armed,uint,0444);
/* Snapshot both event classes before acknowledgement; never discard unknown
 * events. This does not transfer CPU ownership of the streaming DMA buffers. */
/* Encoded ownership release; raw copy audit below does not assume this
 * credit fences raw DMA.
 * Local tinyvenc7 dcb8 stores enc_stat0 fd; live handler12f24 reads it and
 * 130b4 publishes after DMA. ep.ko store0 writes one byte at mapped+0x50.
 * Publication ACK and ownership release are distinct operations. */
#define LIVE_COPY_LIMIT 8




module_param_named(live_copy_count, stream.live_copy_count,uint,0444);
module_param_named(live_copy_equal, stream.live_copy_equal,uint,0444);
module_param_array_named(live_copy_slots, stream.live_copy_slots,uint,NULL,0444);
module_param_array_named(live_copy_events, stream.live_copy_events,uint,NULL,0444);
module_param_array_named(live_copy_results, stream.live_copy_results,int,NULL,0444);
module_param_array_named(live_copy_begin_ns, stream.live_copy_begin_ns,ullong,NULL,0444);
module_param_array_named(live_copy_end_ns, stream.live_copy_end_ns,ullong,NULL,0444);
/* Coherent visibility only; this is NOT a device completion fence. */
static void copy_live_source(void *context, void *destination, size_t bytes)
{
 dma_rmb();
 memcpy(destination,context,bytes);
 dma_rmb();
}

module_param_named(stub_updates_skipped, stream.stub_updates_skipped,uint,0444);

module_param_array_named(raw_after, stream.raw_after,uint,NULL,0444);
module_param_array_named(raw_selected, stream.raw_selected,uint,NULL,0444);
static void audit_live_copy(struct diagnostic_owner *o, u32 reported_raw)
{
 unsigned int n=min_t(unsigned int,stream.live_copy_count,7), slot=reported_raw & 15u;
 u64 now=ktime_get_ns();
 enum hd60_copy_result result;
 if(slot>=4 || !stream.explicit_start_event ||
    !hd60_capture_io_allowed(&o->capture) || !o->capture.master_expected ||
    o->pool.allocated!=4 || o->pool.paired || !o->live_copies || !o->live_scratch)
  return;
 /* Negative filter only. Recheck the immutable copy below; this byte is
  * written before DMA and is not a completion or ownership fence. */
 dma_rmb();
 if (!(READ_ONCE(((unsigned char *)o->pool.cpu[slot])[5]) & 1u)) {
  stream.stub_updates_skipped++;
  return;
 }
 stream.live_copy_begin_ns[n]=now;
 result=hd60_copy_pair((char *)o->live_copies+n*HD60_I420_1080_BYTES,
             HD60_I420_1080_BYTES,o->live_scratch,HD60_I420_1080_BYTES,
             copy_live_source,o->pool.cpu[slot]);
 stream.live_copy_end_ns[n]=ktime_get_ns();
 /* Telemetry only: equality of cyclic indices is not a no-wrap proof. */
 stream.raw_after[n]=ioread32(o->bar+0x40);
 stream.raw_selected[n]=result==HD60_COPY_EQUAL_CANDIDATE &&
   hd60_candidate_selected((char *)o->live_copies+n*HD60_I420_1080_BYTES,
                           HD60_I420_1080_BYTES);
 stream.live_copy_results[n]=result;
 stream.live_copy_slots[n]=slot; stream.live_copy_events[n]=stream.frame_events;
 if(result==HD60_COPY_EQUAL_CANDIDATE) stream.live_copy_equal++;
 if(stream.raw_selected[n] && (stream.raw_after[n]&15u)==slot &&
    bridge_deliver(&live_bridge,(char *)o->live_copies+n*HD60_I420_1080_BYTES,
                   HD60_I420_1080_BYTES,stream.live_copy_begin_ns[n])) stream.delivered_frames++;
 if(stream.live_copy_count<LIVE_COPY_LIMIT) stream.live_copy_count++;
 /* Keep only first seven samples plus latest; never replay to userspace. */
}
/* Candidate samples only. Equal copies and equal modulo-four indices cannot
 * prove absence of a complete ring wrap or a producer error. Not ALSA data.
 * Fixed 1920-byte chunks, no direct DMA mapping exposed to userspace. */
static void audit_audio_copy(struct diagnostic_owner *o,
                             const struct hd60_stereo_event *e, unsigned int latest)
{
 void *dst;
 u32 before,after;
 u64 began,finished,age;
 if(audio_sequence.faulted) return; /* First fault ends PCM for this session. */
 if(!e->valid || !e->present || !o->channels || !o->audio_copies ||
    !o->audio_scratch || !stream.explicit_start_event ||
    !hd60_capture_io_allowed(&o->capture) || !o->capture.master_expected) return;

 if(audio_inject_gap_after_blocks && !audio_gap_injected &&
    audio_blocks>=audio_inject_gap_after_blocks && audio_sequence.seen) {
  audio_gap_injected=true;
  audio_sequence_fault=HD60_AUDIO_RING_GAP;
  audio_sequence.faulted=1;
  hd60_alsa_end(&audio_pcm);
  dev_warn(&o->pdev->dev,"injected host PCM discontinuity; no DMA data modified\n");
  return;
 }
 began=ktime_get_ns();
 before=ioread32(o->bar+0x4c);
 dst=audio_candidates<AUDIO_SAMPLE_LIMIT ?
  (char *)o->audio_copies+audio_candidates*HD60_STEREO_BLOCK_BYTES : (void *)audio_live_block;
 copy_live_source((char *)o->channels+e->offset,dst,e->bytes);
 copy_live_source((char *)o->channels+e->offset,o->audio_scratch,e->bytes);
 after=ioread32(o->bar+0x4c);
 finished=ktime_get_ns();
 age=finished-phase_current[0];
 if(memcmp(dst,o->audio_scratch,e->bytes)) { audio_changed++;
  audio_sequence_fault=HD60_AUDIO_BAD_COPY;audio_sequence.faulted=1;hd60_alsa_end(&audio_pcm);return; }
 if(before==~0U || after==~0U ||
    !hd60_audio_copy_window(e->slot,latest,before&15u,after&15u,age)) {
  if(!audio_slot_changed) dev_warn(&o->pdev->dev,
   "audio copy window rejected slot=%u event_latest=%u before=%08x after=%08x age_ns=%llu\n",
   e->slot,latest,before,after,(unsigned long long)age);
  audio_slot_changed++;
  audio_sequence_fault=HD60_AUDIO_BAD_SLOT;audio_sequence.faulted=1;hd60_alsa_end(&audio_pcm);return; }
 if(audio_candidates<AUDIO_SAMPLE_LIMIT) audio_trace[audio_candidates]=(struct audio_trace_record){
  .begin_ns=cpu_to_le64(began),.end_ns=cpu_to_le64(ktime_get_ns()),
  .slot=cpu_to_le32(e->slot),.reserved=0};
 {
  enum hd60_audio_sequence_result seq=hd60_audio_sequence_accept(&audio_sequence,
    e->slot,began,finished,1);
  if(seq==HD60_AUDIO_FIRST || seq==HD60_AUDIO_NEXT) hd60_alsa_push(&audio_pcm,dst);
  else { if(!audio_sequence_fault) audio_sequence_fault=seq;hd60_alsa_end(&audio_pcm); }
 }
 audio_blocks++;
 if(audio_candidates<AUDIO_SAMPLE_LIMIT) audio_candidates++;
 else audio_capacity_drops++; /* diagnostic history only; PCM still delivered */
}
static int release_discarded_frame(struct diagnostic_owner *o)
{
 u32 value;
 enum hd60_credit_action action;
 if(!stream.ownership_release_pending) return 0;
 if(!hd60_capture_io_allowed(&o->capture) || !o->capture.master_expected)
  return -EPERM;
 value=ioread32(o->bar+0x50);
 stream.encoded_status_last=value;
 action=hd60_credit_action(stream.ownership_release_pending,0,
          hd60_capture_io_allowed(&o->capture),o->capture.master_expected,value);
 if(action==HD60_CREDIT_FAULT) return -EPROTO;
 if(action==HD60_CREDIT_WAIT) { credit_wait_calls++; return 0; }
 /* Byte write preserves credits belonging to every other stream. */
 iowrite8(0,o->bar+0x50); wmb();
 (void)ioread32(o->bar+0x50); /* flush; producer may already mark it busy */
 if(credit_pending_since_ns) {
  u64 elapsed=ktime_get_ns()-credit_pending_since_ns;
  credit_release_samples++; credit_release_total_ns+=elapsed;
  if(elapsed>credit_release_max_ns) credit_release_max_ns=elapsed;
  credit_pending_since_ns=0;
 }
 stream.ownership_releases++; stream.ownership_release_pending=false;
 return 0;
}
static int capture_events_inner(struct diagnostic_owner *o, unsigned int opcode,
                          bool *completed)
{
 u32 status=ioread32(o->bar+0x30),counter=0;
 struct hd60_frame_event e;
 struct hd60_indexed_audio audio;
 phase_current[1]=ktime_get_ns();phase_current[7]=status;
 if (!status) return opcode==7 ? 0 : release_discarded_frame(o);
 if (status&1) counter=ioread32(o->bar+0x40);
 audio=hd60_decode_indexed_audio(status,
          status&0xf0000u ? ioread32(o->bar+0x4c) : 0);
 if(!audio.valid) {
  pr_err("HD60 audio decode rejected status=%08x latest=%u mask=%x\n",status,audio.latest,audio.mask);
  if(audio.lost) o->capture.life.health=HD60_HEALTH_LOST;
  o->capture.fault=1;
  return -EPROTO;
 }
 phase_current[2]=ktime_get_ns();
 e=hd60_capture_status(&o->capture,audio.video_status,counter);
 o->capture.life.pending_event=!!status;
 if(audio.mask) {
  audio_notifications++;audio_last_slot=audio.latest;
  if(!audio_sequence.faulted) {
   unsigned int n=audio_event_history_head*8;
   audio_event_history[n]=phase_current[0];
   audio_event_history[n+1]=status;
   audio_event_history[n+2]=audio.latest;
   audio_event_history[n+3]=audio_sequence.seen;
   audio_event_history[n+4]=audio_sequence.slot;
   audio_event_history[n+5]=audio_sequence.begin_ns;
   audio_event_history[n+6]=audio_sequence.end_ns;
   audio_event_history[n+7]=audio_notifications;
   audio_event_history_head=(audio_event_history_head+1)&7u;
   if(audio_event_history_count<8) audio_event_history_count++;
  }

  if(!stream.explicit_start_event) audio_before_start++;
  if(opcode==7) audio_during_stop++;
 }
 if (e.lost || o->capture.fault) return -EIO;
 if (e.mailbox) {
  u32 actual=ioread32(o->bar+4);
  enum hd60_mailbox_result classification=
   hd60_classify_mailbox(status,command_pending,opcode,actual);
  stream.mailbox_snapshot[0]=status; stream.mailbox_snapshot[1]=actual;
  stream.mailbox_snapshot[2]=opcode; stream.mailbox_snapshot[3]=command_pending;
  stream.mailbox_snapshot[4]=classification;
  if(classification!=HD60_MAILBOX_MATCH) {
   pr_err("HD60-FRAME-SNAPSHOT unexpected mailbox status=%08x actual_opcode=%08x expected=%08x pending=%u counter=%08x\n",
          status,actual,opcode,command_pending,counter);
   o->capture.fault=1;
   return -EPROTO;
  }
 }
 if (e.frame) {
  u32 counter44=ioread32(o->bar+0x44),counter48=ioread32(o->bar+0x48);
  stream.frame_events++;stream.last_frame_counter=counter;
  if(stream.ownership_release_pending) credit_pending_overlap++;
  else credit_pending_since_ns=ktime_get_ns();
  stream.ownership_release_pending=true;
  if(stream.frame_snapshots<32) {
   unsigned int n=stream.frame_snapshots*3;
   stream.frame_counters[n]=counter;
   stream.frame_counters[n+1]=counter44;
   stream.frame_counters[n+2]=counter48;
   stream.frame_snapshots++;
  }
 }
 iowrite32(2,o->aux+0xdc); wmb();
 iowrite32(0,o->bar+0x30); wmb();
 /* Flush the posted clear before reopening the endpoint publication gate.
  * A stale completion must not be consumed as the next command's event. */
 if (ioread32(o->bar+0x30)!=0) {
  o->capture.fault=1;
  return -EIO;
 }
 iowrite32(0x400,o->bar);
 if (e.mailbox) {
  command_pending=false;o->capture.command_pending=0;*completed=true;
 }
 phase_current[3]=ktime_get_ns();
 /* Do not grant another frame after the STOP completion. */
 if(opcode==7) { stream.ownership_release_pending=false; return 0; }
 /* Process context only, after event ACK, before returning encoded credit.
  * During START/STOP waits this path never copies. */
 if(opcode==0 && audio.mask && stream.explicit_start_event &&
    hd60_audio_in_startup(audio_start_ns,ktime_get_ns(),audio_startup_ms)) {
  /* Event has been acknowledged. Do not copy or deliver startup buffers;
   * after this fixed interval all original live ownership checks apply. */
  audio_startup_discarded+=audio.count;
 } else if(opcode==0 && audio.mask==15u && !audio_sequence.faulted) {
  audio_sequence.faulted=1;audio_sequence_fault=HD60_AUDIO_RING_GAP;
  hd60_alsa_end(&audio_pcm);
 } else if(opcode==0 && audio.mask) {
  unsigned int i;
  for(i=0;i<audio.count;i++) {
   struct hd60_stereo_event block={.present=1,.valid=1,
    .slot=audio.slots[i],.offset=audio.slots[i]*HD60_STEREO_SLOT_BYTES,
    .bytes=HD60_STEREO_BLOCK_BYTES};
   if(!o->channels || block.offset>CHANNEL_BYTES || block.bytes>CHANNEL_BYTES-block.offset)
    return -EPROTO;
   audit_audio_copy(o,&block,audio.latest);
  }
 }
 phase_current[4]=ktime_get_ns();
 if(opcode==0 && e.frame) audit_live_copy(o,counter);
 phase_current[5]=ktime_get_ns();
 return release_discarded_frame(o);
}
static int capture_events(struct diagnostic_owner *o,unsigned int opcode,bool *completed)
{
 int ret;unsigned int i;
 memset(phase_current,0,sizeof(phase_current));phase_current[0]=ktime_get_ns();
 ret=capture_events_inner(o,opcode,completed);phase_current[6]=ktime_get_ns();
 if(!opcode && phase_count<ARRAY_SIZE(phase_trace)) {
  for(i=0;i<8;i++) phase_trace[phase_count][i]=cpu_to_le64(phase_current[i]);
  phase_count++;
 }
 return ret;
}
static int capture_wait_inner(struct diagnostic_owner *o, unsigned int opcode,
                        unsigned int milliseconds, bool require_event)
{
 unsigned long deadline=jiffies+msecs_to_jiffies(milliseconds);
 bool completed=false;
 int ret;
 do {
  if(!opcode && stream.explicit_start_event && atomic_read(&stop_requested)) return 0;
  ret=capture_events(o,opcode,&completed);
  if(ret) return ret;
  if(require_event && completed) return 0;
  usleep_range(500,1000);
 } while(time_before(jiffies,deadline));
 return require_event ? -ETIMEDOUT : 0;
}
/* Dedicated worker only. Elevate just the bounded active polling interval,
 * not allocation/receiver initialization/cleanup. Every iteration sleeps.
 * No timeout, copy guard, STOP gate or retained-memory rule is relaxed. */
static int capture_wait(struct diagnostic_owner *o, unsigned int opcode,
                        unsigned int milliseconds, bool require_event)
{
 int ret;
 if(!opcode) sched_set_fifo_low(current);
 ret=capture_wait_inner(o,opcode,milliseconds,require_event);
 if(!opcode) sched_set_normal(current,0);
 return ret;
}
/* Immutable diagnostic copy only. This does not certify the endpoint worker
 * exited, authorize buffer release, or permit bus mastering to be re-enabled.
 * Linux device-io.html: non-relaxed PCI reads order outstanding DMA writes.
 * Require BME off and strict PCIe ordering before the read, then DMA API sync.
 * A future streaming driver needs a separate per-frame ownership protocol.
 */
static int snapshot_stopped_buffers(struct diagnostic_owner *o)
{
 unsigned int i;
 u16 command,devctl,devctl2;
 /* Preview-off reference can write a frame without a notification.
  * Keep STOP, MASTER-off, ordering and retention gates unchanged. */
 if (!stream.activation_armed || !stream.preview_event || !stream.stop_event || command_pending ||
     !stream.master_off_verified || !hd60_capture_io_allowed(&o->capture) ||
     o->capture.master_expected || o->pool.allocated!=4 || !o->snapshot)
  return -EPERM;
 if (!pci_is_pcie(o->pdev) ||
     pcie_capability_read_word(o->pdev,PCI_EXP_DEVCTL,&devctl)) return -EIO;
 snapshot_pcie_devctl=devctl;
 /* Ordering was configured before registration/START; verify it remained. */
 if(devctl==0xffff || (devctl&(PCI_EXP_DEVCTL_RELAX_EN|PCI_EXP_DEVCTL_NOSNOOP_EN)))
  return -EOPNOTSUPP;
 if(pcie_capability_read_word(o->pdev,PCI_EXP_DEVCTL2,&devctl2) ||
    devctl2==0xffff || (devctl2&(PCI_EXP_DEVCTL2_IDO_REQ_EN|PCI_EXP_DEVCTL2_IDO_CMP_EN)))
  return -EOPNOTSUPP;
 if(guarded_config_read(o->pdev,PCI_COMMAND,&command) ||
    !hd60_capture_io_allowed(&o->capture) || (command&PCI_COMMAND_MASTER))
  return -EIO;
 /* Non-relaxed MMIO read after verified master disable. Status register has
  * already been exercised by event polling and has no read-to-clear side effect.
  * Reject any pending event instead of acknowledging it speculatively. */
 stream.snapshot_flush_status=ioread32(o->bar+0x30);
 if(stream.snapshot_flush_status) return -EBUSY;
 if(guarded_config_read(o->pdev,PCI_COMMAND,&command) ||
    !hd60_capture_io_allowed(&o->capture) || (command&PCI_COMMAND_MASTER))
  return -EIO;
 dma_rmb();
 /* Same STOP/BME/PCI ordering gates as the frame snapshot above. A changed
  * sentinel proves modification, not HDMI provenance or sample continuity.
  * Inspect every registered8KiB extent to catch a transposed mapping error. */
 if(!o->channels) return -EINVAL;
 for(i=0;i<32;i++) {
  unsigned int j;
  const u8 *p=(const u8 *)o->channels+i*0x2000u;
  audio_extent_first[i]=0x2000u;
  audio_extent_last[i]=0x2000u;
  for(j=0;j<0x2000u;j++) {
   u8 v=READ_ONCE(p[j]);
   if(v!=AUDIO_SENTINEL) {
    if(!audio_extent_changed[i]) audio_extent_first[i]=j;
    audio_extent_last[i]=j;
    audio_extent_changed[i]++;
    if(v) audio_extent_nonzero[i]++;
   }
  }
 }
 audio_extent_snapshot=true;
 for(i=0;i<4;i++) {
  if(!o->pool.cpu[i]) return -EINVAL;
  hd60_coherent_copy_stopped((char *)o->snapshot+i*BUFFER_BYTES,&o->pool,i);
 }
 stream.snapshot_bytes=4*BUFFER_BYTES;
 stream.snapshot_ready=true;
 /* No sync_for_device: this lifecycle must never re-enable bus mastering. */
 return 0;
}

static int first_capture(struct diagnostic_owner *o)
{
 u16 command;
 int ret;
 /* Once setup begins, complete the established START/STOP transaction even
  * if the client closes. The streaming wait exits immediately after START
  * acknowledgement; all original stop/restore/retention gates still apply. */
 o->capture.ready=HD60_CAPTURE_READY;
 o->capture.command_pending=command_pending;
 stream.encoded_status_last=ioread32(o->bar+0x50);
 if(stream.encoded_status_last==~0U || !hd60_io_allowed(&o->capture.life)) return -ENODEV;
 iowrite8(0,o->bar+0x50); wmb();
 if(ioread32(o->bar+0x50)&0xff) return -EBUSY;
 ret=guarded_config_read(o->pdev,PCI_COMMAND,&command);
 if(ret || !hd60_arm_configured_pipeline(&o->capture,stream.mode_event,stream.audio_event,
                                          stream.encoder_events,stream.preview_event)) return -EIO;
 trace_stage("enable-master");
 pci_set_master(o->pdev);
 ret=guarded_config_read(o->pdev,PCI_COMMAND,&command);
 if(ret || !hd60_capture_io_allowed(&o->capture)) { ret=-EIO;goto contain; }
 stream.activation_armed=1;
 /* Frame eligibility was armed before BME, so early configuration-driven
  * frames remain valid. Drain publication before the additional START command. */
 ret=capture_wait(o,0,1,false);
 if(ret || command_pending) goto contain;
 trace_stage("configured-pipeline-explicit-START");
 iowrite32(6,o->bar+4); iowrite32(~0U,o->bar+8); wmb();
 command_pending=true; o->capture.command_pending=1;
 iowrite32(0x800,o->bar);
 ret=capture_wait(o,6,5000,true);
 if(ret) goto contain;
 audio_start_ns=ktime_get_ns();
 stream.explicit_start_event=true;
 {
  u64 began=ktime_get_ns();
  do {
   ret=capture_wait(o,0,capture_duration_ms ?: 1000,false);
  } while (!capture_duration_ms && !ret && !atomic_read(&stop_requested));
  stream.live_interval_ns=ktime_get_ns()-began;
  pr_info("HD60 live interval ns=%llu client_stop=%d frames=%u ret=%d\n",
          stream.live_interval_ns,atomic_read(&stop_requested),stream.delivered_frames,ret);
 }
 if(ret || command_pending) goto contain;
 trace_stage("capture-STOP-submit");
 iowrite32(7,o->bar+4);iowrite32(~0U,o->bar+8);wmb();
 command_pending=true;o->capture.command_pending=1;iowrite32(0x800,o->bar);
 ret=capture_wait(o,7,5000,true);
 if(!ret) { o->capture.life.stop_confirmed=1; stream.stop_event=true; stream.stop_status=0x800; }
contain:
 /* Keep memory mapped regardless of STOP. No DMA drain proof exists yet. */
 trace_stage("master-off-retain-mappings");
 hd60_capture_disarm_master(&o->capture);
 pci_clear_master(o->pdev);
 if (!guarded_config_read(o->pdev,PCI_COMMAND,&command))
  stream.master_off_verified=!(command&PCI_COMMAND_MASTER);
 if(!ret) {
  trace_stage("stopped-buffer-snapshot");
  ret=snapshot_stopped_buffers(o);
 }
 return ret;
}

static int register_pool(struct diagnostic_owner *o)
{
 struct device *dev=&o->pdev->dev;
 struct iommu_domain *domain=iommu_get_domain_for_dev(dev);
 u32 packet[11]={2,0,BUFFER_BYTES};
 unsigned int i;
 u16 command;
 int ret;
 iommu_mapping=domain && (domain->type==IOMMU_DOMAIN_DMA ||
                                            domain->type==IOMMU_DOMAIN_DMA_FQ);
 if(!dev->dma_mask || (iommu_mapping && !dev->dma_parms)) return -EOPNOTSUPP;
 o->saved_mask=*dev->dma_mask;
 o->saved_coherent_mask=dev->coherent_dma_mask;
 o->masks_changed=true;
 ret=dma_set_mask_and_coherent(dev,DMA_BIT_MASK(64));
 if(ret) ret=dma_set_mask_and_coherent(dev,DMA_BIT_MASK(32));
 if(ret) return ret;
 if(iommu_mapping) {
  o->saved_segment=dma_get_max_seg_size(dev);
  dma_set_max_seg_size(dev,BUFFER_BYTES);
  o->segment_changed=true;
 }
 trace_stage("allocate-map-primary");
 o->allocation_attempted=true;
 ret=hd60_coherent_pool_alloc(dev,&o->pool);
 buffers_allocated=o->pool.allocated;
 paired_primary=o->pool.paired;
 o->capture.life.allocated_buffers=buffers_allocated;
 if(ret) return ret;
 ret=guarded_config_read(o->pdev,PCI_COMMAND,&command);
 if(ret || !hd60_io_allowed(&o->capture.life)) return -EIO;
 if(ioread32(o->bar+0x30)) return -EBUSY;
 for(i=0;i<4;i++) {
  addresses[i]=o->pool.dma[i];
  packet[3+2*i]=upper_32_bits(o->pool.dma[i]);
  packet[4+2*i]=lower_32_bits(o->pool.dma[i]);
 }
 ret=allocate_extra(o);
 if(ret) return ret;
 trace_stage("primary-register-submit");
 /* Offset2c contains final address low word, not a completion flag. */
 for(i=0;i<ARRAY_SIZE(packet);i++) iowrite32(packet[i],o->bar+4+4*i);
 wmb();
 o->capture.life.registered_buffers=4;
 command_pending=true;
 iowrite32(0x800,o->bar);
 ret=wait_mailbox_event(o->bar,&register_status);
 if(ret) return ret;
 if(ioread32(o->bar+4)!=2) return -EPROTO;
 ret=acknowledge(o->bar,o->aux);
 if(ret) return ret;
 command_pending=false; register_event=true;
 ret=register_channels(o);
 if(ret) return ret;
 ret=register_extra(o);
 if(ret) return ret;
 receiver_aux=o->aux;
 ret=receiver_baseline(o->bar,false);
 if(ret) return ret;
 /* first_capture already issued STOP before master containment. Never send
  * a second STOP merely because this setup path originally had its own. */
 if (o->capture.life.dma_ever_enabled) {
  if (!stream.stop_event || command_pending || o->capture.fault) return -EIO;
  return 0;
 }
 trace_stage("primary-stop-submit");
 iowrite32(0,o->bar+0x2c);
 iowrite32(7,o->bar+4);
 iowrite32(~0U,o->bar+8);
 wmb(); command_pending=true;
 iowrite32(0x800,o->bar);
 ret=wait_mailbox_event(o->bar,&stream.stop_status);
 if(ret) return ret;
 if(ioread32(o->bar+4)!=7) return -EPROTO;
 ret=acknowledge(o->bar,o->aux);
 if(ret) return ret;
 command_pending=false; stream.stop_event=true; o->capture.life.stop_confirmed=1;
 trace_stage("primary-version-after");
 ret=query(o->bar,o->aux);
 stream.version_after=!ret;
 return ret;
}

static bool receiver_fully_restored(void);

static int run_capture(struct pci_dev *pdev, const struct pci_device_id *id)
{
 struct diagnostic_owner *o;
 struct hd60_cleanup_plan plan;
 u16 original = 0xffff, command = 0xffff, devctl = 0xffff;
 bool enabled=false, masked=false, regions=false, input_rejected=false;
 bool pci_restored=false;
 unsigned int i;
 int ret;
 if (active_owner) return -EBUSY;
 startup_retry_ready=false;
 o=kzalloc(sizeof(*o), GFP_KERNEL);
 if (!o) return -ENOMEM;
 active_owner=o; o->pdev=pdev;
 trace_stage("PCI-preflight");
 ret=guarded_config_read(pdev, PCI_COMMAND, &original);
 if (ret || original == 0xffff || (original & PCI_COMMAND_MASTER)) {
  ret=ret ?: -EBUSY; goto out;
 }
 if (!(pci_resource_flags(pdev,0)&IORESOURCE_MEM) ||
     !(pci_resource_flags(pdev,5)&IORESOURCE_MEM) ||
     pci_resource_len(pdev,0)<0x64 || pci_resource_len(pdev,5)<0xe0) {
  ret=-ENODEV; goto out;
 }
 ret=pci_enable_device_mem(pdev); if(ret) goto out; enabled=true;
 pci_intx(pdev,0); masked=true;
 ret=guarded_config_read(pdev,PCI_COMMAND,&command);
 if(ret || !hd60_io_allowed(&o->capture.life)) { ret=-EIO; goto out; }
 ret=pci_request_selected_regions(pdev,BIT(0)|BIT(5),"hd60pro_audio_probe");
 if(ret) goto out; regions=true;
 o->bar=pci_iomap_range(pdev,0,0,0x64);
 o->aux=pci_iomap_range(pdev,5,0,0xe0);
 if(!o->bar || !o->aux) { ret=-ENOMEM; goto out; }

 /* Validate export ordering and reserve CPU-copy storage before any firmware
  * registration, so these failures cannot create a retained DMA lifecycle. */
 if(!pci_is_pcie(pdev) || pcie_capability_read_word(pdev,PCI_EXP_DEVCTL,&devctl) ||
    devctl==0xffff) { ret=-EIO; o->capture.life.health=HD60_HEALTH_LOST; goto out; }
 o->saved_devctl=devctl;
 /* The existing card enables Relaxed Ordering. Disable it, and No Snoop,
  * while BME is still off, BEFORE any command or address registration. This
  * affects PCI transactions only, not flash or receiver firmware. */
 o->ordering_changed=true;
 ret=pcie_capability_clear_word(pdev,PCI_EXP_DEVCTL,
                  PCI_EXP_DEVCTL_RELAX_EN|PCI_EXP_DEVCTL_NOSNOOP_EN);
 if(ret || pcie_capability_read_word(pdev,PCI_EXP_DEVCTL,&devctl) ||
    devctl==0xffff || (devctl&(PCI_EXP_DEVCTL_RELAX_EN|PCI_EXP_DEVCTL_NOSNOOP_EN))) {
  ret=-EIO; o->capture.life.health=HD60_HEALTH_LOST; goto out;
 }
 snapshot_pcie_devctl=devctl;
 ret=pcie_capability_read_word(pdev,PCI_EXP_DEVCTL2,&devctl);
 if(ret || devctl==0xffff || (devctl&(PCI_EXP_DEVCTL2_IDO_REQ_EN|PCI_EXP_DEVCTL2_IDO_CMP_EN))) {
  ret=-EOPNOTSUPP; goto out;
 }
 o->snapshot=kvzalloc(4*BUFFER_BYTES,GFP_KERNEL);
 if(!o->snapshot) { ret=-ENOMEM; goto out; }
 o->live_copies=kvzalloc(LIVE_COPY_LIMIT*HD60_I420_1080_BYTES,GFP_KERNEL);
 o->live_scratch=kvzalloc(HD60_I420_1080_BYTES,GFP_KERNEL);
 if(!o->live_copies || !o->live_scratch) { ret=-ENOMEM; goto out; }
 o->audio_copies=kvzalloc(AUDIO_SAMPLE_LIMIT*HD60_STEREO_BLOCK_BYTES,GFP_KERNEL);
 o->audio_scratch=kvzalloc(HD60_STEREO_BLOCK_BYTES,GFP_KERNEL);
 if(!o->audio_copies || !o->audio_scratch) { ret=-ENOMEM;goto out; }
 trace_stage("version-before");
 ret=acknowledge(o->bar,o->aux);
 if(!ret) ret=query(o->bar,o->aux);
 if(!ret) {
  receiver_aux=o->aux;
  trace_stage("input-preflight-before-registration");
  ret=receiver_baseline(o->bar,true);
  input_rejected=(ret==-ENOLINK && input_status==HD60_INPUT_NO_LOCK) ||
   (ret==-EOPNOTSUPP && input_status==HD60_INPUT_UNSUPPORTED);
  if(!ret && !receiver_fully_restored()) ret=-EIO;
  if(!ret) {
   /* A second transaction performs normal setup after buffer registration.
    * Reset only receiver bookkeeping after verified restoration. */
   memset(&receiver,0,sizeof(receiver));
  }
 }
 if(!ret) ret=register_pool(o);
 stream.finished=!ret && stream.explicit_start_event && stream.activation_armed && stream.preview_event && extra_registered==4 && stream.encoder_events==2 && channels_completed==8 && register_event && stream.mode_event && stream.audio_event && stream.preview_event && stream.stop_event;

out:
 stream.diagnostic_error=ret;
 if(!enabled && !masked && !regions) goto free_owner;
 if(ret == -ETIMEDOUT || ret == -ENODEV) o->capture.life.health=HD60_HEALTH_LOST;
 if(o->capture.life.health != HD60_HEALTH_LOST)
  guarded_config_read(pdev,PCI_COMMAND,&command);
 if(o->bar && hd60_io_allowed(&o->capture.life))
  hd60_observe_status(&o->capture.life,ioread32(o->bar+0x30));
 o->capture.command_pending=command_pending;
 plan=hd60_capture_cleanup(&o->capture);
 if(plan.retain_ownership || encoder_tail_attempted || command_pending || port_touched ||
    (receiver.handoff_attempted && !receiver.handoff_gates_restored) ||
    (receiver.pulse_attempted && !receiver.pulse_restored) || (receiver.latch_attempted && !receiver.latch_cleared) || receiver.core_changed || receiver.page1_changed || (receiver.gpio8_attempted && !receiver.gpio8_restored) || (receiver.init_writes_attempted && !receiver.init_restored) || (receiver.steps && !receiver.restored) || (receiver.source_attempted && !receiver.source_restored) ||
    (receiver.reg13_attempted && !receiver.reg13_restored) || (receiver.bank_attempted && !receiver.bank_restored) ||
    (receiver.coefficients_attempted && !receiver.coefficients_restored) ||
    (receiver.prefix_attempted && !receiver.prefix_restored) || (receiver.output_b0_attempted && !receiver.output_b0_restored)) {
  quarantined=true;
  mappings_retained=o->capture.life.dma_ever_enabled;
  if(!stream.diagnostic_error && (!mappings_retained || !stream.master_off_verified))
   stream.diagnostic_error=-EIO;
  pci_dev_get(pdev); pci_set_drvdata(pdev,o); __module_get(THIS_MODULE);
  if(stream.snapshot_ready) {
   o->snapshot_blob.data=o->snapshot;
   o->snapshot_blob.size=stream.snapshot_bytes;
   o->snapshot_dir=debugfs_create_dir("hd60pro-audio-probe",NULL);
   if(!IS_ERR_OR_NULL(o->snapshot_dir)) {
    if(phase_count) {
     phase_blob.data=phase_trace;phase_blob.size=phase_count*sizeof(phase_trace[0]);
     debugfs_create_blob("event-phases-le64.bin",0400,o->snapshot_dir,&phase_blob);
    }
    if(audio_candidates) {
     audio_trace_blob.data=audio_trace;
     audio_trace_blob.size=audio_candidates*sizeof(audio_trace[0]);
     debugfs_create_blob("audio-trace-le24.bin",0400,o->snapshot_dir,&audio_trace_blob);
     o->audio_blob.data=o->audio_copies;
     o->audio_blob.size=audio_candidates*HD60_STEREO_BLOCK_BYTES;
     debugfs_create_blob("audio-candidates-s16le-stereo.bin",0400,
                         o->snapshot_dir,&o->audio_blob);
    }
    struct dentry *entry=debugfs_create_blob("primary-pools.bin",0400,
                              o->snapshot_dir,&o->snapshot_blob);
    if(IS_ERR_OR_NULL(entry)) pr_err("HD60-FRAME-SNAPSHOT export unavailable\n");
    if(stream.live_copy_count) {
     o->live_blob.data=o->live_copies;
     o->live_blob.size=stream.live_copy_count*HD60_I420_1080_BYTES;
     entry=debugfs_create_blob("live-candidates.bin",0400,o->snapshot_dir,&o->live_blob);
     if(IS_ERR_OR_NULL(entry)) pr_err("HD60 live-copy export unavailable\n");
    }
   }
  }
  pr_err("HD60-FRAME-SNAPSHOT QUARANTINED stage=%s error=%d command=%04x; no further test\n",last_stage,stream.diagnostic_error,command);
  return 0;
 }
 trace_stage("healthy-cleanup");
 /* Reached only with healthy config, no pending command/event, MASTER off,
  * and confirmed STOP if any address was submitted. No active DMA here.
  */
 for(i=0;i<8;i++) if(o->extra[i]) {
  dma_free_coherent(&pdev->dev,EXTRA_BYTES,o->extra[i],o->extra_address[i]);
  o->extra[i]=NULL; extra_freed++;
 }
 if(o->channels) {
  dma_free_coherent(&pdev->dev,CHANNEL_BYTES,o->channels,o->channel_address);
  o->channels=NULL; channels_freed=true;
 }
 if(o->allocation_attempted) {
  hd60_coherent_pool_free(&pdev->dev,&o->pool);
  buffer_freed=true;
 }
 if(o->segment_changed) dma_set_max_seg_size(&pdev->dev,o->saved_segment);
 if(o->masks_changed) {
  *pdev->dev.dma_mask=o->saved_mask;
  pdev->dev.coherent_dma_mask=o->saved_coherent_mask;
 }
 if(o->ordering_changed) {
  int err=pcie_capability_clear_and_set_word(pdev,PCI_EXP_DEVCTL,
             PCI_EXP_DEVCTL_RELAX_EN|PCI_EXP_DEVCTL_NOSNOOP_EN,
             o->saved_devctl&(PCI_EXP_DEVCTL_RELAX_EN|PCI_EXP_DEVCTL_NOSNOOP_EN));
  if(err && !stream.diagnostic_error) stream.diagnostic_error=-EIO;
 }
 if(o->aux) pci_iounmap(pdev,o->aux);
 if(o->bar) pci_iounmap(pdev,o->bar);
 if(regions) pci_release_selected_regions(pdev,BIT(0)|BIT(5));
 if(enabled) pci_disable_device(pdev);
 /* pci_disable_device leaves memory decoding enabled on this platform.
  * Restore only the MEM bit we enabled, on a healthy pre-registration
  * rejection. Never change PCI config here after DMA/registration. */
 if(input_rejected && !o->capture.life.registered_buffers &&
    !o->capture.life.dma_ever_enabled && !(original&PCI_COMMAND_MEMORY)) {
  int err=guarded_config_read(pdev,PCI_COMMAND,&command);
  if(!err && command!=0xffff && !(command&PCI_COMMAND_MASTER))
   err=pci_write_config_word(pdev,PCI_COMMAND,command&~PCI_COMMAND_MEMORY);
  else err=-EIO;
  if(err) pci_restored=false;
 }
 if(masked) {
  pci_intx(pdev,!(original&PCI_COMMAND_INTX_DISABLE));
  intx_restored=!guarded_config_read(pdev,PCI_COMMAND,&command) &&
    !((command^original)&PCI_COMMAND_INTX_DISABLE);
  if(!intx_restored) stream.diagnostic_error=-EIO;
 }
 /* No retry evidence is published from a retained/uncertain cleanup path.
  * Compare final PCI state with the saved preflight state before freeing owner. */
 if(input_rejected && intx_restored &&
    !guarded_config_read(pdev,PCI_COMMAND,&command) && command==original &&
    !pcie_capability_read_word(pdev,PCI_EXP_DEVCTL,&devctl) &&
    devctl!=0xffff && devctl==o->saved_devctl)
  pci_restored=true;
 startup_retry_ready=hd60_startup_cleanup_allows_retry(input_rejected,
  receiver_fully_restored(),pci_restored,o->capture.life.registered_buffers,
  o->capture.life.dma_ever_enabled,command_pending || o->capture.life.pending_event,
  o->capture.life.health==HD60_HEALTH_OK && !o->capture.fault);
 /* Worker join and owner absence are checked again by join_capture. */
free_owner:
 kvfree(o->audio_scratch); kvfree(o->audio_copies);
 kvfree(o->live_scratch); kvfree(o->live_copies);
 kvfree(o->snapshot); active_owner=NULL; kfree(o);
 pr_err("HD60-FRAME-SNAPSHOT finished=%d error=%d mode=%d stop=%d intx=%d\n",
         stream.finished,stream.diagnostic_error,register_event,stream.stop_event,intx_restored);
 return ret;
}
static bool receiver_fully_restored(void)
{
 return receiver.restored && !receiver.restored_level &&
  audio_setup_restored==audio_setup_attempted &&
  (!receiver.handoff_attempted || receiver.handoff_gates_restored) &&
  (!receiver.pulse_attempted || receiver.pulse_restored) &&
  (!receiver.latch_attempted || receiver.latch_cleared) &&
  !receiver.core_changed && !receiver.page1_changed &&
  (!receiver.gpio8_attempted || receiver.gpio8_restored) &&
  (!receiver.init_writes_attempted || receiver.init_restored) &&
  (!receiver.source_attempted || receiver.source_restored) &&
  (!receiver.reg13_attempted || receiver.reg13_restored) &&
  (!receiver.bank_attempted || receiver.bank_restored) &&
  (!receiver.coefficients_attempted || receiver.coefficients_restored) &&
  (!receiver.prefix_attempted || receiver.prefix_restored) &&
  (!receiver.output_b0_attempted || receiver.output_b0_restored);
}
static bool retained_layout(struct diagnostic_owner *o)
{
 unsigned int i;
 if(!o || o->pdev!=bridge_pdev || !o->bar || !o->aux ||
    !mappings_retained || o->pool.allocated!=4 || o->pool.paired ||
    !o->channels || extra_allocated!=8 || channels_completed!=8 ||
    !o->live_copies || !o->live_scratch || !o->snapshot) return false;
 for(i=0;i<4;i++)
  if(!o->pool.cpu[i] || o->pool.tail[i] || o->pool.dma[i]!=addresses[i]) return false;
 for(i=0;i<8;i++) if(!o->extra[i]) return false;
 return true;
}
static struct hd60_session_evidence session_evidence(void)
{
 struct hd60_session_evidence e={
  .worker_joined=session_worker_joined,
  .receiver_restored=receiver_fully_restored(),
  .mappings_owned=retained_layout(active_owner),
  .stop_event=stream.stop_event,
  .master_off_verified=stream.master_off_verified,
  .command_pending=command_pending || stream.ownership_release_pending,
  .error=stream.diagnostic_error ?: (!stream.finished ? -EIO :
    (audio_sequence_fault && !hd60_audio_restart_classified(audio_restart_test,
      audio_sequence_fault,READ_ONCE(audio_pcm.ended),READ_ONCE(audio_pcm.running)) ? -EIO : 0))
 };
 return e;
}
/* Experimental retained-owner path. No allocation, address replacement,
 * unmap, DMA-buffer memset or reset. Requires explicit test opt-in. */
static int reuse_capture(struct diagnostic_owner *o)
{
 struct hd60_session_evidence e=session_evidence();
 unsigned int registered_before=extra_registered;
 u16 command;
 int ret;
 restart_attempts++;
 if(!retained_layout(o)) return -EIO;
 ret=guarded_config_read(o->pdev,PCI_COMMAND,&command);
 if(ret || !hd60_capture_io_allowed(&o->capture) || (command&PCI_COMMAND_MASTER))
  return ret ?: -EIO;
 /* Reject residual publication rather than acknowledging an unknown event. */
 if(ioread32(o->bar+0x30)) return -EBUSY;
 if(!hd60_session_prepare(&session,&o->capture,&e)) return -EIO;
 session_worker_joined=false;
 /* Joined, clean previous session; reset only host session bookkeeping.
  * Keep every DMA allocation and address unchanged. */
 if(audio_recovery_pending) {
  audio_recovered_sessions++;
  audio_recovery_pending=false;
 }
 memset(&audio_sequence,0,sizeof(audio_sequence));
 memset(audio_event_history,0,sizeof(audio_event_history));
 audio_event_history_head=audio_event_history_count=0;
 audio_setup_attempted=audio_setup_verified=audio_setup_restored=0;
 audio_receiver_bank_restored=false;
 memset(&receiver,0,sizeof(receiver));
 memset(&stream,0,sizeof(stream));
 o->next_copy_ns=0;
 session.phase=HD60_SESSION_RUNNING;
 WRITE_ONCE(session_state,session.phase);
 receiver_aux=o->aux;
 ret=query(o->bar,o->aux);
 if(!ret && (major!=1 || minor!=11)) ret=-EPROTO;
 if(!ret) ret=receiver_baseline(o->bar,false);
 o->capture.command_pending=command_pending;
 stream.finished=!ret && stream.explicit_start_event && stream.activation_armed &&
  stream.encoder_events==2 && stream.mode_event && stream.audio_event &&
  stream.preview_event && extra_registered-registered_before==2 &&
  stream.stop_event && stream.master_off_verified && receiver_fully_restored();
 stream.diagnostic_error=ret ?: (stream.finished ? 0 : -EIO);
 if(stream.diagnostic_error) session.phase=HD60_SESSION_FAILED;
 return stream.diagnostic_error;
}
static void capture_worker(struct kthread_work *work)
{
 /* A queued first session can be cancelled without acquiring the card.
  * Once setup begins, retain the existing hardware cleanup requirements. */
 if(!active_owner && atomic_read(&stop_requested)) {
  bridge_finished(&live_bridge);
  return;
 }
 session_setup_started=true;
 if(active_owner) {
  int ret=reuse_capture(active_owner);
  if(ret) { stream.diagnostic_error=ret;session.phase=HD60_SESSION_FAILED; }
 } else run_capture(bridge_pdev,NULL);
 session_state=session.phase;
 hd60_alsa_end(&audio_pcm);
 if(active_owner && stream.finished && stream.master_off_verified) {
  audio_trace_blob.size=audio_candidates*sizeof(audio_trace[0]);
  active_owner->audio_blob.size=audio_candidates*HD60_STEREO_BLOCK_BYTES;
  phase_blob.size=phase_count*sizeof(phase_trace[0]);
 }
 bridge_finished(&live_bridge);
}
static int request_capture(void *context)
{
 if(session.phase!=HD60_SESSION_NEW &&
    !(reuse_test && session.phase==HD60_SESSION_RETAINED))
  return -EIO;
 if(session.phase==HD60_SESSION_NEW) {
  if(startup_retry_ready) {
   memset(&receiver,0,sizeof(receiver));
   memset(&stream,0,sizeof(stream));
   startup_retry_ready=false;
  }
  session.phase=HD60_SESSION_RUNNING;
 }
 WRITE_ONCE(session_state,session.phase);
 atomic_set(&stop_requested,0);
 session_setup_started=false;
 if(kthread_queue_work(capture_thread,&capture_work)) return 0;
 session.phase=HD60_SESSION_FAILED;
 WRITE_ONCE(session_state,session.phase);
 return -EBUSY;
}
static void join_capture(void *context)
{
 unsigned int i;
 stream.client_stop_requested=true;
 pr_info("HD60 V4L2 client requested STREAMOFF/close; frames=%u\n",stream.delivered_frames);
 atomic_set(&stop_requested,1);
 kthread_flush_work(&capture_work);
 session_worker_joined=true;
 if(startup_retry_ready && !active_owner && session.phase==HD60_SESSION_RUNNING &&
    !session.completed && !hd60_alsa_rearm(&audio_pcm)) {
  session.phase=HD60_SESSION_NEW;
  session_state=session.phase;
  return;
 }
 if(hd60_session_cancel_queued_new(&session,session_worker_joined,
                                  session_setup_started,!!active_owner)) {
  session_state=session.phase;
  return;
 }
 if(session.phase==HD60_SESSION_RUNNING && active_owner) {
  struct hd60_session_evidence e=session_evidence();
  hd60_session_stopped(&session,&active_owner->capture,&e);
 } else if(session.phase!=HD60_SESSION_RETAINED)
  session.phase=HD60_SESSION_FAILED;
 if(reuse_test && session.phase==HD60_SESSION_RETAINED) {
  if(hd60_alsa_rearm(&audio_pcm)) session.phase=HD60_SESSION_FAILED;
  else if(audio_sequence_fault) {
   /* Only after joined worker, all clean-stop gates and successful PCM rearm.
    * Preserve the reason/history for review; no in-session resynchronization. */
   previous_audio_fault=audio_sequence_fault;
   audio_sequence_fault=0;
   audio_recovery_pending=true;
  }
 }
 completed_sessions=session.completed;
 session_state=session.phase;
 if(active_owner) {
  for(i=0;i<4;i++) retained_dma_addresses[i]=active_owner->pool.dma[i];
  retained_dma_addresses[4]=active_owner->channel_address;
  for(i=0;i<8;i++) retained_dma_addresses[5+i]=active_owner->extra_address[i];
 }
}
static int probe(struct pci_dev *pdev,const struct pci_device_id *id)
{
 int ret;
 if(bridge_pdev) return -EBUSY;
 bridge_pdev=pdev;kthread_init_work(&capture_work,capture_worker);
 capture_thread=kthread_create_worker(0,"hd60-av");
 if(IS_ERR(capture_thread)) { ret=PTR_ERR(capture_thread);capture_thread=NULL;bridge_pdev=NULL;return ret; }
 ret=hd60_alsa_register(&audio_pcm,&pdev->dev,"HD60Audio");
 if(ret) { kthread_destroy_worker(capture_thread);capture_thread=NULL;bridge_pdev=NULL;return ret; }
 ret=bridge_register(&live_bridge,&pdev->dev,request_capture,join_capture,NULL);
 if(ret) { snd_card_free(audio_pcm.card);audio_pcm.card=NULL;kthread_destroy_worker(capture_thread);capture_thread=NULL;bridge_pdev=NULL;return ret; }
 live_bridge.reusable=reuse_test;
 /* Draft one-shot lifetime: keep node/storage and driver until reboot. */
 pci_dev_get(pdev);__module_get(THIS_MODULE);
 return 0;
}
static const struct pci_device_id ids[]={
 {PCI_DEVICE_SUB(0x12ab,0x0380,0x1cfa,0x0003)},{}
};
MODULE_DEVICE_TABLE(pci,ids);
static struct pci_driver isolated_driver={
 .name="hd60pro_audio_probe", .id_table=ids, .probe=probe,
 .driver={.suppress_bind_attrs=true},
};
/* Explicit one-shot opt-in; userspace harness requires a fresh, unbound card. */
static bool run_bounded_test;
module_param(run_bounded_test,bool,0000);
static int __init capture_init(void)
{
 if (!run_bounded_test) return -EPERM;
 if (!hd60_capture_options_valid(capture_duration_ms,reuse_test,audio_startup_ms)) return -EINVAL;
 return pci_register_driver(&isolated_driver);
}
static void __exit capture_exit(void) { pci_unregister_driver(&isolated_driver); }
module_init(capture_init);
module_exit(capture_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Stopped immutable frame snapshot; retains DMA mappings");
