/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_SOURCE_METADATA_H
#define HD60_SOURCE_METADATA_H
/* Observed PC/KVM and direct Pixel metadata only. Windows24db97 masks48
 * with0x60;25387d decodes49>>6 and(4a>>2)&3. Both observed profiles select
 * contexts33c=340=344=0 and the existing CSC plan. This is not a general
 * HDMI mode validator: caller must separately check timing and lock. */
static inline int hd60_known_csc_metadata(unsigned int m0e,unsigned int m48,
                                         unsigned int m49,unsigned int m4a)
{
 return m0e==0xa0 && (m48==0x82 || m48==0x90) && m49==0x28 &&
        (m4a==0 || m4a==0x80);
}
/* GH4 observed metadata selects context344=1: bypass RGB matrix multiply.
 * Exact observed bytes only; neutral Linux controls128/128/128/32.
 * Timing, lock and original-register guards remain in the caller. */
static inline unsigned int hd60_csc_profile(unsigned int m0e,unsigned int m48,
 unsigned int m49,unsigned int m4a)
{
 if(hd60_known_csc_metadata(m0e,m48,m49,m4a)) return 1;
 if(m0e==0xa0 && m48==0xa0 && m49==0 && m4a==0) return 2;
 return 0;
}
static inline unsigned int hd60_csc_coefficient(unsigned int profile,
 unsigned int index,unsigned int pc_value)
{
 static const unsigned char gh4[24]={
  0x3f,0x10,0,0,0,0,0,0,0,0x10,0,0,0,0,0,0,0,0x10,
  0,0x20,0,0,0,0x20};
 return profile==2 && index<24 ? gh4[index] : pc_value;
}
#endif
