HD60 Pro Linux — experimental 0.1.20.1

Supports the tested HD60 Pro PCI12ab:0380/subsystem1cfa:0003 with resident
firmware1.11. No flash write or runtime firmware upload is required.

Verified on this rig: disconnected-input startup rejection and reconnect on
the same boot; normal stop/reopen; startup cancellation; GH4 video and stereo
audio in OBS. User confirmed short-clip lip-sync and orientation. A ten-minute
OBS reopen test completed without audio faults and stopped cleanly.

An earlier audio-buffer timing fault remains unexplained. The new recovery
path stops audio for that session. Close OBS normally and reopen after a clean
stop. Recovery requires verified STOP, bus mastering off, restored receiver,
joined worker and unchanged retained buffers. Hardware/unknown faults still
require reboot. An injected continuity fault, same-boot audio reopen, and
subsequent three-minute OBS test passed. This does not prove all faults recover.
Fault injection is explicitly disabled in normal installation.

Color correction was withdrawn after comparison on the editing display.
Known issues: true60fps is not achieved. Actual
video delivery is approximately50fps in stable periods while the node still
offers nominal30fps and50fps (default50). OBS output frame rate does not prove source capture cadence.
Long-duration drift, active signal-loss recovery and other modes remain open.

Prerequisites: DKMS, current kernel headers/build tree, make, clang, ld.lld and LLVM utilities
(llvm-ar, llvm-nm, llvm-objcopy, llvm-objdump, llvm-readelf, llvm-strip). OBS with V4L2 and ALSA plugins. No IOMMU boot change is required on
the tested rig. Large contiguous allocation may still fail on other systems.

The installer checks that build-tree release metadata matches the running
kernel. A mismatch requires matching headers or a reboot into the installed
kernel before installation. It does not change boot settings for you.

Inspect without changes: python3 install.py --check
Install for the current kernel: sudo python3 install.py --install
Then reboot. The installer never loads, unloads, resets or flashes the card.
DKMS builds for future installed kernels. Review DKMS errors after upgrades.
Secure Boot requires a trusted module-signing key; enrollment is not automated.
The targeted PCI alias and soft dependency give this driver precedence over
sc0710 for the matching card without globally blacklisting sc0710.

In OBS add Video Capture Device (V4L2), select the HD60 Pro, YUV4201920x1080 at50fps. In Settings > Video set OBS output to50fps
(or60fps if desired). The source selection and OBS output rate are separate.
Add Audio Input Capture (ALSA), Custom device hw:HD60Audio,0, rate48000.
Video owns the hardware session: keep video active to receive audio. Audio-only
capture is not yet supported. Audio monitoring is optional in OBS; the meter
can move without playback to local speakers. No firmware upload is needed.

The driver deliberately retains registered DMA memory and cannot be unloaded
until reboot. Stop OBS normally. To upgrade/remove, close OBS and run the
installer action, then reboot; never force rmmod, PCI reset or unbind.
Remove future-boot installation: sudo python3 install.py --uninstall
Use the newest installed bundle: removal covers verified managed versions,
including retained rollback versions. It does not unload a driver.

Read-only diagnostics (no sudo needed for sysfs inventory):
  python3 check-readiness.py --json
After capture stops, inspect the last audio events:
  python3 decode-event-history.py
Save these reports with the kernel log when reporting a fault. The inventory
never authorizes forced unload or claims capture works from device visibility.

For upgrades, run the NEW bundle's installer:
  sudo python3 install.py --upgrade
It verifies the previous source/configuration and all installed kernel build
trees, builds all replacements before switching versions, and retains the old
source and DKMS builds for rollback. It never changes the loaded module.
Reboot to activate the replacement. A downgrade is deliberately refused.

Upgrade journals are under /var/log/hd60pro-upgrade-*/transaction.json.
A failed installation attempts to restore the previous version on every target
kernel and restore its configuration. A rollback-incomplete result requires
manual recovery; do not assume the next boot will load the expected driver.
Both source versions are retained for diagnosis. A power loss or killed
installer is not automatically recovered: inspect the journal and DKMS status.
A failed replacement's staged source may need manual cleanup before retrying;
the installer refuses to overwrite it. Preserve the journal first.

Use the newest installed bundle's --uninstall to remove all verified managed
versions, including retained rollback versions. Local edits cause refusal.
Failed DKMS removal retains source files/configuration and can be retried.
It does not forcibly unload the currently running driver.

Upgrade/removal failure handling has fixture coverage. The real0.1.16 to0.1.17
DKMS upgrade, reboot activation and a1000-frame video/8-second audio capture
passed on this rig, followed by a clean stop. Real multi-kernel upgrade and
removal validation remain outstanding.

Managed settings enable continuous capture, retained-buffer reuse, full-rate
probe,150ms initial audio discard and gated audio-only recovery. They disable
fault injection. Broader kernel/hardware validation and installation upgrade
coverage are incomplete. This remains experimental, not a production release.

0.1.18 release candidate changes only installation/readiness reporting and
this documentation. Capture source is unchanged from0.1.17. It checks the
LLVM utility tools before staging any installation, and provides recovery
next steps without bypassing kernel restart eligibility checks. No new60fps,
color, or audio-recovery claim is made by this release.

Removal verification: python3 check-removal.py reports
managed disk residue separately from the loaded module. Run after uninstall;
a loaded module is expected until reboot. It does not inspect arbitrary manual
copies or initramfs images, and never deletes files or unloads anything.

0.1.19 adds single-version source-integrity checks before removal and a
read-only removal inventory. Capture code is unchanged from0.1.18.

Read-only observed-rate check:
  python check-readiness.py --sample-seconds 10 --json
Run during an existing capture to sample delivered-frame and ALSA-push counters.
It does not open a capture client or send card commands. A stopped capture,
changed session/restart count, reboot, unavailable counter, or counter reset
invalidates the rate sample. Rates describe host delivery, not input frame rate,
frame pacing, audible content, or lip sync. Sampling accepts 1 through 30 seconds.

0.1.20 clarifies installed-source inventory and adds optional read-only rate
sampling. Capture sources are unchanged from0.1.19. Rate sampling does not
start capture, prove60fps, or verify lip sync.

0.1.20.1 adds nominal50fps V4L2 selection and makes it the default;30fps
remains available. This is a host-side negotiation change, not a hardware
clock or capture-throughput change. Delivery remains timestamped at the actual
hardware cadence and can fall below50fps. Selecting30 does not add a hardware
rate limiter. No synthetic frames are generated. Fresh hardware/OBS validation
of this version is pending; do not treat50fps selection as guaranteed50fps.
