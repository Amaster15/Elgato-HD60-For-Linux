#!/usr/bin/env python3
"""Read-only managed installation residue check; never unloads a module."""
import json
from pathlib import Path


def inspect(root=Path('/')):
    root=Path(root)
    residue=[]
    patterns=[
        ('sources','usr/src/hd60pro-linux-*'),
        ('dkms','var/lib/dkms/hd60pro-linux'),
        ('configuration','etc/modprobe.d/hd60pro-linux.conf'),
        ('modules','lib/modules/*/updates/dkms/hd60pro_audio_probe.ko*'),
        ('modules','usr/lib/modules/*/updates/dkms/hd60pro_audio_probe.ko*'),
    ]
    seen=set()
    for kind,pattern in patterns:
        for path in sorted(root.glob(pattern)):
            key=str(path.resolve())
            if key in seen:continue
            seen.add(key)
            residue.append({'kind':kind,'path':str(path)})
    loaded=(root/'sys/module/hd60pro_audio_probe').exists()
    return {'disk_residue':residue,'disk_removal_complete':not residue,
            'module_loaded':loaded,'reboot_required':loaded,
            'changes':False,
            'scope':'Managed source, DKMS state, configuration and updates/dkms modules; does not scan arbitrary manual copies or initramfs.',
            'next_step':('Managed files remain; inspect before removing.' if residue else
                         'Disk removal complete; reboot to release the loaded driver.' if loaded else
                         'No managed disk residue or loaded driver found.')}


if __name__=='__main__':
    print(json.dumps(inspect(),indent=2))
