/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_AUDIO_COPY_WINDOW_H
#define HD60_AUDIO_COPY_WINDOW_H
/* Helper98c0..98dc advances sequentially through four slots. Preserve a
 * one-slot margin for its next DMA. Both immediate pointers must progress
 * forward without reaching the selected slot or its preceding destination.
 * This is a bounded candidate check, not proof against invisible full wraps.
 */
static inline int hd60_audio_copy_window(unsigned int slot,unsigned int event_latest,
 unsigned int before,unsigned int after,unsigned long long elapsed_ns)
{
 unsigned int until_target,advanced,initial;
 if(slot>3 || event_latest>3 || before>3 || after>3 ||
    elapsed_ns>=10000000ULL) return 0;
 until_target=(slot-event_latest)&3u;
 if(!until_target) until_target=4;
 initial=(before-event_latest)&3u;
 advanced=(after-event_latest)&3u;
 return initial<=advanced && advanced+1<until_target;
}
#endif
