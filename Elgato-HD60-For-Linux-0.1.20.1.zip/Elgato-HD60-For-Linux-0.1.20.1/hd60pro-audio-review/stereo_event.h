/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_STEREO_EVENT_H
#define HD60_STEREO_EVENT_H
/* Product5, 48kHz S16 stereo, F=120 B=4, mode flags zero only.
 * Pure decoding: no I/O, acknowledgment, freshness or ownership guarantee.
 * Caller must use the ORIGINAL status for mailbox classification and ACK.
 * Only after validation may it pass video_status to the video-only guard.
 */
#define HD60_STEREO_EVENT_BIT 0x10000u
#define HD60_STEREO_ALLOWED_STATUS 0x10801u
#define HD60_STEREO_BLOCK_BYTES 1920u
#define HD60_STEREO_SLOT_BYTES 8192u /* run-gJljRS5k measured destinations */
struct hd60_stereo_event {
 unsigned int present, valid, lost, unknown;
 unsigned int slot, offset, bytes, video_status;
};
static inline struct hd60_stereo_event
hd60_decode_stereo_event(unsigned int status, unsigned int slots,
                         unsigned int registered_bytes)
{
 struct hd60_stereo_event e={0};
 if(status==0xffffffffu || (status&HD60_STEREO_EVENT_BIT && slots==0xffffffffu)) {
  e.lost=1;
  return e;
 }
 e.unknown=status&~HD60_STEREO_ALLOWED_STATUS;
 if(e.unknown) return e;
 e.present=!!(status&HD60_STEREO_EVENT_BIT);
 e.video_status=status&0x801u;
 if(!e.present) { e.valid=1; return e; }
 e.slot=slots&15u;
 if(e.slot>=4u) return e;
 e.offset=e.slot*HD60_STEREO_SLOT_BYTES;
 e.bytes=HD60_STEREO_BLOCK_BYTES;
 /* Subtraction avoids overflow; no sample pointer formed before this gate. */
 if(e.offset>registered_bytes || e.bytes>registered_bytes-e.offset) return e;
 e.valid=1;
 return e;
}
#endif
