/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_AUDIO_STARTUP_WINDOW_H
#define HD60_AUDIO_STARTUP_WINDOW_H
/* One initial discard window per START. Never reopens on an audio fault. */
static inline int hd60_audio_in_startup(unsigned long long start,
 unsigned long long now, unsigned int milliseconds)
{
 return milliseconds && (now < start ||
                         now-start < (unsigned long long)milliseconds*1000000);
}
#endif
