/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_INDEXED_AUDIO_EVENT_H
#define HD60_INDEXED_AUDIO_EVENT_H
/* ep.ko f14..f24/f34..f44: audio byte17=1 publishes bit(slot+16).
 * Slot is zero based here (firmware argument is 1 based). BAR4c remains
 * latest completion, and can advance independently of the pending mask.
 * Decode does not guarantee buffer ownership or exclude full ring wraps.
 */
#define HD60_INDEXED_AUDIO_ALLOWED_STATUS 0xf0801u
struct hd60_indexed_audio {
 unsigned int valid, lost, mask, latest, count, slots[4], video_status;
};
static inline struct hd60_indexed_audio
hd60_decode_indexed_audio(unsigned int status,unsigned int slots)
{
 struct hd60_indexed_audio e={0};
 unsigned int i,slot;
 if(status==0xffffffffu || ((status&0xf0000u) && slots==0xffffffffu)) {
  e.lost=1;return e;
 }
 if(status&~HD60_INDEXED_AUDIO_ALLOWED_STATUS) return e;
 e.mask=(status>>16)&15u;e.video_status=status&0x801u;
 if(!e.mask) { e.valid=1;return e; }
 e.latest=slots&15u;
 /* Decode full masks too: startup/STOP must ACK and discard them.
  * A live consumer must treat mask15 as overrun, never deliver that batch. */
 if(e.latest>3) return e;
 for(i=1;i<=4;i++) {
  slot=(e.latest+i)&3;
  if(e.mask&(1u<<slot)) e.slots[e.count++]=slot;
 }
 e.valid=1;return e;
}
#endif
