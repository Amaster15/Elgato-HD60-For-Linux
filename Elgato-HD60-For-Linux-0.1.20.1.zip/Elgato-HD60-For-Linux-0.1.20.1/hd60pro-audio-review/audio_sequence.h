/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_AUDIO_SEQUENCE_H
#define HD60_AUDIO_SEQUENCE_H
/* Fixed 48kHz, 480-frame blocks, four slots. This detects observed faults;
 * modulo slots and host timestamps do not prove producer continuity.
 * Once faulted, require an explicit new capture session, never auto-resync.
 */
enum hd60_audio_sequence_result {
 HD60_AUDIO_FIRST, HD60_AUDIO_NEXT, HD60_AUDIO_BAD_COPY,
 HD60_AUDIO_BAD_TIME, HD60_AUDIO_RING_GAP, HD60_AUDIO_BAD_SLOT,
 HD60_AUDIO_SEQUENCE_LATCHED
};
struct hd60_audio_sequence {
 unsigned int seen, faulted, slot;
 unsigned long long begin_ns, end_ns;
};
static inline enum hd60_audio_sequence_result
hd60_audio_sequence_accept(struct hd60_audio_sequence *s, unsigned int slot,
 unsigned long long begin, unsigned long long end, unsigned int stable_copy)
{
 enum hd60_audio_sequence_result r;
 if(s->faulted) return HD60_AUDIO_SEQUENCE_LATCHED;
 if(!stable_copy) r=HD60_AUDIO_BAD_COPY;
 else if(end<begin || (s->seen && begin<=s->end_ns)) r=HD60_AUDIO_BAD_TIME;
 else if(end-begin>=40000000ULL ||
         (s->seen && begin-s->begin_ns>=40000000ULL)) r=HD60_AUDIO_RING_GAP;
 else if(slot>3 || (s->seen && slot!=((s->slot+1)&3))) r=HD60_AUDIO_BAD_SLOT;
 else {
  r=s->seen ? HD60_AUDIO_NEXT : HD60_AUDIO_FIRST;
  s->seen=1; s->slot=slot; s->begin_ns=begin; s->end_ns=end;
  return r;
 }
 s->faulted=1;
 return r;
}
#endif
