#!/usr/bin/env python3
"""Read-only HD60 Pro inventory. Never loads modules or touches PCI config/MMIO."""
import argparse
import json
import platform
import shutil
import time
from pathlib import Path


def read(path):
    try:
        return Path(path).read_text().strip()
    except (OSError, UnicodeError):
        return None


def target(path):
    try:
        return str(path.resolve(strict=True)) if path.is_symlink() else None
    except OSError:
        return None


def module_assessment(params):
    """Conservative inventory labels, never authorization to stream or unload."""
    issues = []
    if params.get('session_state') == '4':
        issues.append('failed_session_requires_reboot')
    if params.get('diagnostic_error') not in (None, '0'):
        issues.append('diagnostic_error')
    if params.get('audio_sequence_fault') not in (None, '0'):
        issues.append('audio_sequence_fault')
    input_issue = {'1':'startup_hdmi_lock_absent', '2':'startup_input_mode_unsupported'}.get(params.get('input_status'))
    if input_issue:
        issues.append(input_issue)
    if params.get('audio_recovery_pending') in ('Y', '1'):
        issues.append('audio_fault_acknowledged_explicit_reopen_pending')
    if params.get('previous_audio_fault') not in (None, '0'):
        issues.append('prior_audio_fault_recorded')
    if params.get('audio_inject_gap_after_blocks') not in (None, '0'):
        issues.append('diagnostic_audio_injection_configured')
    duration = params.get('capture_duration_ms')
    if duration is None:
        issues.append('capture_duration_unknown')
    elif duration != '0':
        issues.append('bounded_diagnostic_not_continuous')
    if params.get('command_pending') in ('Y', '1'):
        issues.append('command_pending')
    if params.get('mappings_retained') in ('Y', '1'):
        issues.append('dma_retained_no_force_unload')
    if params.get('quarantined') in ('Y', '1'):
        issues.append('ownership_retained_no_force_unload')
    return dict(issues=issues, next_step=recovery_guidance(params), capture_verified_by_inventory=False,
                safe_unload_established=False)


def recovery_guidance(params):
    """User guidance only; the kernel retains authority over every restart gate."""
    if params.get('session_state') == '4' or params.get('diagnostic_error') not in (None, '0'):
        return 'Save diagnostics and reboot before another capture attempt; do not force unload or reset.'
    fault = params.get('audio_sequence_fault')
    if fault not in (None, '0', '2', '3', '4', '5'):
        return 'Unrecognized audio fault: save diagnostics and reboot; recovery is not established.'
    if fault in ('2', '3', '4', '5'):
        if params.get('audio_restart_test') not in ('Y', '1'):
            return 'Audio fault recovery is disabled or unknown; save diagnostics and reboot.'
        return ('Stop any recording and close OBS normally. Save the stopped event history. '
                'The driver may permit an explicit reopen only after all clean-stop checks pass; '
                'this inventory does not establish restart eligibility.')
    if params.get('audio_recovery_pending') in ('Y', '1'):
        return 'Audio recovery is pending; the driver must validate the next explicit reopen. Do not force reset.'
    return 'No recovery action inferred from this snapshot; capture and safe unload are not established by inventory.'


def collect():
    kernel = platform.release()
    devices = []
    for p in sorted(Path('/sys/bus/pci/devices').glob('*')):
        if read(p / 'vendor') != '0x12ab' or read(p / 'device') != '0x0380':
            continue
        devices.append(dict(pci=p.name, subsystem_vendor=read(p/'subsystem_vendor'),
                            subsystem_device=read(p/'subsystem_device'),
                            driver=target(p/'driver'), iommu_group=target(p/'iommu_group')))
    modules = []
    fields = ('finished', 'diagnostic_error', 'delivered_frames', 'stop_event',
              'master_off_verified', 'command_pending', 'mappings_retained', 'quarantined',
              'session_state', 'completed_sessions', 'restart_attempts',
              'capture_duration_ms', 'full_rate_probe', 'capture_mirror', 'client_stop_requested',
              'previous_audio_fault', 'audio_recovery_pending', 'audio_recovered_sessions',
              'audio_restart_test', 'audio_inject_gap_after_blocks', 'audio_gap_injected',
              'input_status', 'startup_retry_ready', 'audio_event_history_count', 'audio_blocks', 'alsa_pushes', 'alsa_running', 'audio_sequence_fault')
    for p in sorted(Path('/sys/module').glob('hd60pro*')):
        params = {k: read(p/'parameters'/k) for k in fields}
        available = {k:v for k,v in params.items() if v is not None}
        modules.append(dict(name=p.name, parameters=available,
                            assessment=module_assessment(available)))
    nodes = []
    for p in sorted(Path('/sys/class/video4linux').glob('video*')):
        name = read(p/'name')
        if name and ('hd60' in name.lower() or 'elgato' in name.lower()):
            nodes.append(dict(node='/dev/'+p.name, name=name))
    tools = {name:shutil.which(name) for name in ('make', 'clang', 'ld.lld', 'modprobe', 'v4l2-ctl', 'obs', 'dkms', 'arecord')}
    retained = any(m['parameters'].get('mappings_retained') == 'Y' for m in modules)
    ownership_retained = retained or any(
        m['parameters'].get('quarantined') in ('Y', '1') for m in modules)
    return dict(schema=1, kernel=kernel, boot_id=read('/proc/sys/kernel/random/boot_id'),
                kernel_build_tree=Path('/lib/modules',kernel,'build','Makefile').is_file(),
                tools=tools, devices=devices, modules=modules, video_nodes=nodes,
                retained_dma=retained, ownership_retained=ownership_retained, writes_performed=False,
                release_ready=False,
                limitations=['PC-source continuous OBS close/reopen and startup cancellation verified on the test rig; settings-change recovery remains unverified.',
                             'PC-source lip-sync playback passed at zero offset. GH4 command-line continuous capture passed 360 seconds of video with330 seconds of audio and stop/reopen; GH4 OBS ran over five minutes and stopped cleanly on0.1.14; user confirmed short-clip lip-sync. Classified audio-fault recovery and normal audio-client reopen have passed bounded tests; broader fault coverage and long-term synchronization remain unverified. Color correction was withdrawn after comparison on the editing display.',
                             'Automatic unload and DMA release not established.',
                             'GH4 capture at 60 fps remains unverified; current video path does not establish 60 fps delivery.'])


def measure_rates(before, after, elapsed):
    """Counter deltas only; never infer signal quality or synchronized playback."""
    results = []
    old = {m['name']: m['parameters'] for m in before['modules']}
    for module in after['modules']:
        name, end = module['name'], module['parameters']
        start = old.get(name, {})
        reasons = []
        if not before.get('boot_id') or before['boot_id'] != after.get('boot_id'):
            reasons.append('boot_changed_or_unknown')
        if elapsed <= 0:
            reasons.append('invalid_elapsed_time')
        for field in ('completed_sessions', 'restart_attempts'):
            if start.get(field) is None or start.get(field) != end.get(field):
                reasons.append(field + '_changed_or_unknown')
        if start.get('session_state') != '1' or end.get('session_state') != '1':
            reasons.append('capture_not_running_at_both_endpoints')
        rates = {}
        for field in ('delivered_frames', 'alsa_pushes'):
            try:
                delta = int(end[field]) - int(start[field])
                if delta < 0:
                    raise ValueError('counter reset or wrap')
                rates[field] = dict(delta=delta, per_second=delta / elapsed if elapsed > 0 else None)
            except (KeyError, ValueError, TypeError):
                reasons.append(field + '_unavailable_reset_or_wrapped')
        results.append(dict(module=name, valid=not reasons, reasons=reasons,
                            counters=rates if not reasons else {}))
    return dict(elapsed_seconds=elapsed, modules=results,
                interpretation='Endpoint counter samples only; no frame-pacing, audio-content, or lip-sync verification.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--json', action='store_true', help='print machine-readable inventory')
    parser.add_argument('--sample-seconds', type=int, choices=range(1, 31), metavar='1..30',
                        help='read counters twice without starting capture')
    args = parser.parse_args()
    report = collect()
    if args.sample_seconds:
        started = time.monotonic()
        time.sleep(args.sample_seconds)
        after = collect()
        report['rate_sample'] = measure_rates(report, after, time.monotonic() - started)
    if args.json:
        print(json.dumps(report, indent=2))
        return
    print('HD60 Pro read-only readiness report')
    print('Kernel:',report['kernel'])
    if 'rate_sample' in report:
        print('Observed counter rates:', json.dumps(report['rate_sample'], sort_keys=True))
    print('Matching PCI cards:',len(report['devices']))
    for d in report['devices']:
        print(f"  {d['pci']}: driver={d['driver'] or 'unbound'}, IOMMU={d['iommu_group'] or 'none'}")
    print('Kernel build tree:', 'present' if report['kernel_build_tree'] else 'missing')
    print('Missing tools:', ', '.join(k for k,v in report['tools'].items() if not v) or 'none')
    for m in report['modules']:
        print('Loaded:',m['name'],json.dumps(m['parameters'],sort_keys=True))
        print('Inventory issues:', ', '.join(m['assessment']['issues']) or 'none detected; capture remains unverified')
        print('Next step:', m['assessment']['next_step'])
    for m in report['modules']:
        params = m['parameters']
        if params.get('session_state') == '4':
            print('CAPTURE UNAVAILABLE: the loaded driver has latched a failed session; reboot before another capture attempt.')
            print('A visible video node does not mean this session can stream. Do not force unload or reset it.')
        elif params.get('diagnostic_error') not in (None, '0'):
            print('DIAGNOSTIC ERROR:', params['diagnostic_error'], '— capture readiness is not established.')
        duration = m['parameters'].get('capture_duration_ms')
        if duration is not None and duration != '0':
            print(f'DIAGNOSTIC BUILD: capture is limited to {duration} ms; unsuitable for continuous OBS recording.')
        if m['parameters'].get('full_rate_probe') in ('Y', '1'):
            print('Full-rate probe enabled: this does not establish 60 fps delivery.')
    for n in report['video_nodes']:
        print('Video:',n['node'],n['name'])
    if report['ownership_retained']:
        print('Retained device ownership detected: do not force unload, unbind, or reset the driver.')
        print('Use a fresh boot before switching test builds.')
    elif report['modules']:
        print('Experimental module loaded; absence of retention telemetry does not establish safe unload.')
    print('Release status: experimental; inventory is not a capture or installation success test.')
    for item in report['limitations']:
        print('  -',item)
    print('No modules loaded, no device commands sent, no system settings changed.')

if __name__ == '__main__':
    main()
