#!/usr/bin/env python3
"""Read-only inventory for upgrade planning; never execute installed package code."""
import ast
import hashlib
import json
from pathlib import Path


def inspect(source_root=Path('/usr/src'), config=Path('/etc/modprobe.d/hd60pro-linux.conf')):
    packages = []
    for source in sorted(source_root.glob('hd60pro-linux-*')):
        item = {'source': str(source), 'issues': []}
        try:
            if source.is_symlink() or not source.is_dir():
                raise ValueError('source is not an ordinary directory')
            manifest_path = source / 'manifest.json'
            if manifest_path.is_symlink():
                raise ValueError('manifest is a symlink')
            manifest = json.loads(manifest_path.read_text())
            if not isinstance(manifest, dict) or 'install.py' not in manifest:
                raise ValueError('missing installer in manifest')
            for rel, digest in manifest.items():
                path = source / rel
                if (not isinstance(digest, str) or Path(rel).is_absolute()
                        or '..' in Path(rel).parts
                        or not path.resolve().is_relative_to(source.resolve())
                        or any(p.is_symlink() for p in [path, *path.parents] if p != source.parent)
                        or not path.is_file()
                        or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
                    raise ValueError('source integrity failed: ' + rel)
            # Parse literals; importing the old installer would run arbitrary code.
            values = {}
            for node in ast.parse((source / 'install.py').read_text()).body:
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id in ('NAME', 'VERSION', 'CONFIG_TEXT'):
                            values[target.id] = ast.literal_eval(node.value)
            if (values.get('NAME') != 'hd60pro-linux'
                    or source.name != 'hd60pro-linux-' + str(values.get('VERSION'))
                    or not isinstance(values.get('CONFIG_TEXT'), str)):
                raise ValueError('installer identity/configuration missing or inconsistent')
            item['version'] = values['VERSION']
            item['verified_files'] = len(manifest)
            item['config_matches'] = (not config.is_symlink() and config.is_file()
                                      and config.read_text() == values['CONFIG_TEXT'])
            if not item['config_matches']:
                item['issues'].append('managed configuration differs or is absent')
        except (OSError, ValueError, TypeError, SyntaxError) as exc:
            item['issues'].append(str(exc))
        packages.append(item)
    config_issue = 'managed configuration differs or is absent'
    current = [p for p in packages if p.get('config_matches') and not p['issues']]
    intact = bool(packages) and all(
        all(issue == config_issue for issue in p['issues']) for p in packages)
    return {'packages': packages, 'changes': False,
            'current_config_version': current[0]['version'] if len(current) == 1 else None,
            'current_source_verified': len(current) == 1,
            'all_retained_sources_verified': intact,
            'retained_versions': [p['version'] for p in packages
                                  if 'version' in p and not p.get('config_matches')],
            'rollback_source_verified': len(packages) == 1 and not packages[0]['issues'],
            'upgrade_ready': False,
            'upgrade_assessment': 'not_performed_by_source_inventory',
            'remaining': 'Source/configuration inventory only. upgrade_ready=false is not a '
                         'failed installation verdict. The installer separately checks DKMS '
                         'targets and rollback before an upgrade; loaded-module state is not inspected.'}


if __name__ == '__main__':
    print(json.dumps(inspect(), indent=2))
