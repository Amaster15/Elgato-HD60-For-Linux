/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_FRAME_EVENT_H
#define HD60_FRAME_EVENT_H
/* Current channel-zero, four-slot primary pool only. Pure decoding, no I/O.
 * Other channels/kinds are not silently acknowledged by this policy.
 * A frame notification is not proof that CPU buffer ownership is safe.
 */
struct hd60_frame_event {
 unsigned int mailbox, frame, slot, unknown, invalid_counter, lost;
};
static inline struct hd60_frame_event
hd60_decode_frame_event(unsigned int status, unsigned int counter40)
{
 struct hd60_frame_event e = {0};
 if(status == 0xffffffffu) { e.lost=1; return e; }
 e.mailbox=!!(status&0x800u);
 e.frame=!!(status&1u);
 e.unknown=status&~0x801u;
 if(e.frame) {
  e.slot=counter40&15u;
  e.invalid_counter=e.slot>=4u;
 }
 return e;
}
#endif
