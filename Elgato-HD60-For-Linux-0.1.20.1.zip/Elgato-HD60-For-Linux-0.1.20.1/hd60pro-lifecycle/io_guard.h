/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60PRO_IO_GUARD_H
#define HD60PRO_IO_GUARD_H
#include "cleanup_policy.h"
typedef unsigned int (*hd60_read_fn)(void *context);
typedef void (*hd60_write_fn)(void *context, unsigned int value);
static inline int hd60_io_allowed(const struct hd60_lifetime *s)
{
 /* This guard is for the non-DMA, polled diagnostic only. */
 return s->health == HD60_HEALTH_OK && s->config_valid && !s->unexpected_event &&
        !(s->command & 4u) && (s->command & 0x400u);
}
/* This diagnostic's read protocol has no legitimate all-ones responses.
 * Do not reuse this assumption for arbitrary data registers or capture data.
 */
static inline unsigned int hd60_guarded_read(struct hd60_lifetime *s,
 void *context, hd60_read_fn read, int is_status)
{
 unsigned int value;
 if (!hd60_io_allowed(s)) return 0xffffffffu;
 value = read(context);
 if (value == 0xffffffffu) s->health = HD60_HEALTH_LOST;
 if (is_status) hd60_observe_status(s, value);
 return value;
}
static inline void hd60_guarded_write(struct hd60_lifetime *s,
 void *context, hd60_write_fn write, unsigned int value)
{
 if (hd60_io_allowed(s)) write(context, value);
}
#endif
