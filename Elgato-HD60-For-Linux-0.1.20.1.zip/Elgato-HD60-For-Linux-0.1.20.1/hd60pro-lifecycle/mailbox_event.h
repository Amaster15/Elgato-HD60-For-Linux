/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_MAILBOX_EVENT_H
#define HD60_MAILBOX_EVENT_H
/* Pure classification: no acknowledgement and no assumption that a repeated
 * START completion is benign. The caller snapshots the actual opcode once. */
enum hd60_mailbox_result {
 HD60_MAILBOX_ABSENT, HD60_MAILBOX_MATCH,
 HD60_MAILBOX_UNSOLICITED, HD60_MAILBOX_WRONG_OPCODE
};
static inline enum hd60_mailbox_result hd60_classify_mailbox(
 unsigned int status, unsigned int pending,
 unsigned int expected, unsigned int actual)
{
 if (!(status & 0x800u)) return HD60_MAILBOX_ABSENT;
 if (!pending) return HD60_MAILBOX_UNSOLICITED;
 return expected==actual ? HD60_MAILBOX_MATCH : HD60_MAILBOX_WRONG_OPCODE;
}
#endif
