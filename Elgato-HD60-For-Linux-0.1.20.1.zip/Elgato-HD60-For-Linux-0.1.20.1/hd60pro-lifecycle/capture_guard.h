/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_CAPTURE_GUARD_H
#define HD60_CAPTURE_GUARD_H
#include "cleanup_policy.h"
#include "frame_event.h"
/* Separate from io_guard.h: polled, channel-zero capture policy only.
 * Readiness bits: pools, receiver, video mode, audio mode, owned mappings.
 * No routine here performs I/O or infers DMA drain from a STOP event.
 */
#define HD60_CAPTURE_READY 31u
struct hd60_capture_guard {
 struct hd60_lifetime life;
 unsigned int ready, master_expected, transition, command_pending;
 unsigned int start_submitted, fault;
};
static inline int hd60_capture_io_allowed(const struct hd60_capture_guard *g)
{
 return g->life.health==HD60_HEALTH_OK && g->life.config_valid &&
        !g->fault && !g->transition && !g->life.unexpected_event &&
        (g->life.command&0x400u) && (g->life.command&2u) &&
        (!!(g->life.command&4u)==!!g->master_expected);
}
static inline int hd60_capture_arm_master(struct hd60_capture_guard *g)
{
 if(!hd60_capture_io_allowed(g) || g->ready!=HD60_CAPTURE_READY ||
    g->command_pending || g->life.pending_event || g->master_expected ||
    !g->life.registered_buffers || !g->life.allocated_buffers) return 0;
 /* Set before pci_set_master: even a failed readback cannot justify freeing. */
 g->life.dma_ever_enabled=1;
 g->life.dma_drained=0;
 g->transition=1;
 g->master_expected=1;
 return 1;
}
static inline void hd60_capture_config(struct hd60_capture_guard *g,
                                       int error, unsigned int command)
{
 hd60_observe_config(&g->life,error,command);
 if(!g->life.config_valid || !(command&0x400u) || !(command&2u) ||
    (!!(command&4u)!=!!g->master_expected)) g->fault=1;
 g->transition=0;
}
static inline int hd60_capture_can_start(const struct hd60_capture_guard *g)
{
 return hd60_capture_io_allowed(g) && g->master_expected &&
        g->ready==HD60_CAPTURE_READY && !g->command_pending &&
        !g->life.pending_event && !g->start_submitted;
}
/* Call before the START doorbell, never after it. A timeout leaves the
 * command pending and prevents a speculative STOP from replacing it. */
static inline int hd60_capture_submit_start(struct hd60_capture_guard *g)
{
 if (!hd60_capture_can_start(g)) return 0;
 g->start_submitted=1;
 g->command_pending=1;
 g->life.stop_confirmed=0;
 return 1;
}
/* Disabling bus mastering is containment, not evidence that DMA drained.
 * Config readback must complete the transition even on a faulted lifecycle. */
static inline void hd60_capture_disarm_master(struct hd60_capture_guard *g)
{
 g->transition=1;
 g->master_expected=0;
}
static inline struct hd60_frame_event
hd60_capture_status(struct hd60_capture_guard *g, unsigned int status,
                    unsigned int counter40)
{
 struct hd60_frame_event e=hd60_decode_frame_event(status,counter40);
 g->life.pending_event=!!status;
 if(e.lost) g->life.health=HD60_HEALTH_LOST;
 if(e.unknown || e.invalid_counter || (e.frame && !g->start_submitted)) {
  g->life.unexpected_event=1;
  g->fault=1;
 }
 return e;
}
static inline struct hd60_cleanup_plan
hd60_capture_cleanup(const struct hd60_capture_guard *g)
{
 struct hd60_cleanup_plan retained={1,0,0,0};
 if(g->fault || g->transition || g->command_pending) return retained;
 return hd60_plan_cleanup(&g->life);
}
#endif
