/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60PRO_CLEANUP_POLICY_H
#define HD60PRO_CLEANUP_POLICY_H
/* Hardware-independent policy for the replacement driver. No I/O here.
 * A stop mailbox event must NOT be used as evidence of drained PCI DMA.
 */
enum hd60_health { HD60_HEALTH_UNKNOWN, HD60_HEALTH_OK, HD60_HEALTH_LOST };
struct hd60_lifetime {
 enum hd60_health health;
 unsigned int registered_buffers;
 unsigned int allocated_buffers;
 unsigned int dma_ever_enabled;
 unsigned int dma_drained;
 unsigned int stop_confirmed;
 unsigned int unexpected_event;
 unsigned int pending_event;
 unsigned int config_valid;
 unsigned int command;
 int config_error;
};
struct hd60_cleanup_plan {
 unsigned int retain_ownership;
 unsigned int release_buffers;
 unsigned int restore_interrupts;
 unsigned int normal_pci_cleanup;
};
static inline void hd60_observe_config(struct hd60_lifetime *s,
                                      int error, unsigned int command)
{
 s->config_error = error;
 s->command = command;
 s->config_valid = !error && command <= 0xffffu && command != 0xffffu;
 if (!s->config_valid) s->health = HD60_HEALTH_LOST;
 else if (s->health != HD60_HEALTH_LOST) s->health = HD60_HEALTH_OK;
}
static inline void hd60_observe_status(struct hd60_lifetime *s,
                                      unsigned int status)
{
 s->pending_event = status != 0;
 if (status == 0xffffffffu) s->health = HD60_HEALTH_LOST;
 else if (status != 0 && status != 0x800u) s->unexpected_event = 1;
}
static inline struct hd60_cleanup_plan
hd60_plan_cleanup(const struct hd60_lifetime *s)
{
 struct hd60_cleanup_plan p = {1, 0, 0, 0};
 /* UNKNOWN is not equivalent to healthy. Lost health is sticky until a new
  * device lifecycle, not erased by a later successful config read.
  * PCI_COMMAND_MASTER = 0x4, PCI_COMMAND_INTX_DISABLE = 0x400.
  */
 if (s->health != HD60_HEALTH_OK || !s->config_valid ||
     (s->command & 4u) || !(s->command & 0x400u) || s->unexpected_event || s->pending_event)
  return p;
 if (s->registered_buffers && !s->stop_confirmed) return p;
 if (s->dma_ever_enabled && !s->dma_drained) return p;
 p.retain_ownership = 0;
 p.release_buffers = s->allocated_buffers != 0;
 p.restore_interrupts = 1;
 p.normal_pci_cleanup = 1;
 return p;
}
#endif
