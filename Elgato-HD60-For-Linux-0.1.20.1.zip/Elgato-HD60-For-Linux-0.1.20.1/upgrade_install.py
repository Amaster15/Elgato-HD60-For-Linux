"""Preflight and staging for the disk-only upgrade transaction."""
import importlib.util
import re
import shutil
import tempfile
from pathlib import Path
from upgrade_transaction import upgrade


def version_key(value):
    if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', value):
        raise RuntimeError('Unsupported package version: ' + value)
    return tuple(map(int, value.split('.')))


def remove_retained(installer, kernel):
    """Remove all verified package versions, keeping sources until DKMS succeeds."""
    spec = importlib.util.spec_from_file_location('installed_inventory',
                                                installer.HERE / 'inspect-installed.py')
    inventory = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(inventory)
    packages = inventory.inspect(installer.SOURCE.parent, installer.CONFIG)['packages']
    config_issue = 'managed configuration differs or is absent'
    if not packages or any(any(i != config_issue for i in p['issues']) for p in packages):
        raise RuntimeError('Installed sources failed integrity checks; no removal attempted')
    current = [p for p in packages if p.get('config_matches')]
    if len(current) != 1 or current[0]['version'] != installer.VERSION:
        raise RuntimeError('Use the current managed package to uninstall retained versions')
    state = installer.DKMS_STATE.parent
    known = {p['version'] for p in packages}
    for entry in (state.iterdir() if state.exists() else []):
        if entry.name.startswith('kernel-') or entry.name == 'original_module':
            continue
        if entry.name not in known:
            raise RuntimeError('Unknown DKMS package state retained: ' + str(entry))
    # Old versions first: if they cannot be removed, keep the current install.
    packages.sort(key=lambda p: (p['version'] == installer.VERSION, version_key(p['version'])))
    for package in packages:
        version = package['version']
        if (state / version).exists():
            installer.run('dkms', 'remove', '-m', installer.NAME, '-v', version, '--all')
    if installer.CONFIG.is_symlink() or installer.CONFIG.read_text() != installer.CONFIG_TEXT:
        raise RuntimeError('Configuration changed during removal; sources retained')
    installer.CONFIG.unlink()
    for package in packages:
        shutil.rmtree(package['source'])
    installer.run('depmod', '-a', kernel)


def active(state, version, kernel, arch):
    link = state / ('kernel-' + kernel + '-' + arch)
    target = state / version / kernel / arch
    return (link.is_symlink() and link.resolve() == target.resolve()
            and (target / 'module').is_dir()
            and any((target / 'module').glob('hd60pro_audio_probe.ko*')))


def plan(installer, arch):
    spec = importlib.util.spec_from_file_location('installed_inventory',
                                                installer.HERE / 'inspect-installed.py')
    inventory = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(inventory)
    packages = inventory.inspect(installer.SOURCE.parent, installer.CONFIG)['packages']
    # Retained old versions may have a different managed config, but their
    # source integrity must still pass before using them as rollback material.
    config_issue = 'managed configuration differs or is absent'
    if any(any(issue != config_issue for issue in p['issues']) for p in packages):
        raise RuntimeError('Installed source integrity failed; inspect-installed.py has details')
    current = [p for p in packages if p.get('config_matches')]
    if len(current) != 1:
        raise RuntimeError('Cannot identify one current managed configuration')
    old = current[0]['version']
    if any(version_key(p['version']) >= version_key(installer.VERSION) for p in packages):
        raise RuntimeError('Upgrade requires a version newer than every retained package')
    state = installer.DKMS_STATE.parent
    if installer.SOURCE.exists() or installer.DKMS_STATE.exists():
        raise RuntimeError('Replacement source or DKMS state already exists')
    source_link = state / old / 'source'
    if not source_link.is_symlink() or source_link.resolve() != Path(current[0]['source']).resolve():
        raise RuntimeError('Previous DKMS source link does not match verified package')
    targets = []
    for link in sorted(state.glob('kernel-*')):
        try:
            parts = link.resolve().relative_to(state.resolve()).parts
        except ValueError:
            raise RuntimeError('DKMS active link escapes package state')
        if len(parts) != 3:
            raise RuntimeError('Unexpected DKMS active link: ' + str(link))
        version, kernel, target_arch = parts
        if (link.name != 'kernel-' + kernel + '-' + target_arch
                or version != old or target_arch != arch
                or not active(state, old, kernel, target_arch)):
            raise RuntimeError('Mixed, foreign or incomplete DKMS installation: ' + str(link))
        prerequisites = installer.build_prerequisites(kernel)
        if prerequisites['build_issues']:
            raise RuntimeError('Missing build prerequisites for installed kernel ' + kernel + ': ' + str(prerequisites))
        targets.append((kernel, target_arch))
    if not targets:
        raise RuntimeError('No installed DKMS targets found')
    return old, targets


def execute(installer, manifest, arch):
    old, targets = plan(installer, arch)
    old_config = installer.CONFIG.read_text()
    stage = Path(tempfile.mkdtemp(prefix='.hd60pro-upgrade-', dir=installer.SOURCE.parent))
    try:
        for rel in manifest:
            dest = stage / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(installer.HERE / rel, dest)
        shutil.copy2(installer.HERE / 'manifest.json', stage / 'manifest.json')
        stage.chmod(0o755)
        stage.rename(installer.SOURCE)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    # Retain staged sources on failure; the journal identifies recovery state.
    journal_dir = Path(tempfile.mkdtemp(prefix='hd60pro-upgrade-', dir='/var/log'))
    journal = journal_dir / 'transaction.json'
    print('Upgrade journal: ' + str(journal), flush=True)
    return upgrade(name=installer.NAME, old=old, new=installer.VERSION,
                   targets=targets, config=installer.CONFIG, old_config=old_config,
                   new_config=installer.CONFIG_TEXT, journal=journal, run=installer.run,
                   installed=lambda v, k, a: active(installer.DKMS_STATE.parent, v, k, a))
