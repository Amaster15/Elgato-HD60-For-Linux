"""Disk-only DKMS upgrade engine. Caller verifies sources, prerequisites and lock.

Both source versions are retained. No module load/unload or card operation.
The journal is evidence/recovery guidance, not a claim of power-loss atomicity.
"""
import json
import os
import tempfile
from pathlib import Path


def atomic_text(path, text):
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        Path(temporary).unlink(missing_ok=True)


def upgrade(*, name, old, new, targets, config, old_config, new_config,
            journal, run, installed):
    """Targets are (kernel, arch); installed verifies active DKMS state.

    New source is staged but not registered; old binaries must already exist.
    Caller holds the installer lock and rejects pre-existing new DKMS state.
    """
    if not targets or len(set(targets)) != len(targets) or old == new:
        raise ValueError('Invalid upgrade targets/versions')
    config = Path(config)
    if config.is_symlink() or config.read_text() != old_config:
        raise RuntimeError('Configuration changed before upgrade')
    if not all(installed(old, kernel, arch) for kernel, arch in targets):
        raise RuntimeError('Previous version is not installed on every target')
    state = dict(old=old, new=new, targets=targets, phase='prepared',
                 rollback_errors=[], module_touched=False)

    def record(phase):
        state['phase'] = phase
        atomic_text(journal, json.dumps(state, indent=2) + '\n')

    record('prepared')
    add_attempted = False
    switch_attempted = False
    config_replaced = False
    try:
        add_attempted = True
        record('adding')
        run('dkms', 'add', '-m', name, '-v', new)
        # Every build must succeed before replacing any installed module.
        for kernel, arch in targets:
            record('building:' + kernel + ':' + arch)
            run('dkms', 'build', '-m', name, '-v', new, '-k', kernel, '-a', arch)
        if config.is_symlink() or config.read_text() != old_config:
            raise RuntimeError('Configuration changed while building')
        for kernel, arch in targets:
            switch_attempted = True
            record('installing:' + kernel + ':' + arch)
            run('dkms', 'install', '-m', name, '-v', new, '-k', kernel, '-a', arch, '--force')
            if not installed(new, kernel, arch):
                raise RuntimeError('DKMS did not activate replacement for ' + kernel)
        if config.is_symlink() or config.read_text() != old_config:
            raise RuntimeError('Configuration changed during installation')
        record('replacing-configuration')
        # Mark the attempt first: atomic replacement can succeed before fsync fails.
        config_replaced = True
        atomic_text(config, new_config)
        for kernel, _ in targets:
            run('depmod', '-a', kernel)
        record('complete-reboot-required')
    except BaseException as original:
        state['error'] = str(original)
        try:
            record('rolling-back')
        except OSError as exc:
            state['rollback_errors'].append('journal: ' + str(exc))
        if add_attempted:
            try:
                run('dkms', 'remove', '-m', name, '-v', new, '--all')
            except Exception as exc:
                state['rollback_errors'].append('remove replacement: ' + str(exc))
        if switch_attempted:
            for kernel, arch in targets:
                try:
                    run('dkms', 'install', '-m', name, '-v', old,
                        '-k', kernel, '-a', arch, '--force')
                    if not installed(old, kernel, arch):
                        raise RuntimeError('Previous version did not become active')
                    run('depmod', '-a', kernel)
                except Exception as exc:
                    state['rollback_errors'].append(kernel + ': ' + str(exc))
        if config_replaced:
            try:
                if config.is_symlink() or config.read_text() not in (old_config, new_config):
                    raise RuntimeError('Concurrent configuration edit retained')
                atomic_text(config, old_config)
            except Exception as exc:
                state['rollback_errors'].append('configuration: ' + str(exc))
        record('rollback-incomplete' if state['rollback_errors'] else 'rolled-back')
        if state['rollback_errors']:
            raise RuntimeError('Upgrade failed; recovery required. Both source versions retained. See ' + str(journal)) from original
        raise
    return state
