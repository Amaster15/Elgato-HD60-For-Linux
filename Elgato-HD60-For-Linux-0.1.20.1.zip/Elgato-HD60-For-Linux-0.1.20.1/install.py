#!/usr/bin/env python3
"""Transactional DKMS staging; never load, unload, reset or program the card."""
import argparse,fcntl,hashlib,json,os,platform,re,shutil,subprocess,sys,tempfile
from pathlib import Path
NAME='hd60pro-linux'; VERSION='0.1.20.1'; MODULE='hd60pro_audio_probe'
SOURCE=Path('/usr/src')/f'{NAME}-{VERSION}'
DKMS_STATE=Path('/var/lib/dkms')/NAME/VERSION
CONFIG=Path('/etc/modprobe.d/hd60pro-linux.conf')
CONFIG_TEXT='''# Managed by hd60pro-linux 0.1.20.1
options hd60pro_audio_probe run_bounded_test=1 reuse_test=1 capture_duration_ms=0 full_rate_probe=1 audio_startup_ms=150 audio_restart_test=1 audio_inject_gap_after_blocks=0
alias pci:v000012ABd00000380sv00001CFAsd00000003bc*sc*i* hd60pro_audio_probe
softdep sc0710 pre: hd60pro_audio_probe
'''
HERE=Path(__file__).resolve().parent

def run(*args): subprocess.run(args,check=True)
def verify():
 manifest=json.loads((HERE/'manifest.json').read_text())
 for rel,digest in manifest.items():
  p=(HERE/rel).resolve()
  if not p.is_relative_to(HERE) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
   raise RuntimeError('Bundle integrity check failed: '+rel)
 return manifest

def secure_boot():
 efi=Path('/sys/firmware/efi')
 if not efi.exists(): return False
 paths=list((efi/'efivars').glob('SecureBoot-*'))
 if len(paths)!=1:return None
 try:return paths[0].read_bytes()[4]!=0
 except (OSError,IndexError):return None

def build_prerequisites(kernel, modules=Path('/lib/modules')):
 build=modules/kernel/'build'
 release_file=build/'include/config/kernel.release'
 try: release=release_file.read_text().strip()
 except OSError: release=None
 # The bundle builds with LLVM=1; clang and lld alone are insufficient.
 tools=['dkms','make','clang','ld.lld','llvm-ar','llvm-nm','llvm-objcopy',
        'llvm-objdump','llvm-readelf','llvm-strip','depmod']
 missing=[t for t in tools if not shutil.which(t)]
 headers=(build/'Makefile').is_file()
 issues=[]
 if missing: issues.append('missing_build_tools')
 if not headers: issues.append('missing_kernel_build_tree')
 if release is None: issues.append('missing_kernel_release_metadata')
 elif release!=kernel: issues.append('kernel_build_release_mismatch')
 return dict(headers=headers,missing_tools=missing,build_release=release,
             build_matches_running_kernel=release==kernel,build_issues=issues)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 g=parser.add_mutually_exclusive_group(required=True)
 for option in ['check','install','upgrade','uninstall']:g.add_argument('--'+option,action='store_true')
 args=parser.parse_args();manifest=verify();kernel=platform.release()
 prerequisites=build_prerequisites(kernel)
 loaded=Path('/sys/module',MODULE).exists()
 if args.check:
  print(json.dumps(dict(kernel=kernel,**prerequisites,
   secure_boot=secure_boot(),loaded=loaded,source_exists=SOURCE.exists(),
   config_exists=CONFIG.exists(),bundle_files=len(manifest),changes=False),indent=2));return
 if os.geteuid()!=0:raise RuntimeError('Run install/uninstall with sudo.')
 with open('/run/lock/hd60pro-linux.lock','w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if args.uninstall:
   retained=[p for p in SOURCE.parent.glob(NAME+'-*') if p!=SOURCE]
   if retained:
    from types import SimpleNamespace
    from upgrade_install import remove_retained
    remove_retained(SimpleNamespace(**globals()),kernel)
    print('Removed all managed versions from disk. Loaded driver untouched; reboot before reuse.')
    return
   if CONFIG.exists() and CONFIG.read_text()!=CONFIG_TEXT:raise RuntimeError('Configuration was modified; refusing to remove it.')
   if not SOURCE.is_dir() or (SOURCE/'manifest.json').read_text()!=(HERE/'manifest.json').read_text():
    raise RuntimeError('Installed source manifest differs or is missing; refusing removal.')
   # A matching manifest alone does not prove its installed files are unchanged.
   if SOURCE.is_symlink() or (SOURCE/'manifest.json').is_symlink():
    raise RuntimeError('Installed source or manifest is a symlink; refusing removal.')
   for rel,digest in manifest.items():
    path=SOURCE/rel
    if (not path.resolve().is_relative_to(SOURCE.resolve()) or
        any(p.is_symlink() for p in [path,*path.parents] if p!=SOURCE.parent) or
        not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest):
     raise RuntimeError('Installed source integrity failed; refusing removal: '+rel)
   run('dkms','remove','-m',NAME,'-v',VERSION,'--all')
   CONFIG.unlink(missing_ok=True);shutil.rmtree(SOURCE)
   run('depmod','-a',kernel)
   print('Removed from disk. Loaded driver was not touched; reboot before reuse.');return
  if prerequisites['build_issues']:
   guidance=[]
   if prerequisites['missing_tools']:
    guidance.append('Install the missing build tools: '+', '.join(prerequisites['missing_tools'])+'. The bundled DKMS build uses the LLVM toolchain.')
   if any(issue!='missing_build_tools' for issue in prerequisites['build_issues']):
    guidance.append('Install headers matching the running kernel, or reboot into the kernel matching installed headers.')
   raise RuntimeError('Build prerequisites failed: '+json.dumps(prerequisites)+'. '+' '.join(guidance)+' No changes made.')
  if secure_boot() is not False:raise RuntimeError('Secure Boot is enabled or unverified. Configure and verify trusted DKMS signing before installation; no changes made.')
  if not args.upgrade and (SOURCE.exists() or CONFIG.exists() or DKMS_STATE.exists()):raise RuntimeError('Managed destination or DKMS registration already exists; no files overwritten. Remove this version before reinstalling.')
  for conf in [Path('/etc/dkms/framework.conf'), *Path('/etc/dkms/framework.conf.d').glob('*.conf')]:
   if conf.is_file() and re.search(r'^\s*modprobe_on_install\s*=',conf.read_text(),re.M):
    raise RuntimeError('Explicit DKMS modprobe_on_install setting detected; refusing possible automatic module loading.')
  if args.upgrade:
   from types import SimpleNamespace
   from upgrade_install import execute
   execute(SimpleNamespace(**globals()),manifest,platform.machine())
   print('Upgrade installed on disk. Previous sources retained. Reboot to activate; no module or card operation performed.')
   return
  stage=Path(tempfile.mkdtemp(prefix='.hd60pro-',dir=SOURCE.parent))
  added=False
  try:
   for rel in manifest:
    dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(HERE/rel,dest)
   shutil.copy2(HERE/'manifest.json',stage/'manifest.json');stage.chmod(0o755);stage.rename(SOURCE)
   run('dkms','add','-m',NAME,'-v',VERSION);added=True
   run('dkms','build','-m',NAME,'-v',VERSION,'-k',kernel)
   run('dkms','install','-m',NAME,'-v',VERSION,'-k',kernel)
   # Exclusive creation; never clobber an administrator's concurrent change.
   with CONFIG.open('x') as f:f.write(CONFIG_TEXT)
   run('depmod','-a',kernel)
  except BaseException:
   if CONFIG.exists() and CONFIG.read_text()==CONFIG_TEXT:CONFIG.unlink()
   # dkms add may create its state directory before returning failure.
   # Preflight established this version was absent; preserve source if cleanup
   # fails so the administrator still has the material needed for recovery.
   if added or DKMS_STATE.exists():
    try:run('dkms','remove','-m',NAME,'-v',VERSION,'--all')
    except subprocess.CalledProcessError:
     print('DKMS rollback failed; staged source retained for recovery.',file=sys.stderr);raise
   if SOURCE.exists():shutil.rmtree(SOURCE)
   if stage.exists():shutil.rmtree(stage)
   raise
  print('Installed experimental HD60 Pro driver for '+kernel+'. Reboot to activate.')
  print('No driver loaded/unloaded and no card commands sent. See README.txt.')
if __name__=='__main__':
 try:main()
 except (RuntimeError,OSError,subprocess.CalledProcessError) as e:sys.exit(str(e))
