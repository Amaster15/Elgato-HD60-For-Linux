/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_AUDIO_RESTART_H
#define HD60_AUDIO_RESTART_H
#include "../hd60pro-audio-review/audio_sequence.h"
/* Classification only: caller MUST still pass every session_clean gate.
 * Unknown faults and active PCM are never eligible. No current-session
 * resynchronization, ownership release, or new START is authorized here. */
static inline int hd60_audio_restart_classified(unsigned int enabled,
 unsigned int fault,unsigned int ended,unsigned int running)
{
 if(!enabled || !ended || running) return 0;
 return fault==HD60_AUDIO_BAD_COPY || fault==HD60_AUDIO_BAD_TIME ||
        fault==HD60_AUDIO_RING_GAP || fault==HD60_AUDIO_BAD_SLOT;
}
#endif
