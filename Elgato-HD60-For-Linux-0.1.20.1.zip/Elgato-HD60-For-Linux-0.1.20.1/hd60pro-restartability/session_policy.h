/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_SESSION_POLICY_H
#define HD60_SESSION_POLICY_H
#include "../hd60pro-lifecycle/capture_guard.h"
/* Reconfiguration eligibility only. This does not prove firmware restart,
 * DMA drain, or permission to free any registered memory. No I/O here. */
enum hd60_session_phase {
 HD60_SESSION_NEW, HD60_SESSION_RUNNING, HD60_SESSION_RETAINED,
 HD60_SESSION_RECONFIGURING, HD60_SESSION_FAILED
};
struct hd60_session {
 enum hd60_session_phase phase;
 unsigned int completed;
};
struct hd60_session_evidence {
 unsigned int worker_joined, receiver_restored, mappings_owned;
 unsigned int stop_event, master_off_verified, command_pending;
 int error;
};
/* Cancellation while work is still queued: caller must join the worker and
 * prove setup never began. No completion is counted and no hardware evidence
 * is fabricated. Only an untouched NEW session can use this transition. */
static inline int hd60_session_cancel_queued_new(struct hd60_session *s,
 unsigned int worker_joined, unsigned int setup_started,
 unsigned int owner_exists)
{
 if(s->phase!=HD60_SESSION_RUNNING || !worker_joined || setup_started ||
    owner_exists || s->completed) return 0;
 s->phase=HD60_SESSION_NEW;
 return 1;
}
/* Existing lifetime counters cover 4 primary + 32 channel + 8 extra buffers.
 * Registration counts include resubmission of the same extra addresses.
 * Caller must separately verify all actual owner pointers and DMA addresses. */
static inline int hd60_session_clean(const struct hd60_capture_guard *g,
 const struct hd60_session_evidence *e)
{
 return e->worker_joined && e->receiver_restored && e->mappings_owned &&
        e->stop_event && e->master_off_verified && !e->command_pending &&
        !e->error && hd60_capture_io_allowed(g) && !g->master_expected &&
        !g->command_pending && !g->life.pending_event &&
        g->life.stop_confirmed && g->life.dma_ever_enabled &&
        g->life.allocated_buffers == 44 && g->life.registered_buffers >= 44 &&
        !(g->life.registered_buffers % 4);
}
/* Caller serializes transitions and supplies fresh evidence after join. */
static inline int hd60_session_stopped(struct hd60_session *s,
 const struct hd60_capture_guard *g, const struct hd60_session_evidence *e)
{
 if(s->phase != HD60_SESSION_RUNNING || !hd60_session_clean(g,e)) {
  s->phase=HD60_SESSION_FAILED;
  return 0;
 }
 s->completed++;
 s->phase=HD60_SESSION_RETAINED;
 return 1;
}
static inline int hd60_session_prepare(struct hd60_session *s,
 struct hd60_capture_guard *g, const struct hd60_session_evidence *e)
{
 if(s->phase != HD60_SESSION_RETAINED || !hd60_session_clean(g,e)) {
  s->phase=HD60_SESSION_FAILED;
  return 0;
 }
 /* Reset readiness and event eligibility only. Lifetime ownership, health,
  * stop evidence and the fact DMA ran survive this transition unchanged. */
 g->ready=0;
 g->start_submitted=0;
 s->phase=HD60_SESSION_RECONFIGURING;
 return 1;
}
#endif
