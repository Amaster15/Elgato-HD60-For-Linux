/* SPDX-License-Identifier: GPL-2.0 */
#ifndef HD60_STARTUP_RETRY_H
#define HD60_STARTUP_RETRY_H
/* Cleanup eligibility only. Caller must additionally join the worker and
 * verify owner absence before making the session retryable. */
static inline int hd60_startup_cleanup_allows_retry(unsigned int rejected_input,
 unsigned int receiver_restored,unsigned int pci_restored,
 unsigned int registered,unsigned int dma_enabled,unsigned int pending,
 unsigned int healthy)
{
 return rejected_input && receiver_restored && pci_restored && !registered &&
        !dma_enabled && !pending && healthy;
}
#endif
