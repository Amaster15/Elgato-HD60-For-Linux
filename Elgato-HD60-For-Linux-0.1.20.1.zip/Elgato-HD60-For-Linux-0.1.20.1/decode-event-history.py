#!/usr/bin/env python3
"""Decode a stopped driver's frozen audio history; never accesses card registers."""
import argparse,json
from pathlib import Path

def decode(values, head, count):
    if len(values)!=64 or not 0<=head<8 or not 0<=count<=8:
        raise ValueError('Invalid event history dimensions')
    rows=[]
    for i in range(count):
        n=((head-count+i)%8)*8
        t,status,latest,seen,slot,begin,end,notification=values[n:n+8]
        rows.append(dict(entry_ns=t,status=hex(status),mask=(status>>16)&15,
            latest=latest,previous_seen=bool(seen),previous_slot=slot,
            previous_begin_ns=begin,previous_end_ns=end,
            gap_from_previous_begin_ns=t-begin if seen else None,
            notification=notification))
    return rows

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--parameters',type=Path,default=Path('/sys/module/hd60pro_audio_probe/parameters'))
    a=p.parse_args(); root=a.parameters
    if (root/'session_state').read_text().strip()=='1':
        p.error('Stop capture normally before reading the history')
    values=[int(x) for x in (root/'audio_event_history').read_text().strip().split(',')]
    print(json.dumps(dict(fault=int((root/'audio_sequence_fault').read_text()),
        events=decode(values,int((root/'audio_event_history_head').read_text()),
                      int((root/'audio_event_history_count').read_text()))),indent=2))
